import { useState, useEffect, useCallback } from 'react';
import Terminal from './components/Terminal';
import DarkWebSim from './components/DarkWebSim';
import SecretVault from './components/SecretVault';
import NetworkLab from './components/NetworkLab';
import AgencyArsenal from './components/AgencyArsenal';
import TorGateway from './components/TorGateway';
import VirtualLab from './components/VirtualLab';
import SecretLabs from './components/SecretLabs';
import CloudDeployment from './components/CloudDeployment';
import ConferenceIntel from './components/ConferenceIntel';
import SobinTab from './components/SobinTab';
import NuclearArsenal from './components/NuclearArsenal';
import SatelliteOps from './components/SatelliteOps';
import StealthToolkit from './components/StealthToolkit';
import CyberAcademy from './components/CyberAcademy';
import DarkWebTechniques from './components/DarkWebTechniques';
import MegaToolsPanel from './components/MegaToolsPanel';
import LiveWorldMap from './components/LiveWorldMap';
import FutureVault from './components/FutureVault';
import CompanyWeaknessPanel from './components/CompanyWeaknessPanel';
import OSUltimateArsenal from './components/OSUltimateArsenal';
import ShadowCloudShells from './components/ShadowCloudShells';
import SHDockerLab from './components/SHDockerLab';
import SHDarkMarkets from './components/SHDarkMarkets';
import SHHackerCourse from './components/SHHackerCourse';
import SHSecretSites from './components/SHSecretSites';
import DarkCity from './components/DarkCity';
import GitToolsHub from './components/GitToolsHub';
import AIHub from './components/AIHub';
import CodeEditor from './components/CodeEditor';
import InvisibleTools from './components/InvisibleTools';
import ModulesPanel from './components/ModulesPanel';
import FullInstallTools from './components/FullInstallTools';
import type { AccessLevel } from './data/types';

type Panel = 'home'|'gittools'|'aitools'|'codeeditor'|'invisible'|'modules'|'fullinstall'|'tools'|'osint'|'social'|'exploit'|'agency'|'weapons'|'future'|'weakness'|'allos'|'dockerlab'|'cloudshells'|'secretsites'|'darkmarkets'|'hackercourse'|'stealth'|'worldmap'|'nuclear'|'satellites'|'labs'|'academy'|'cloud'|'conferences'|'tor'|'darkweb'|'darktechniques'|'network'|'terminals'|'threat'|'vault'|'darkcity'|'about';

export default function App() {
  const [panel, setPanel] = useState<Panel>('home');
  const [accessLevel, setAccessLevel] = useState<AccessLevel>('researcher');
  const [secretsRevealed] = useState<Set<string>>(new Set());
  const [secretPanelVisible, setSecretPanelVisible] = useState(false);
  const [notifications, setNotifications] = useState<string[]>([]);
  const [, setKeys] = useState('');
  const [time, setTime] = useState(new Date());
  const [comboMsg, setComboMsg] = useState<string|null>(null);

  useEffect(()=>{const t=setInterval(()=>setTime(new Date()),1000);return()=>clearInterval(t);},[]);
  const addNotif=(m:string)=>{setNotifications(p=>[...p.slice(-4),`[${time.toLocaleTimeString()}] ${m}`]);setTimeout(()=>setNotifications(p=>p.slice(1)),4000);};
  const flash=(m:string)=>{setComboMsg(m);setTimeout(()=>setComboMsg(null),1500);};

  const handleKey=useCallback((e:KeyboardEvent)=>{
    setKeys(p=>{const n=(p+e.key.toLowerCase()).slice(-20);
    if(n.includes('doulat')){flash('🔓 FOUNDER VAULT — MR. DOULAT KUMAR');}
    if(n.includes('omega')){setAccessLevel('omega');flash('Ω OMEGA ACCESS');}
    if(e.ctrlKey&&e.shiftKey&&e.key==='R'){e.preventDefault();const l:AccessLevel[]=['public','researcher','classified','omega'];setAccessLevel(l[(l.indexOf(accessLevel)+1)%4]);}
    if(e.ctrlKey&&e.shiftKey&&e.key==='X'){e.preventDefault();setSecretPanelVisible(p=>!p);}
    if(e.ctrlKey&&e.key==='`'){e.preventDefault();setPanel('terminals');}
    if(e.ctrlKey&&e.shiftKey&&e.key==='T'){e.preventDefault();setPanel('tor');}
    if(e.ctrlKey&&e.key==='h'){e.preventDefault();setPanel('home');}
    return n;});},[accessLevel]);
  useEffect(()=>{window.addEventListener('keydown',handleKey);return()=>window.removeEventListener('keydown',handleKey);},[handleKey]);

  const tabs:{id:Panel;label:string;icon?:string;badge?:string;color?:string;secret?:boolean;super?:boolean}[]=[
    {id:'home',label:'HOME'},
    {id:'gittools',label:'GIT TOOLS',badge:'50+',color:'cyan'},
    {id:'aitools',label:'FREE AI',badge:'100+',color:'green'},
    {id:'codeeditor',label:'CODE EDITOR',icon:'fa-code',badge:'LIVE',color:'cyan',super:true},
    {id:'invisible',label:'INVISIBLE',badge:'100+',color:'purple',super:true},
    {id:'modules',label:'MODULES',badge:'2000+',color:'red',super:true},
    {id:'fullinstall',label:'FULL INSTALL',badge:'FUTURE AI',color:'purple',super:true},
    {id:'tools',label:'TOOLS',badge:'300+',color:'red'},
    {id:'osint',label:'OSINT',badge:'50+',color:'cyan'},
    {id:'social',label:'SOCIAL',badge:'25+',color:'purple'},
    {id:'exploit',label:'EXPLOIT',badge:'50+',color:'red'},
    {id:'agency',label:'AGENCY',badge:'70+',color:'red'},
    {id:'weapons',label:'WEAPONS',badge:'12',color:'red'},
    {id:'future',label:'FUTURE',badge:'12',color:'purple'},
    {id:'weakness',label:'VULN INTEL',badge:'40',color:'red'},
    {id:'allos',label:'ALL OS',badge:'50+',color:'cyan'},
    {id:'dockerlab',label:'DOCKER',badge:'12',color:'cyan'},
    {id:'cloudshells',label:'CLOUD',badge:'10',color:'blue'},
    {id:'secretsites',label:'SITES',badge:'100+',color:'blue'},
    {id:'darkmarkets',label:'DARK WEB',badge:'21',color:'purple'},
    {id:'hackercourse',label:'COURSE',badge:'340H',color:'green'},
    {id:'stealth',label:'STEALTH',badge:'Ω',color:'purple'},
    {id:'worldmap',label:'WORLD MAP',badge:'LIVE',color:'green'},
    {id:'nuclear',label:'NUCLEAR',badge:'12',color:'red'},
    {id:'satellites',label:'SAT',badge:'12',color:'cyan'},
    {id:'labs',label:'LABS',badge:'8',color:'green'},
    {id:'academy',label:'ACADEMY',badge:'8',color:'green'},
    {id:'cloud',label:'DEPLOY',color:'blue'},
    {id:'conferences',label:'EVENTS',color:'yellow'},
    {id:'tor',label:'TOR',color:'purple'},
    {id:'darkweb',label:'DARK',color:'purple'},
    {id:'darktechniques',label:'OPSEC',color:'purple'},
    {id:'network',label:'NET',color:'cyan'},
    {id:'terminals',label:'TERM',color:'green'},
    {id:'threat',label:'INTEL',color:'red'},
    {id:'vault',label:'VAULT',color:'yellow'},
    {id:'darkcity',label:'DARKCITY',badge:'🔒',color:'red',secret:true},
  ];

  const c=(t:typeof tabs[0])=>{
    if(t.id!==panel) return {borderColor:'transparent',color:'#606080'};
    const col=t.color==='red'?'#ff3050':t.color==='cyan'?'#00e0ff':t.color==='purple'?'#a070ff':t.color==='green'?'#00e040':t.color==='yellow'?'#ffb000':t.color==='blue'?'#4080ff':'#8080a0';
    return {borderColor:col,color:col,backgroundColor:`${col}15`};
  };

  return (
    <div className="min-h-screen bg-[#060608] text-[#d0d0e0] font-mono flex flex-col">
      {/* TOAST */}
      {comboMsg&&<div className="fixed top-4 left-1/2 -translate-x-1/2 z-[9999] px-6 py-3 bg-[#0a0a12] border-2 border-[#00e0ff] rounded-lg text-[#00e0ff] font-black text-sm animate-pulse shadow-[0_0_30px_rgba(0,224,255,0.3)]">{comboMsg}</div>}

      {/* HEADER */}
      <header className="bg-[#080810] border-b-2 border-red-900/20">
        <div className="max-w-[1600px] mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="relative w-11 h-11 flex-shrink-0">
              <div className="absolute inset-0 bg-gradient-to-br from-red-600 via-red-800 to-black rounded-lg flex items-center justify-center shadow-[0_0_25px_rgba(255,0,0,0.3)]">
                <span className="text-white font-black text-[22px]" style={{fontFamily:'Impact, sans-serif'}}>D</span>
              </div>
              <div className="absolute -top-0.5 -right-0.5 w-3 h-3 bg-[#00e0ff] rounded-full animate-pulse-slow"/>
            </div>
            <div>
              <h1 className="text-3xl font-black tracking-tighter" style={{fontFamily:'Impact, sans-serif'}}>
                <span className="text-white">DOULA</span><span className="text-red-600">TREX</span>
              </h1>
              <p className="text-red-700/60 text-[10px] tracking-[4px] uppercase">BY DARKBRO — MR. DOULAT KUMAR</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className={`badge ${accessLevel==='omega'?'badge-omega':accessLevel==='classified'?'badge-classified':'badge-researcher'}`}>{accessLevel}</span>
            <span className="text-gray-500 text-xs font-bold">{time.toLocaleTimeString()}</span>
          </div>
        </div>
      </header>

      {/* NAV */}
      <nav className="bg-[#0a0a12] border-b border-[#181830] overflow-x-auto">
        <div className="max-w-[1600px] mx-auto flex px-2">
          {tabs.map(t=>(
            <button key={t.id} onClick={()=>setPanel(t.id)}
              className={`flex items-center gap-1 px-3 py-2 text-[10px] font-bold whitespace-nowrap border-b-2 transition-all ${t.secret?'animate-pulse-slow':''}`}
              style={c(t)}>
              {t.label}{t.badge&&<span className="ml-1 px-1.5 py-0.5 text-[7px] rounded-full font-black bg-[#181830]">{t.badge}</span>}
            </button>
          ))}
        </div>
      </nav>

      {/* NOTIFICATIONS */}
      <div className="fixed top-14 right-3 z-[100] space-y-1 pointer-events-none">
        {notifications.map((n,i)=>(<div key={i} className="bg-[#0c0c14] border border-[#181830] px-3 py-1.5 text-[9px] text-[#00e0ff] rounded animate-fadein">{n}</div>))}
      </div>

      {/* SECRET LABS */}
      {secretPanelVisible&&<SecretLabs accessLevel={accessLevel} secretsRevealed={secretsRevealed} onClose={()=>setSecretPanelVisible(false)} onUnlock={()=>{}}/>}

      {/* CONTENT */}
      <div className="relative z-10 flex-1">
        {/* HOME */}
        {panel==='home'&&<HomePanel onNav={setPanel} level={accessLevel}/>}

        {/* GIT TOOLS */}
        {panel==='gittools'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><GitToolsHub/></div>}

        {/* AI TOOLS + CODE EDITOR */}
        {panel==='aitools'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><AIHub/></div>}
        {panel==='codeeditor'&&<CodeEditor/>}
        {panel==='invisible'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><InvisibleTools/></div>}
        {panel==='modules'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><ModulesPanel/></div>}
        {panel==='fullinstall'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><FullInstallTools/></div>}

        {/* TOOLS PANELS */}
        {panel==='tools'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><MegaToolsPanel/></div>}
        {panel==='osint'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><MegaToolsPanel categoryFilter="OSINT"/></div>}
        {panel==='social'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><MegaToolsPanel categoryFilter="Social"/></div>}
        {panel==='exploit'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><MegaToolsPanel categoryFilter="Exploitation,Vulnerability,Password,Wireless,WebApplication"/></div>}

        {/* AGENCY + WEAPONS */}
        {panel==='agency'&&<AgencyArsenal/>}
        {panel==='weapons'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><SobinTab/></div>}

        {/* FUTURE + WEAKNESS */}
        {panel==='future'&&<FutureVault/>}
        {panel==='weakness'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><CompanyWeaknessPanel/></div>}

        {/* ALL OS */}
        {panel==='allos'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><OSUltimateArsenal/></div>}

        {/* DOCKER + CLOUD + SITES */}
        {panel==='dockerlab'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><SHDockerLab/></div>}
        {panel==='cloudshells'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><ShadowCloudShells/></div>}
        {panel==='secretsites'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><SHSecretSites/></div>}

        {/* DARK WEB + COURSE */}
        {panel==='darkmarkets'&&<SHDarkMarkets/>}
        {panel==='hackercourse'&&<SHHackerCourse/>}

        {/* STEALTH + WORLD MAP */}
        {panel==='stealth'&&<StealthToolkit accessLevel={accessLevel}/>}
        {panel==='worldmap'&&<div className="h-full"><LiveWorldMap/></div>}

        {/* NUCLEAR + SATELLITES */}
        {panel==='nuclear'&&<NuclearArsenal accessLevel={accessLevel}/>}
        {panel==='satellites'&&<SatelliteOps accessLevel={accessLevel}/>}

        {/* LABS + ACADEMY + CLOUD DEPLOY */}
        {panel==='labs'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><VirtualLab accessLevel={accessLevel} secretsRevealed={secretsRevealed}/></div>}
        {panel==='academy'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><CyberAcademy/></div>}
        {panel==='cloud'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><CloudDeployment/></div>}

        {/* CONFERENCES + TOR + DARK WEB + OPSEC */}
        {panel==='conferences'&&<div className="mx-auto max-w-[1500px] w-full px-4 py-4"><ConferenceIntel/></div>}
        {panel==='tor'&&<TorGateway/>}
        {panel==='darkweb'&&<DarkWebSim accessLevel={accessLevel}/>}
        {panel==='darktechniques'&&<DarkWebTechniques/>}

        {/* NETWORK LAB */}
        {panel==='network'&&<NetworkLab/>}

        {/* TERMINALS */}
        {panel==='terminals'&&(
          <div className="h-screen grid gap-0.5 bg-[#060608] grid-cols-2">
            {[1,2].map(id=><Terminal key={id} id={id} accessLevel={accessLevel} onCommand={addNotif}/>)}
          </div>
        )}

        {/* THREAT + VAULT + DARKCITY */}
        {panel==='threat'&&<ThreatPanel/>}
        {panel==='vault'&&<SecretVault accessLevel={accessLevel}/>}
        {panel==='darkcity'&&<DarkCity/>}

        {/* ABOUT */}
        {panel==='about'&&<AboutPanel/>}
      </div>

      {/* FOOTER */}
      <footer className="bg-[#080810] border-t-2 border-red-900/20 py-4 text-center">
        <div className="flex items-center justify-center gap-3 mb-1">
          <span className="text-xl font-black text-white" style={{fontFamily:'Impact, sans-serif'}}>DOULA<span className="text-red-600">TREX</span></span>
          <span className="text-gray-700 text-[9px] tracking-[3px] uppercase">V1.0</span>
        </div>
        <p className="text-gray-600 text-[9px]">
          CREATED BY <span className="text-red-500 font-bold">MR. DOULAT KUMAR</span> (DARKBRO) |
          <span className="text-gray-500 ml-2">SHADOWSEC RESEARCH INSTITUTE</span> |
          <span className="text-gray-500 ml-2">{tabs.length} MODULES | 1000+ TOOLS | EDUCATIONAL ONLY</span>
        </p>
      </footer>
    </div>
  );
}

/* ═══════════════════════════════════════════════════
   HOME PANEL
   ═══════════════════════════════════════════════════ */
function HomePanel({ onNav, level }: { onNav: (p: Panel) => void; level: AccessLevel }) {
  const navs:{l:string;c:string;p:Panel}[]=[
    {l:'MEGA TOOLS — 300+ Real Hacking Tools',c:'#ff3050',p:'tools'},
    {l:'OSINT TOOLS — 50+ Reconnaissance Tools (Sherlock, Holehe, Maigret)',c:'#00e0ff',p:'osint'},
    {l:'SOCIAL ATTACK — 25+ Social Media Attack Tools (Evilginx2, Zphisher)',c:'#a070ff',p:'social'},
    {l:'EXPLOITATION — 50+ Frameworks (Metasploit, Covenant, Sliver, Empire)',c:'#ff3050',p:'exploit'},
    {l:'AGENCY ARSENAL — 70+ Tools (NSA·CIA·Mossad·GRU·MSS·GCHQ·BND)',c:'#ff3050',p:'agency'},
    {l:'CYBER WEAPONS DB — Stuxnet·WannaCry·NotPetya·Pegasus·Triton',c:'#ff3050',p:'weapons'},
    {l:'FUTURE VAULT — 12 Predicted Tools (QuantumSploit, NeuralForge, BioMesh)',c:'#a070ff',p:'future'},
    {l:'VULNERABILITY INTEL — 10 Companies + 30 Attack Techniques',c:'#ff3050',p:'weakness'},
    {l:'ALL WORLD OS — 50+ OS (Kali·Kylin·Red Star·Astra·Qubes·TAILS)',c:'#00e0ff',p:'allos'},
    {l:'DOCKER LAB — 12 Security Containers (DVWA·Juice Shop·WebGoat)',c:'#00e0ff',p:'dockerlab'},
    {l:'CLOUD SHELLS — 10 Environments (AWS·GCP·Azure·GitHub Codespaces)',c:'#4080ff',p:'cloudshells'},
    {l:'LEARNING SITES — 100+ Platforms & 15 Verified Onion Sites',c:'#4080ff',p:'secretsites'},
    {l:'DARK WEB INTEL — 6 Historic Markets + OpSec Lessons',c:'#a070ff',p:'darkmarkets'},
    {l:'HACKER COURSE — 7 Phases · 340 Hours · 49 Topics',c:'#00e040',p:'hackercourse'},
    {l:'STEALTH TOOLS — Ω Classified Invisible Arsenal',c:'#a070ff',p:'stealth'},
    {l:'LIVE WORLD MAP — Real-Time Global Cyber Attack Visualization',c:'#00e040',p:'worldmap'},
    {l:'NUCLEAR ARSENAL — 12 Global Nuclear Weapons Systems',c:'#ff3050',p:'nuclear'},
    {l:'SATELLITE OPS — 12 Classified Orbital Assets (KH-11, Mentor, X-37B)',c:'#00e0ff',p:'satellites'},
    {l:'VIRTUAL LABS — 8 Practice Environments',c:'#00e040',p:'labs'},
    {l:'CYBER ACADEMY — 8 Courses (CEH→OSCP→OMEGA)',c:'#00e040',p:'academy'},
    {l:'CLOUD DEPLOY — AWS·Azure·GCP·Kubernetes·Docker',c:'#4080ff',p:'cloud'},
    {l:'GLOBAL CONFERENCES — DEF CON·Black Hat·RSA·CCC',c:'#ffb000',p:'conferences'},
    {l:'TOR GATEWAY — Anonymous Network Access',c:'#a070ff',p:'tor'},
    {l:'DARK WEB SIMULATOR — .onion Site Exploration',c:'#a070ff',p:'darkweb'},
    {l:'OPSEC GUIDE — 8 Dark Web Techniques & Anonymity Methods',c:'#a070ff',p:'darktechniques'},
    {l:'NETWORK LAB — Simulated Network Reconnaissance',c:'#00e0ff',p:'network'},
    {l:'TERMINAL — Multi-Terminal Command Center (Up to 6)',c:'#00e040',p:'terminals'},
    {l:'THREAT INTEL — Live Cyber Threat Monitoring Feed',c:'#ff3050',p:'threat'},
    {l:'SECRET VAULT — Classified Intelligence Repository',c:'#ffb000',p:'vault'},
    {l:'DARKCITY OF DARKBRO — Secret Maze District (Code Required)',c:'#ff3050',p:'darkcity'},
  ];

  return (
    <div className="max-w-[1400px] mx-auto px-4 py-6 space-y-8 animate-fadein">
      {/* HERO */}
      <div className="text-center space-y-3 py-8">
        <div className="relative inline-block">
          <div className="w-20 h-20 bg-gradient-to-br from-red-600 via-red-800 to-black rounded-2xl flex items-center justify-center shadow-[0_0_50px_rgba(255,0,0,0.4)] mx-auto">
            <span className="text-white font-black text-5xl" style={{fontFamily:'Impact, sans-serif'}}>D</span>
          </div>
          <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#00e0ff] rounded-full animate-pulse-slow"/>
        </div>
        <h1 className="text-7xl font-black tracking-tighter" style={{fontFamily:'Impact, sans-serif'}}>
          <span className="text-white">DOULA</span><span className="text-red-600">TREX</span>
        </h1>
        <p className="text-red-700/70 text-sm tracking-[6px] uppercase">SHADOWSEC RESEARCH INSTITUTE</p>
        <p className="text-gray-500 text-xs">WORLD'S MOST ADVANCED CYBERSECURITY EDUCATION PLATFORM</p>
        <div className="flex items-center justify-center gap-3 pt-2">
          <span className={`badge ${level==='omega'?'badge-omega':level==='classified'?'badge-classified':'badge-researcher'}`}>{level.toUpperCase()}</span>
          <span className="text-gray-600 text-xs">|</span>
          <span className="text-red-500 font-bold text-sm">MR. DOULAT KUMAR (DARKBRO)</span>
        </div>
      </div>

      <div className="h-px bg-gradient-to-r from-transparent via-red-900/30 to-transparent"/>

      {/* WHAT IS DOULATREX */}
      <div className="max-w-3xl mx-auto">
        <h2 className="text-3xl font-black text-white mb-3" style={{fontFamily:'Impact, sans-serif'}}>WHAT IS DOULATREX?</h2>
        <div className="space-y-1 text-sm text-gray-400">
          <p>• THE ULTIMATE CYBERSECURITY EDUCATION & RESEARCH PLATFORM</p>
          <p>• 1000+ REAL HACKING TOOLS WITH COMMANDS & INSTALLATION GUIDES</p>
          <p>• 50+ OPERATING SYSTEMS FROM EVERY COUNTRY IN THE WORLD</p>
          <p>• COMPLETE HACKER TRAINING CURRICULUM — 7 PHASES, 340 HOURS</p>
          <p>• LIVE GLOBAL CYBER THREAT MAP WITH REAL-TIME EVENT FEED</p>
          <p>• 12 CLOUD SHELL ENVIRONMENTS FOR REMOTE TOOL DEPLOYMENT</p>
          <p>• DOCKER LABORATORY — 12 VULNERABLE CONTAINERS FOR PRACTICE</p>
          <p>• 70+ CLASSIFIED AGENCY TOOLS (NSA, CIA, MOSSAD, GRU, MSS, GCHQ, BND)</p>
          <p>• 12 DOCUMENTED CYBER WEAPONS WITH FULL TECHNICAL ANALYSIS</p>
          <p>• 12 PREDICTED FUTURE TOOLS — QUANTUM, AI, BIO-CYBER RESEARCH</p>
          <p>• 30 ATTACK TECHNIQUES WITH COMMANDS, TOOLS & MITIGATION</p>
          <p>• 10 GLOBAL CORPORATE VULNERABILITY INTELLIGENCE REPORTS</p>
          <p>• 100+ HACKING LEARNING WEBSITES & 15 VERIFIED .ONION SITES</p>
          <p>• COMPLETE DARK WEB INTELLIGENCE — MARKETS, OPSEC, TECHNIQUES</p>
          <p>• ALL CONTENT IS STRICTLY FOR EDUCATIONAL & DEFENSIVE PURPOSES</p>
        </div>
      </div>

      <div className="h-px bg-gradient-to-r from-transparent via-red-900/30 to-transparent"/>

      {/* QUICK NAV — ALL 30 MODULES */}
      <div>
        <h2 className="text-2xl font-black text-white mb-3" style={{fontFamily:'Impact, sans-serif'}}>ALL MODULES ({navs.length})</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-1.5">
          {navs.map((n,i)=>(
            <button key={i} onClick={()=>onNav(n.p)}
              className="card p-3 text-left hover:border-red-500/20 transition-all"
              style={{borderLeft:`3px solid ${n.c}`}}>
              <span className="text-white font-bold text-[10px]">{n.l}</span>
            </button>
          ))}
        </div>
      </div>

      {/* STATS */}
      <div className="grid grid-cols-4 md:grid-cols-8 gap-2 text-center">
        {[{v:'1000+',l:'TOOLS'},{v:'50+',l:'OS'},{v:'30',l:'MODULES'},{v:'70+',l:'AGENCY TOOLS'},{v:'340H',l:'TRAINING'},{v:'12',l:'DOCKER LABS'},{v:'10',l:'CLOUD SHELLS'},{v:'100+',l:'SITES'}].map((s,i)=>(
          <div key={i} className="card p-3"><div className="text-red-500 font-black text-lg">{s.v}</div><div className="text-gray-600 text-[9px]">{s.l}</div></div>
        ))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════
   THREAT PANEL
   ═══════════════════════════════════════════════════ */
function ThreatPanel() {
  const threats=[{name:'APT29 Cozy Bear',sev:'CRITICAL',type:'State-Sponsored',desc:'Russian SVR threat actor — SolarWinds, Microsoft breaches',src:'CISA/FBI'},{name:'Volt Typhoon',sev:'CRITICAL',type:'Chinese APT',desc:'PRC critical infrastructure targeting US/EU',src:'NSA/CISA'},{name:'Lazarus Group',sev:'CRITICAL',type:'North Korean APT',desc:'DPRK $1B+ crypto heists, supply chain attacks',src:'FBI'},{name:'Storm-0558',sev:'CRITICAL',type:'Chinese APT',desc:'Microsoft Exchange Online — US gov emails breached',src:'CISA'},{name:'LockBit',sev:'HIGH',type:'Ransomware',desc:'RaaS — 2000+ victims, $100M+ extorted',src:'Europol'},{name:'APT40 Leviathan',sev:'HIGH',type:'Chinese APT',desc:'Maritime & naval technology theft',src:'ASD'}];
  return (
    <div className="h-full bg-[#060608] p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4"><h2 className="text-3xl font-black text-red-500" style={{fontFamily:'Impact, sans-serif'}}>THREAT INTEL</h2><span className="text-[9px] text-red-500 animate-pulse">● LIVE FEED</span></div>
      <div className="flex-1 overflow-y-auto space-y-2">
        {threats.map((t,i)=>(<div key={i} className="card border-red-900/20 hover:border-red-500/30 p-3"><div className="flex items-center justify-between"><div className="flex items-center gap-2"><span className={`tag ${t.sev==='CRITICAL'?'tag-red':'tag-yellow'}`}>{t.sev}</span><span className="text-white font-bold text-xs">{t.name}</span></div><span className="text-[9px] text-gray-500">{t.type}</span></div><p className="text-[10px] text-gray-400 mt-1">{t.desc}</p><span className="text-[8px] text-gray-600">Source: {t.src}</span></div>))}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════
   ABOUT PANEL
   ═══════════════════════════════════════════════════ */
function AboutPanel() {
  return (
    <div className="max-w-[800px] mx-auto px-4 py-8 space-y-6 animate-fadein">
      <h2 className="text-4xl font-black text-white" style={{fontFamily:'Impact, sans-serif'}}>ABOUT DOULATREX</h2>
      <div className="card border-red-900/20 p-6 space-y-3">
        <p className="text-gray-300 text-sm">• <span className="text-red-400 font-bold">DOULATREX</span> is the world's most advanced cybersecurity education and research platform.</p>
        <p className="text-gray-300 text-sm">• Created by <span className="text-red-400 font-bold">Mr. Doulat Kumar</span>, also known as <span className="text-red-400 font-bold">DarkBro</span>.</p>
        <p className="text-gray-300 text-sm">• The platform serves as the <span className="text-cyan-400">ShadowSec Research Institute</span> — a comprehensive resource for cybersecurity professionals, researchers, and students worldwide.</p>
        <p className="text-gray-300 text-sm">• <span className="text-yellow-400 font-bold">MISSION:</span> To provide the most extensive educational cybersecurity resource on the planet — covering every tool, technique, operating system, and methodology used in the field.</p>
        <p className="text-gray-300 text-sm">• <span className="text-red-400 font-bold">DISCLAIMER:</span> All content is strictly for educational and defensive security purposes. Unauthorized use of these techniques is illegal.</p>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        {[{v:'1000+',l:'Tools'},{v:'50+',l:'Operating Systems'},{v:'30',l:'Modules'},{v:'340H',l:'Course Content'}].map((s,i)=>(<div key={i} className="card p-4 text-center"><div className="text-red-500 font-black text-2xl">{s.v}</div><div className="text-gray-500 text-[10px]">{s.l}</div></div>))}
      </div>
    </div>
  );
}
