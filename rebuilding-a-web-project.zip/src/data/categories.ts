import type { ResearchTool, TerminalCommand, ThreatData, DarkWebSite, Agency } from './types';

export const researchTools: ResearchTool[] = [
  // Reconnaissance
  { id: 'nmap', name: 'Nmap', description: 'Network discovery and security auditing', longDescription: 'Nmap ("Network Mapper") is a free and open source utility for network discovery and security auditing. Many systems and network administrators also find it useful for tasks such as network inventory, managing service upgrade schedules, and monitoring host or service uptime.', category: 'Reconnaissance', icon: 'fa-radar', level: 'public', commands: ['nmap -sS target', 'nmap -sV target', 'nmap -A target'], tags: ['scanning', 'network', 'discovery'], os: ['Linux', 'Windows', 'macOS'], usage: 'nmap [scan type] [options] {target}', install: 'sudo apt install nmap' },
  { id: 'masscan', name: 'Masscan', description: 'Fastest Internet port scanner', longDescription: 'Masscan is the fastest Internet port scanner. It can scan the entire Internet in under 6 minutes, transmitting 10 million packets per second.', category: 'Reconnaissance', icon: 'fa-bolt', level: 'researcher', commands: ['masscan -p80,443 10.0.0.0/8', 'masscan --rate=10000'], tags: ['scanning', 'fast', 'mass'], os: ['Linux', 'macOS'], usage: 'masscan [options] {target}', install: 'sudo apt install masscan' },
  { id: 'shodan', name: 'Shodan', description: 'Search engine for Internet-connected devices', longDescription: 'Shodan is a search engine that lets users search for various types of servers connected to the internet using a variety of filters.', category: 'Reconnaissance', icon: 'fa-search', level: 'public', commands: ['shodan search apache', 'shodan host 1.1.1.1'], tags: ['search', 'iot', 'scanning'], url: 'https://shodan.io' },
  { id: 'theharvester', name: 'theHarvester', description: 'Email, subdomain, and name harvester', longDescription: 'theHarvester gathers emails, subdomains, hosts, employee names, open ports and banners from different public sources.', category: 'Reconnaissance', icon: 'fa-envelope', level: 'researcher', commands: ['theharvester -d domain.com -b google', 'theharvester -d domain.com -b all'], tags: ['email', 'osint', 'subdomain'], os: ['Linux', 'macOS'], install: 'sudo apt install theharvester' },
  { id: 'maltego', name: 'Maltego', description: 'Graphical link analysis for OSINT', longDescription: 'Maltego is an interactive data mining tool that renders directed graphs for link analysis.', category: 'Reconnaissance', icon: 'fa-project-diagram', level: 'classified', tags: ['osint', 'graph', 'analysis'], url: 'https://maltego.com' },
  { id: 'recon-ng', name: 'Recon-ng', description: 'Full-featured web reconnaissance framework', longDescription: 'Recon-ng is a full-featured reconnaissance framework designed with the goal of providing a powerful environment to conduct open source web-based reconnaissance.', category: 'Reconnaissance', icon: 'fa-eye', level: 'researcher', commands: ['recon-ng', 'workspaces create target'], tags: ['osint', 'framework', 'recon'], os: ['Linux'], install: 'sudo apt install recon-ng' },

  // Exploitation
  { id: 'metasploit', name: 'Metasploit', description: 'World\'s most used penetration testing framework', longDescription: 'The Metasploit Framework is a Ruby-based, modular penetration testing platform that enables you to write, test, and execute exploit code.', category: 'Exploitation', icon: 'fa-bomb', level: 'researcher', commands: ['msfconsole', 'use exploit/multi/handler', 'set PAYLOAD windows/meterpreter/reverse_tcp'], tags: ['framework', 'exploit', 'payload'], os: ['Linux', 'Windows', 'macOS'], usage: 'msfconsole', install: 'curl https://raw.githubusercontent.com/rapid7/metasploit-framework/master/msfinstall | bash' },
  { id: 'burpsuite', name: 'Burp Suite', description: 'Web application security testing platform', longDescription: 'Burp Suite is a graphical tool for testing Web application security. It functions as an intercepting proxy, allowing analysis of web traffic.', category: 'Exploitation', icon: 'fa-bug', level: 'researcher', tags: ['web', 'proxy', 'intercept'], url: 'https://portswigger.net/burp' },
  { id: 'sqlmap', name: 'SQLMap', description: 'Automatic SQL injection tool', longDescription: 'sqlmap is an open source penetration testing tool that automates the process of detecting and exploiting SQL injection flaws.', category: 'Exploitation', icon: 'fa-database', level: 'researcher', commands: ['sqlmap -u "http://target.com/page?id=1"', 'sqlmap -r request.txt --dbs'], tags: ['sql', 'injection', 'database'], os: ['Linux', 'Windows', 'macOS'], install: 'sudo apt install sqlmap' },
  { id: 'hydra', name: 'Hydra', description: 'Parallelized login cracker', longDescription: 'Hydra is a parallelized login cracker which supports numerous protocols to attack. It is very fast and flexible.', category: 'Exploitation', icon: 'fa-key', level: 'researcher', commands: ['hydra -l admin -P pass.txt target ssh', 'hydra -L users.txt -P pass.txt target ftp'], tags: ['bruteforce', 'login', 'cracking'], os: ['Linux', 'Windows', 'macOS'], install: 'sudo apt install hydra' },
  { id: 'beef', name: 'BeEF', description: 'Browser Exploitation Framework', longDescription: 'BeEF is short for The Browser Exploitation Framework. It is a penetration testing tool that focuses on the web browser.', category: 'Exploitation', icon: 'fa-chrome', level: 'classified', commands: ['beef-xss', 'cd /usr/share/beef-xss && ./beef'], tags: ['browser', 'xss', 'hooking'], os: ['Linux'], install: 'sudo apt install beef-xss' },

  // Post-Exploitation
  { id: 'mimikatz', name: 'Mimikatz', description: 'Windows credential extractor', longDescription: 'Mimikatz is a leading post-exploitation tool that extracts plaintext passwords, hashes, PIN codes and kerberos tickets from memory.', category: 'Post-Exploitation', icon: 'fa-user-secret', level: 'classified', commands: ['mimikatz.exe "privilege::debug" "sekurlsa::logonpasswords"'], tags: ['credentials', 'windows', 'memory'], os: ['Windows'] },
  { id: 'bloodhound', name: 'BloodHound', description: 'Active Directory attack path mapping', longDescription: 'BloodHound uses graph theory to reveal the hidden and often unintended relationships within an Active Directory environment.', category: 'Post-Exploitation', icon: 'fa-sitemap', level: 'classified', tags: ['active-directory', 'graph', 'escalation'], os: ['Linux', 'Windows'], install: 'sudo apt install bloodhound' },
  { id: 'covenant', name: 'Covenant', description: '.NET command and control framework', longDescription: 'Covenant is a .NET command and control framework that serves as a collaborative platform for red teamers.', category: 'Post-Exploitation', icon: 'fa-skull', level: 'omega', tags: ['c2', 'dotnet', 'redteam'] },

  // Wireless
  { id: 'aircrack-ng', name: 'Aircrack-ng', description: 'Complete WiFi security auditing suite', longDescription: 'Aircrack-ng is a complete suite of tools to assess WiFi network security. It focuses on monitoring, attacking, testing, and cracking.', category: 'Wireless', icon: 'fa-wifi', level: 'researcher', commands: ['airmon-ng start wlan0', 'airodump-ng wlan0mon', 'aircrack-ng -w wordlist.txt capture.cap'], tags: ['wifi', 'wpa', 'cracking'], os: ['Linux'], install: 'sudo apt install aircrack-ng' },
  { id: 'bettercap', name: 'Bettercap', description: 'Swiss army knife for WiFi, BLE, ETH', longDescription: 'Bettercap is a powerful, easily extensible and portable framework written in Go which aims to offer to security researchers.', category: 'Wireless', icon: 'fa-network-wired', level: 'classified', commands: ['bettercap -iface wlan0', 'net.probe on', 'wifi.recon on'], tags: ['wifi', 'ble', 'mitm'], os: ['Linux', 'macOS'], install: 'sudo apt install bettercap' },

  // Forensics
  { id: 'autopsy', name: 'Autopsy', description: 'Digital forensics platform', longDescription: 'Autopsy is a digital forensics platform and graphical interface to The Sleuth Kit and other digital forensics tools.', category: 'Forensics', icon: 'fa-microscope', level: 'researcher', tags: ['forensics', 'analysis', 'recovery'], os: ['Linux', 'Windows', 'macOS'] },
  { id: 'volatility', name: 'Volatility', description: 'Memory forensics framework', longDescription: 'The Volatility Framework is a completely open collection of tools for the extraction of digital artifacts from volatile memory (RAM) samples.', category: 'Forensics', icon: 'fa-memory', level: 'classified', commands: ['volatility -f memory.dump imageinfo', 'volatility -f memory.dump --profile=Win7SP1x64 pslist'], tags: ['memory', 'forensics', 'analysis'], os: ['Linux', 'Windows', 'macOS'], install: 'sudo apt install volatility' },

  // Social Engineering
  { id: 'setoolkit', name: 'SET', description: 'Social-Engineer Toolkit', longDescription: 'The Social-Engineer Toolkit is an open-source penetration testing framework designed for social engineering.', category: 'Social Engineering', icon: 'fa-users', level: 'classified', commands: ['setoolkit', 'select option 1 for spear-phishing'], tags: ['phishing', 'social', 'engineering'], os: ['Linux'], install: 'sudo apt install set' },
  { id: 'gophish', name: 'GoPhish', description: 'Open-source phishing toolkit', longDescription: 'Gophish is a powerful, open-source phishing framework that makes it easy to test your organization\'s exposure to phishing.', category: 'Social Engineering', icon: 'fa-fish', level: 'researcher', tags: ['phishing', 'campaign', 'framework'], os: ['Linux', 'Windows', 'macOS'] },
];

export const terminalCommands: TerminalCommand[] = [
  { cmd: 'ls', desc: 'List directory contents', usage: 'ls [options] [path]', category: 'System', level: 'public' },
  { cmd: 'cd', desc: 'Change directory', usage: 'cd [path]', category: 'System', level: 'public' },
  { cmd: 'pwd', desc: 'Print working directory', category: 'System', level: 'public' },
  { cmd: 'cat', desc: 'Concatenate and display files', usage: 'cat [file]', category: 'System', level: 'public' },
  { cmd: 'nmap', desc: 'Network mapper & port scanner', usage: 'nmap -sS -sV target', category: 'Recon', level: 'public' },
  { cmd: 'whois', desc: 'Domain WHOIS lookup', usage: 'whois domain.com', category: 'Recon', level: 'public' },
  { cmd: 'dig', desc: 'DNS lookup utility', usage: 'dig domain.com ANY', category: 'Recon', level: 'public' },
  { cmd: 'gobuster', desc: 'Directory/file brute-forcer', usage: 'gobuster dir -u URL -w wordlist', category: 'Recon', level: 'researcher' },
  { cmd: 'ffuf', desc: 'Fast web fuzzer', usage: 'ffuf -u URL/FUZZ -w wordlist', category: 'Recon', level: 'researcher' },
  { cmd: 'nikto', desc: 'Web server scanner', usage: 'nikto -h target.com', category: 'Scanning', level: 'researcher' },
  { cmd: 'wpscan', desc: 'WordPress vulnerability scanner', usage: 'wpscan --url target.com', category: 'Scanning', level: 'researcher' },
  { cmd: 'john', desc: 'John the Ripper password cracker', usage: 'john --wordlist=pass.txt hash.txt', category: 'Cracking', level: 'researcher' },
  { cmd: 'hashcat', desc: 'Advanced password recovery', usage: 'hashcat -m 0 hash.txt wordlist.txt', category: 'Cracking', level: 'classified' },
  { cmd: 'msfconsole', desc: 'Metasploit framework console', usage: 'msfconsole -q', category: 'Exploitation', level: 'researcher' },
  { cmd: 'msfvenom', desc: 'Payload generator', usage: 'msfvenom -p windows/meterpreter/reverse_tcp LHOST=IP LPORT=PORT -f exe', category: 'Exploitation', level: 'classified' },
  { cmd: 'searchsploit', desc: 'Exploit-DB search tool', usage: 'searchsploit apache 2.4', category: 'Exploitation', level: 'researcher' },
  { cmd: 'netcat', desc: 'TCP/IP Swiss Army knife', usage: 'nc -lvp 4444', category: 'Networking', level: 'public' },
  { cmd: 'socat', desc: 'Multipurpose relay', usage: 'socat TCP-LISTEN:8080,fork TCP:host:80', category: 'Networking', level: 'researcher' },
  { cmd: 'tcpdump', desc: 'Network packet analyzer', usage: 'tcpdump -i eth0 port 80', category: 'Networking', level: 'public' },
  { cmd: 'wireshark', desc: 'Network protocol analyzer (GUI)', usage: 'wireshark', category: 'Networking', level: 'public' },
  { cmd: 'chmod', desc: 'Change file permissions', usage: 'chmod +x script.sh', category: 'System', level: 'public' },
  { cmd: 'ssh', desc: 'Secure shell client', usage: 'ssh user@host -p 22', category: 'System', level: 'public' },
  { cmd: 'scp', desc: 'Secure copy', usage: 'scp file.txt user@host:/path/', category: 'System', level: 'public' },
  { cmd: 'proxychains', desc: 'Force TCP connections through proxy', usage: 'proxychains nmap -sT target', category: 'Anonymity', level: 'classified' },
  { cmd: 'torify', desc: 'Route traffic through TOR', usage: 'torify curl http://onion.site', category: 'Anonymity', level: 'classified' },
  { cmd: 'macchanger', desc: 'MAC address changer', usage: 'macchanger -r eth0', category: 'Anonymity', level: 'researcher' },
  { cmd: 'exiftool', desc: 'Read/write meta information', usage: 'exiftool image.jpg', category: 'Forensics', level: 'public' },
  { cmd: 'binwalk', desc: 'Firmware analysis tool', usage: 'binwalk -e firmware.bin', category: 'Forensics', level: 'researcher' },
  { cmd: 'foremost', desc: 'File carving tool', usage: 'foremost -t all -i disk.img', category: 'Forensics', level: 'researcher' },
  { cmd: 'steghide', desc: 'Steganography tool', usage: 'steghide extract -sf image.jpg', category: 'Forensics', level: 'researcher' },
  { cmd: 'doulat', desc: '[CLASSIFIED] DOULATREX system access', usage: 'doulat --init', category: 'DOULATREX', level: 'omega' },
  { cmd: 'omega', desc: '[OMEGA] Activate omega protocols', usage: 'omega --activate', category: 'DOULATREX', level: 'omega' },
  { cmd: 'darkbro', desc: '[FOUNDER] Creator override', usage: 'darkbro --status', category: 'DOULATREX', level: 'omega' },
  { cmd: 'hack', desc: '[DEEP] Initiate deep scan', usage: 'hack --target TARGET --deep', category: 'DOULATREX', level: 'omega' },
];

export const threatData: ThreatData[] = [
  { id: 't1', name: 'APT29 Cozy Bear', severity: 'critical', type: 'APT', description: 'Russian state-sponsored threat actor targeting government networks', timestamp: new Date().toISOString(), source: 'CISA' },
  { id: 't2', name: 'Lazarus Group', severity: 'critical', type: 'APT', description: 'North Korean threat group targeting financial institutions', timestamp: new Date().toISOString(), source: 'FBI' },
  { id: 't3', name: 'LockBit Ransomware', severity: 'high', type: 'Ransomware', description: 'Ransomware-as-a-Service operation targeting enterprises worldwide', timestamp: new Date().toISOString(), source: 'Europol' },
  { id: 't4', name: 'Cobalt Strike Abuse', severity: 'high', type: 'Tool Abuse', description: 'Cracked Cobalt Strike beacons used by multiple threat actors', timestamp: new Date().toISOString(), source: 'MITRE' },
  { id: 't5', name: 'Log4j Exploitation', severity: 'high', type: 'Vulnerability', description: 'Ongoing exploitation of Log4Shell vulnerability (CVE-2021-44228)', timestamp: new Date().toISOString(), source: 'NIST' },
  { id: 't6', name: 'Phishing-as-a-Service', severity: 'medium', type: 'Trend', description: 'Rise of PhaaS platforms enabling low-skill phishing campaigns', timestamp: new Date().toISOString(), source: 'Group-IB' },
  { id: 't7', name: 'Zero-Day Broker Market', severity: 'medium', type: 'Market', description: 'Growing underground market for zero-day exploits', timestamp: new Date().toISOString(), source: 'Zerodium' },
  { id: 't8', name: 'Critical Infrastructure', severity: 'critical', type: 'Targeting', description: 'Increased targeting of energy and water sectors', timestamp: new Date().toISOString(), source: 'DHS' },
];

export const darkWebSites: DarkWebSite[] = [
  { id: 'd1', name: 'Dread', onion: 'dreadytofatroptsd.onion', category: 'Forum', status: 'online', description: 'Reddit-like darknet discussion forum' },
  { id: 'd2', name: 'The Hidden Wiki', onion: 'zqktlwiuavvvqqt4...onion', category: 'Directory', status: 'online', description: 'Dark web link directory' },
  { id: 'd3', name: 'ProPublica', onion: 'p53lf57qovyuvwsc...onion', category: 'News', status: 'online', description: 'Investigative journalism on dark web' },
  { id: 'd4', name: 'SecureDrop', onion: 'sdolvtfhatvsysc6...onion', category: 'Whistleblowing', status: 'online', description: 'Secure whistleblower submission system' },
  { id: 'd5', name: 'Torch', onion: 'xmh57jrzrnw6insl...onion', category: 'Search Engine', status: 'online', description: 'Dark web search engine' },
  { id: 'd6', name: 'Ahmia', onion: 'juhanurmihxlp77nk...onion', category: 'Search Engine', status: 'online', description: 'Search engine indexing .onion sites' },
  { id: 'd7', name: 'DuckDuckGo', onion: 'duckduckgogg42xj...onion', category: 'Search Engine', status: 'online', description: 'Privacy-focused search engine' },
  { id: 'd8', name: 'Riseup', onion: 'nzh3fv6jc6jskki3...onion', category: 'Email', status: 'online', description: 'Secure email services' },
];

export const agencies: Agency[] = [
  { id: 'a1', name: 'NSA', country: 'USA', type: 'intelligence', description: 'National Security Agency — Signals intelligence (SIGINT) and information assurance', knownTools: ['XKeyscore', 'PRISM', 'TAO', 'GHIDRA', 'FoxAcid'] },
  { id: 'a2', name: 'CIA', country: 'USA', type: 'intelligence', description: 'Central Intelligence Agency — Human intelligence (HUMINT) and covert operations', knownTools: ['Vault7', 'Marble Framework', 'Scribbles', 'HIVE'] },
  { id: 'a3', name: 'FBI', country: 'USA', type: 'cyber', description: 'Federal Bureau of Investigation — Domestic intelligence and cyber crime', knownTools: ['CIPAV', 'NIT', 'Torpedo'] },
  { id: 'a4', name: 'GCHQ', country: 'UK', type: 'intelligence', description: 'Government Communications Headquarters — UK signals intelligence', knownTools: ['TEMPORA', 'EdgeHill', 'BULLRUN'] },
  { id: 'a5', name: 'Mossad', country: 'Israel', type: 'intelligence', description: 'Institute for Intelligence and Special Operations', knownTools: ['Pegasus', 'Duqu', 'Stuxnet (Joint)'] },
  { id: 'a6', name: 'GRU', country: 'Russia', type: 'military', description: 'Main Intelligence Directorate — Russian military intelligence', knownTools: ['APT28', 'X-Agent', 'Industroyer'] },
  { id: 'a7', name: 'MSS', country: 'China', type: 'intelligence', description: 'Ministry of State Security — Chinese intelligence agency', knownTools: ['APT10', 'APT41', 'PlugX'] },
  { id: 'a8', name: 'USCYBERCOM', country: 'USA', type: 'military', description: 'United States Cyber Command', knownTools: ['UnitedKeyboard', 'DACUS', 'CYBERCOM Arsenal'] },
];

export const toolCategories = [
  'Reconnaissance',
  'Exploitation',
  'Post-Exploitation',
  'Wireless',
  'Forensics',
  'Social Engineering',
  'Web Application',
  'Password Cracking',
  'Network Analysis',
  'Anonymity',
  'Cloud Security',
  'IoT/Embedded',
  'Mobile Security',
  'ICS/SCADA',
  'AI/ML Security',
];
