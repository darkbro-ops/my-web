export type AccessLevel = 'public' | 'researcher' | 'classified' | 'omega';

export interface ResearchTool {
  id: string;
  name: string;
  description: string;
  longDescription?: string;
  category: string;
  icon?: string;
  level: AccessLevel;
  commands?: string[];
  url?: string;
  tags?: string[];
  os?: string[];
  usage?: string;
  install?: string;
}

export interface TerminalCommand {
  cmd: string;
  desc: string;
  usage?: string;
  category: string;
  level: AccessLevel;
}

export interface ThreatData {
  id: string;
  name: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  type: string;
  description: string;
  timestamp: string;
  source?: string;
}

export interface DarkWebSite {
  id: string;
  name: string;
  onion: string;
  category: string;
  status: 'online' | 'offline' | 'unknown';
  description: string;
}

export interface Agency {
  id: string;
  name: string;
  country: string;
  type: 'intelligence' | 'military' | 'cyber' | 'surveillance';
  description: string;
  knownTools: string[];
}
