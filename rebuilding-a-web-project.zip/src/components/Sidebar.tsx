import type { ResearchTool } from '../data/types';
import type { AccessLevel } from '../data/types';
import { researchTools } from '../data/categories';

interface Props {
  onSelectTool: (tool: ResearchTool) => void;
  activeToolId: string | null;
  searchTerm: string;
  onSearchChange: (term: string) => void;
  accessLevel: AccessLevel;
  secretsRevealed: Set<string>;
}

export default function Sidebar(props: Props) {
  const { onSelectTool, activeToolId, searchTerm, onSearchChange, accessLevel } = props;
  const filtered = researchTools.filter(t =>
    accessLevel === 'omega' ? true :
    accessLevel === 'classified' ? ['public', 'researcher', 'classified'].includes(t.level) :
    accessLevel === 'researcher' ? ['public', 'researcher'].includes(t.level) :
    t.level === 'public'
  ).filter(t =>
    !searchTerm ||
    t.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.tags?.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const categories = [...new Set(filtered.map(t => t.category))];

  const levelBadge = (level: string) => {
    if (level === 'omega') return 'bg-purple-950/30 text-purple-400 border-purple-500/30';
    if (level === 'classified') return 'bg-red-950/30 text-red-400 border-red-500/30';
    if (level === 'researcher') return 'bg-yellow-950/30 text-yellow-400 border-yellow-500/30';
    return 'bg-green-950/30 text-green-400 border-green-500/30';
  };

  return (
    <div className="bg-black/80 border border-green-900/20 rounded p-3">
      <div className="mb-3">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="🔍 Search 400+ tools..."
          className="w-full px-3 py-1.5 bg-[#020408] border border-green-900/30 rounded text-green-400 text-[10px] outline-none font-mono placeholder-green-800"
        />
      </div>

      <div className="text-[9px] text-green-700 mb-2">
        {filtered.length} tools • {accessLevel.toUpperCase()} access
      </div>

      <div className="max-h-[60vh] overflow-y-auto space-y-3">
        {categories.map(cat => (
          <div key={cat}>
            <h3 className="text-[9px] text-red-400 font-bold mb-1 tracking-wider border-b border-red-900/20 pb-1">
              {cat.toUpperCase()}
            </h3>
            <div className="space-y-0.5">
              {filtered.filter(t => t.category === cat).map(tool => (
                <button
                  key={tool.id}
                  onClick={() => onSelectTool(tool)}
                  className={`w-full text-left px-2 py-1 rounded text-[10px] transition-all flex items-center gap-2 ${
                    activeToolId === tool.id
                      ? 'bg-green-950/20 text-green-300 border border-green-500/20'
                      : 'text-green-500 hover:bg-green-950/10 hover:text-green-400'
                  }`}
                >
                  <span className="text-[11px] w-4 text-center">
                    <i className={`fas ${tool.icon || 'fa-tool'}`} />
                  </span>
                  <span className="flex-1 truncate">{tool.name}</span>
                  <span className={`text-[7px] px-1 py-0.5 rounded border ${levelBadge(tool.level)}`}>
                    {tool.level}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
