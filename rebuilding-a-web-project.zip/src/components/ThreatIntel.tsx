import { useState } from 'react';
import type { AccessLevel } from '../data/types';
import { threatData } from '../data/categories';

interface Props {
  accessLevel: AccessLevel;
}

export default function ThreatIntel({ accessLevel }: Props) {
  const [selected, setSelected] = useState<string | null>(null);

  const severityColor = (s: string) =>
    s === 'critical' ? 'text-red-400 bg-red-950/30 border-red-500/30' :
    s === 'high' ? 'text-orange-400 bg-orange-950/30 border-orange-500/30' :
    s === 'medium' ? 'text-yellow-400 bg-yellow-950/30 border-yellow-500/30' :
    'text-green-400 bg-green-950/30 border-green-500/30';

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-red-500 font-bold text-sm tracking-wider">💀 THREAT INTELLIGENCE — LIVE FEED</h2>
        <span className="text-[9px] text-red-700 animate-pulse">● LIVE</span>
      </div>
      <div className="flex-1 overflow-y-auto space-y-2">
        {threatData.map((t) => (
          <div
            key={t.id}
            onClick={() => setSelected(t.id === selected ? null : t.id)}
            className={`border rounded p-3 cursor-pointer transition-all ${
              t.id === selected
                ? 'border-red-500/50 bg-red-950/10'
                : 'border-green-900/20 bg-green-950/5 hover:border-green-700/30'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className={`px-1.5 py-0.5 text-[8px] font-bold rounded border ${severityColor(t.severity)}`}>
                  {t.severity.toUpperCase()}
                </span>
                <span className="text-green-400 text-xs font-bold">{t.name}</span>
              </div>
              <span className="text-[9px] text-green-700">{t.type}</span>
            </div>
            {t.id === selected && (
              <div className="mt-2 pt-2 border-t border-green-900/20 text-[10px] text-green-600 space-y-1">
                <p>{t.description}</p>
                <div className="flex gap-4 text-[9px] text-green-700">
                  <span>Source: {t.source}</span>
                  <span>ID: {t.id}</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
      {accessLevel === 'omega' && (
        <div className="mt-3 p-3 border border-red-500/20 rounded bg-red-950/10">
          <p className="text-[9px] text-red-400 font-mono">
            🔒 CLASSIFIED: 3 zero-day threats detected in your perimeter. Visit VAULT for details.
          </p>
        </div>
      )}
    </div>
  );
}
