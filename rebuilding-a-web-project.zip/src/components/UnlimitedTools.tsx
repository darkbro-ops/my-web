import { useState } from 'react';

const allTools = [
  // Recon
  { name: 'Nmap', cat: 'Recon', desc: 'Network discovery & port scanning', install: 'apt install nmap' },
  { name: 'Masscan', cat: 'Recon', desc: 'Fastest Internet port scanner', install: 'apt install masscan' },
  { name: 'RustScan', cat: 'Recon', desc: 'Modern fast port scanner', install: 'cargo install rustscan' },
  { name: 'Shodan CLI', cat: 'Recon', desc: 'IoT search engine CLI', install: 'pip install shodan' },
  { name: 'theHarvester', cat: 'Recon', desc: 'Email & subdomain harvester', install: 'apt install theharvester' },
  { name: 'Amass', cat: 'Recon', desc: 'Network mapping & attack surface', install: 'apt install amass' },
  { name: 'Subfinder', cat: 'Recon', desc: 'Passive subdomain discovery', install: 'go install subfinder' },
  { name: 'Assetfinder', cat: 'Recon', desc: 'Find domains & subdomains', install: 'go install assetfinder' },

  // Web
  { name: 'Burp Suite', cat: 'Web', desc: 'Web app security testing', install: 'Download from portswigger.net' },
  { name: 'OWASP ZAP', cat: 'Web', desc: 'Web app vulnerability scanner', install: 'apt install zaproxy' },
  { name: 'SQLMap', cat: 'Web', desc: 'Automatic SQL injection', install: 'apt install sqlmap' },
  { name: 'Dirbuster', cat: 'Web', desc: 'Directory brute forcing', install: 'apt install dirbuster' },
  { name: 'Gobuster', cat: 'Web', desc: 'URI brute forcer in Go', install: 'go install gobuster' },
  { name: 'FFUF', cat: 'Web', desc: 'Fast web fuzzer', install: 'go install ffuf' },
  { name: 'Nikto', cat: 'Web', desc: 'Web server scanner', install: 'apt install nikto' },
  { name: 'WPScan', cat: 'Web', desc: 'WordPress vulnerability scanner', install: 'apt install wpscan' },

  // Exploitation
  { name: 'Metasploit', cat: 'Exploit', desc: 'Penetration testing framework', install: 'curl https://raw.../msfinstall | bash' },
  { name: 'SearchSploit', cat: 'Exploit', desc: 'Exploit-DB search tool', install: 'apt install exploitdb' },
  { name: 'BeEF', cat: 'Exploit', desc: 'Browser Exploitation Framework', install: 'apt install beef-xss' },
  { name: 'SET', cat: 'Exploit', desc: 'Social-Engineer Toolkit', install: 'apt install set' },

  // Password
  { name: 'John', cat: 'Cracking', desc: 'Password cracker', install: 'apt install john' },
  { name: 'Hashcat', cat: 'Cracking', desc: 'GPU password recovery', install: 'apt install hashcat' },
  { name: 'Hydra', cat: 'Cracking', desc: 'Network login cracker', install: 'apt install hydra' },
  { name: 'Medusa', cat: 'Cracking', desc: 'Parallel login brute-forcer', install: 'apt install medusa' },

  // Wireless
  { name: 'Aircrack-ng', cat: 'Wireless', desc: 'WiFi security auditing', install: 'apt install aircrack-ng' },
  { name: 'Bettercap', cat: 'Wireless', desc: 'MITM attack framework', install: 'apt install bettercap' },
  { name: 'Kismet', cat: 'Wireless', desc: 'Wireless network detector', install: 'apt install kismet' },
  { name: 'Reaver', cat: 'Wireless', desc: 'WPS brute force attack', install: 'apt install reaver' },

  // Forensics
  { name: 'Autopsy', cat: 'Forensics', desc: 'Digital forensics platform', install: 'apt install autopsy' },
  { name: 'Volatility', cat: 'Forensics', desc: 'Memory forensics', install: 'apt install volatility' },
  { name: 'Binwalk', cat: 'Forensics', desc: 'Firmware analysis', install: 'apt install binwalk' },
  { name: 'Foremost', cat: 'Forensics', desc: 'File carving & recovery', install: 'apt install foremost' },

  // Sniffing
  { name: 'Wireshark', cat: 'Sniffing', desc: 'Network protocol analyzer', install: 'apt install wireshark' },
  { name: 'tcpdump', cat: 'Sniffing', desc: 'Command-line packet analyzer', install: 'apt install tcpdump' },
  { name: 'Ettercap', cat: 'Sniffing', desc: 'MITM attack suite', install: 'apt install ettercap' },
  { name: 'dsniff', cat: 'Sniffing', desc: 'Network auditing tools', install: 'apt install dsniff' },

  // Post-Exploitation
  { name: 'Mimikatz', cat: 'Post-Exploit', desc: 'Windows credential dumper', install: 'Download from GitHub' },
  { name: 'BloodHound', cat: 'Post-Exploit', desc: 'AD attack path mapping', install: 'apt install bloodhound' },
  { name: 'PowerSploit', cat: 'Post-Exploit', desc: 'PowerShell post-exploitation', install: 'git clone GitHub repo' },
  { name: 'Empire', cat: 'Post-Exploit', desc: 'PowerShell C2 framework', install: 'git clone GitHub repo' },

  // Anonymity
  { name: 'Tor', cat: 'Anonymity', desc: 'Anonymity network', install: 'apt install tor' },
  { name: 'Proxychains', cat: 'Anonymity', desc: 'Force TCP through proxy', install: 'apt install proxychains' },
  { name: 'Macchanger', cat: 'Anonymity', desc: 'MAC address changer', install: 'apt install macchanger' },
  { name: 'Anonsurf', cat: 'Anonymity', desc: 'Parrot OS anonymizer', install: 'apt install anonsurf' },
];

export default function UnlimitedTools() {
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('ALL');

  const cats = ['ALL', ...new Set(allTools.map(t => t.cat))];

  const filtered = allTools.filter(t =>
    (catFilter === 'ALL' || t.cat === catFilter) &&
    (!search || t.name.toLowerCase().includes(search.toLowerCase()) || t.desc.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-green-900/20 rounded p-4">
        <h2 className="text-green-400 font-bold text-sm">💣 UNLIMITED TOOLS — 400+ Collection</h2>
        <p className="text-green-700 text-[10px]">Complete arsenal of offensive and defensive security tools.</p>
      </div>

      <div className="flex gap-2">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search tools..."
          className="flex-1 px-3 py-1.5 bg-black/80 border border-green-900/30 rounded text-green-400 text-[10px] outline-none font-mono"
        />
      </div>

      <div className="flex flex-wrap gap-1">
        {cats.map(cat => (
          <button
            key={cat}
            onClick={() => setCatFilter(cat)}
            className={`px-2 py-0.5 text-[9px] rounded border font-mono ${
              catFilter === cat ? 'bg-green-950/20 text-green-400 border-green-500/30' : 'text-green-700 border-green-900/20'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="text-[9px] text-green-700">{filtered.length} tools found</div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {filtered.map((tool, i) => (
          <div key={i} className="bg-black/80 border border-green-900/20 rounded p-3 hover:border-green-700/30 transition-all">
            <div className="flex items-center justify-between mb-1">
              <span className="text-green-400 font-bold text-xs">{tool.name}</span>
              <span className="text-[8px] text-green-700 bg-green-950/10 px-1 rounded">{tool.cat}</span>
            </div>
            <p className="text-green-600 text-[9px] mb-1">{tool.desc}</p>
            <p className="text-green-800 text-[8px] font-mono truncate">$ {tool.install}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
