import { useState } from 'react';
import type { AccessLevel } from '../data/types';
import { nuclearArsenal } from '../data/enhanced';

interface Props { accessLevel: AccessLevel; }

export default function NuclearArsenal({ accessLevel }: Props) {
  const [selected, setSelected] = useState<string | null>(null);
  const [countryFilter, setCountryFilter] = useState('ALL');

  const countries = ['ALL', ...new Set(nuclearArsenal.map(n => n.country))];
  const filtered = countryFilter === 'ALL' ? nuclearArsenal : nuclearArsenal.filter(n => n.country === countryFilter);
  const visible = filtered.filter(n => {
    if (accessLevel === 'omega') return true;
    if (accessLevel === 'classified') return n.level !== 'omega';
    return n.level === 'public' || n.level === 'researcher';
  });

  const typeIcon = (type: string) => type === 'ICBM' ? '🚀' : type === 'SLBM' ? '🌊' : type === 'Strategic Bomber' ? '✈️' : type === 'Hypersonic' ? '⚡' : type === 'MIRV' ? '🎯' : '💣';

  return (
    <div className="h-full bg-[#050508] p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-red-500 font-bold text-sm tracking-wider">☢ NUCLEAR ARSENAL — GLOBAL NUCLEAR WEAPONS DATABASE</h2>
        <span className={`text-[9px] font-bold animate-pulse ${accessLevel === 'omega' ? 'text-purple-400' : 'text-red-400'}`}>
          {accessLevel === 'omega' ? '● OMEGA CLEARANCE' : `● ${accessLevel.toUpperCase()}`}
        </span>
      </div>

      <div className="flex gap-1 flex-wrap mb-3">
        {countries.map(c => (
          <button key={c} onClick={() => setCountryFilter(c)}
            className={`px-2 py-0.5 text-[9px] rounded border font-mono ${countryFilter === c ? 'bg-red-950/20 text-red-400 border-red-500/30' : 'text-green-700 border-green-900/20 hover:text-green-500'}`}>
            {c === 'ALL' ? '🌍 ALL' : c} {c !== 'ALL' && `(${filtered.filter(n => n.country === c).length})`}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto space-y-2">
        {visible.map(n => (
          <div key={n.id} onClick={() => setSelected(selected === n.id ? null : n.id)}
            className={`border rounded p-3 cursor-pointer transition-all ${
              n.level === 'omega' ? 'border-purple-500/20 bg-purple-950/5' :
              n.level === 'classified' ? 'border-red-500/20 bg-red-950/5' :
              'border-green-900/20 bg-green-950/5 hover:border-red-700/30'
            } ${selected === n.id ? 'border-red-500/50' : ''}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xl">{typeIcon(n.type)}</span>
                <div>
                  <span className="text-green-400 text-xs font-bold">{n.name}</span>
                  <span className="text-green-700 text-[9px] ml-2">{n.country}</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {n.level === 'omega' && <span className="text-[7px] bg-purple-950/30 text-purple-400 px-1 rounded border border-purple-500/20">Ω</span>}
                <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${n.status === 'Active' ? 'bg-green-950/20 text-green-400' : n.status === 'Developing' ? 'bg-yellow-950/20 text-yellow-400' : 'bg-red-950/10 text-red-400'}`}>{n.status}</span>
              </div>
            </div>
            {selected === n.id && (
              <div className="mt-2 pt-2 border-t border-green-900/20">
                <div className="grid grid-cols-2 gap-1 text-[10px]">
                  <div className="text-green-600">Type: <span className="text-green-400">{n.type}</span></div>
                  <div className="text-green-600">Warheads: <span className="text-yellow-400 font-bold">{n.warheads}</span></div>
                  <div className="text-green-600">Yield: <span className="text-red-400">{n.yield_kt} kt</span></div>
                  <div className="text-green-600">Range: <span className="text-cyan-400">{n.range_km} km</span></div>
                </div>
                <p className="text-[9px] text-green-600 mt-2">{n.description}</p>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-2 grid grid-cols-4 gap-1 text-center text-[8px]">
        <div className="p-1.5 border border-red-900/20 rounded"><div className="text-red-400 font-bold">{nuclearArsenal.length}</div><div className="text-red-700">Systems</div></div>
        <div className="p-1.5 border border-red-900/20 rounded"><div className="text-red-400 font-bold">9</div><div className="text-red-700">Nations</div></div>
        <div className="p-1.5 border border-red-900/20 rounded"><div className="text-red-400 font-bold">~12,500</div><div className="text-red-700">Warheads</div></div>
        <div className="p-1.5 border border-red-900/20 rounded"><div className="text-red-400 font-bold">Classified</div><div className="text-red-700">Active</div></div>
      </div>
    </div>
  );
}
