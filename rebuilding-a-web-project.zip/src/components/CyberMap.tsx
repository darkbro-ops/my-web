import { useState, useEffect } from 'react';

export default function CyberMap() {
  const [pings, setPings] = useState<{x:number;y:number;id:number}[]>([]);
  const [activeNodes, setActiveNodes] = useState<{x:number;y:number;label:string;color:string}[]>([]);

  useEffect(() => {
    const nodes = [
      { x: 20, y: 30, label: 'US-CERT', color: '#00ff00' },
      { x: 22, y: 33, label: 'NSA HQ', color: '#ff0000' },
      { x: 48, y: 28, label: 'GCHQ', color: '#ff0000' },
      { x: 52, y: 30, label: 'Europol', color: '#00ff00' },
      { x: 70, y: 25, label: 'GRU', color: '#ff4444' },
      { x: 75, y: 35, label: 'MSS', color: '#ff4444' },
      { x: 85, y: 30, label: 'NPA', color: '#ff4444' },
      { x: 35, y: 45, label: 'Mossad', color: '#ffff00' },
      { x: 30, y: 55, label: 'ASD', color: '#00ff00' },
      { x: 60, y: 50, label: 'RAW', color: '#ffff00' },
      { x: 25, y: 42, label: 'CSE', color: '#00ff00' },
      { x: 55, y: 42, label: 'BND', color: '#00ff00' },
      { x: 45, y: 60, label: 'DGSE', color: '#00ff00' },
      { x: 80, y: 55, label: 'DSD', color: '#00ff00' },
    ];
    setActiveNodes(nodes);

    const interval = setInterval(() => {
      setPings(prev => {
        const next = [...prev];
        if (next.length > 30) next.splice(0, 5);
        next.push({
          x: Math.random() * 80 + 10,
          y: Math.random() * 40 + 20,
          id: Date.now()
        });
        return next;
      });
    }, 500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-green-500 font-bold text-sm tracking-wider">🌍 GLOBAL CYBER MAP — LIVE</h2>
        <div className="flex items-center gap-3 text-[9px]">
          <span className="text-green-600"><span className="text-green-400">●</span> Allied</span>
          <span className="text-green-600"><span className="text-red-400">●</span> Adversary</span>
          <span className="text-green-600"><span className="text-yellow-400">●</span> Neutral</span>
        </div>
      </div>
      <div className="flex-1 relative bg-[#020408] rounded border border-green-900/20 overflow-hidden" style={{ minHeight: '400px' }}>
        {/* World map SVG approximation */}
        <svg viewBox="0 0 100 65" className="w-full h-full opacity-30" style={{ position: 'absolute', inset: 0 }}>
          <ellipse cx="20" cy="30" rx="12" ry="18" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <ellipse cx="48" cy="28" rx="10" ry="8" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <ellipse cx="55" cy="35" rx="5" ry="7" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <ellipse cx="75" cy="30" rx="14" ry="15" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <ellipse cx="28" cy="52" rx="6" ry="8" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <ellipse cx="50" cy="52" rx="5" ry="6" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <ellipse cx="18" cy="50" rx="3" ry="4" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <ellipse cx="65" cy="52" rx="4" ry="4" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <ellipse cx="82" cy="48" rx="4" ry="5" fill="none" stroke="#0f0" strokeWidth="0.2"/>
          <line x1="20" y1="24" x2="22" y2="33" stroke="#0f0" strokeWidth="0.1" opacity="0.5"/>
          <line x1="22" y1="33" x2="48" y2="28" stroke="#0f0" strokeWidth="0.1" opacity="0.5"/>
          <line x1="48" y1="28" x2="52" y2="30" stroke="#0f0" strokeWidth="0.1" opacity="0.5"/>
          <line x1="52" y1="30" x2="70" y2="25" stroke="#0f0" strokeWidth="0.1" opacity="0.5"/>
          <line x1="70" y1="25" x2="75" y2="35" stroke="#0f0" strokeWidth="0.1" opacity="0.5"/>
          <line x1="75" y1="35" x2="85" y2="30" stroke="#0f0" strokeWidth="0.1" opacity="0.5"/>
          <line x1="22" y1="33" x2="35" y2="45" stroke="#0f0" strokeWidth="0.1" opacity="0.5"/>
        </svg>

        {/* Active nodes */}
        {activeNodes.map((node, i) => (
          <div
            key={i}
            className="absolute w-3 h-3 rounded-full animate-pulse"
            style={{
              left: `${node.x}%`,
              top: `${node.y}%`,
              backgroundColor: node.color,
              boxShadow: `0 0 8px ${node.color}`,
              transform: 'translate(-50%, -50%)'
            }}
            title={node.label}
          />
        ))}

        {/* Live pings */}
        {pings.map((ping) => (
          <div
            key={ping.id}
            className="absolute animate-ping"
            style={{
              left: `${ping.x}%`,
              top: `${ping.y}%`,
              width: '8px',
              height: '8px',
              backgroundColor: '#00ff00',
              borderRadius: '50%',
              transform: 'translate(-50%, -50%)',
              animationDuration: '1s'
            }}
          />
        ))}

        {/* Labels */}
        {activeNodes.map((node, i) => (
          <div
            key={`label-${i}`}
            className="absolute text-[8px] font-mono"
            style={{
              left: `${node.x}%`,
              top: `${node.y + 2}%`,
              color: node.color,
              transform: 'translate(-50%, 0)',
              textShadow: `0 0 5px ${node.color}`
            }}
          >
            {node.label}
          </div>
        ))}
      </div>
      <div className="mt-2 grid grid-cols-4 gap-2 text-[9px] text-green-700">
        <div>NODES: {activeNodes.length}</div>
        <div>PINGS/MIN: {Math.floor(Math.random() * 500 + 200)}</div>
        <div>THREATS: {Math.floor(Math.random() * 15 + 3)}</div>
        <div>COVERAGE: GLOBAL</div>
      </div>
    </div>
  );
}
