import { useState } from 'react';

const cloudPlatforms = [
  { name: 'AWS', icon: 'fa-aws', color: 'text-yellow-400', desc: 'Amazon Web Services — EC2, S3, Lambda, IAM', commands: ['aws ec2 describe-instances', 'aws s3 ls', 'aws iam list-users'] },
  { name: 'Azure', icon: 'fa-microsoft', color: 'text-blue-400', desc: 'Microsoft Azure — VMs, Blob Storage, Functions', commands: ['az vm list', 'az storage account list', 'az ad user list'] },
  { name: 'GCP', icon: 'fa-google', color: 'text-red-400', desc: 'Google Cloud Platform — Compute, GCS, Cloud Functions', commands: ['gcloud compute instances list', 'gsutil ls', 'gcloud iam service-accounts list'] },
  { name: 'DigitalOcean', icon: 'fa-digital-ocean', color: 'text-cyan-400', desc: 'Droplets, Spaces, Kubernetes', commands: ['doctl compute droplet list', 'doctl kubernetes cluster list'] },
  { name: 'Kubernetes', icon: 'fa-dharmachakra', color: 'text-purple-400', desc: 'Container orchestration — Pods, Services, Deployments', commands: ['kubectl get pods', 'kubectl get svc', 'kubectl describe deployment'] },
  { name: 'Docker', icon: 'fa-docker', color: 'text-blue-400', desc: 'Container platform — Images, Containers, Compose', commands: ['docker ps', 'docker images', 'docker-compose up -d'] },
];

export default function CloudDeployment() {
  const [active, setActive] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-green-900/20 rounded p-4">
        <h2 className="text-cyan-400 font-bold text-sm">☁️ CLOUD DEPLOYMENT</h2>
        <p className="text-green-700 text-[10px]">Deploy and manage cloud infrastructure across platforms.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {cloudPlatforms.map(platform => (
          <div
            key={platform.name}
            onClick={() => setActive(active === platform.name ? null : platform.name)}
            className={`border rounded p-4 cursor-pointer transition-all ${
              active === platform.name
                ? 'border-cyan-500/30 bg-cyan-950/5'
                : 'border-green-900/20 bg-black/80 hover:border-cyan-700/30'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <i className={`fab ${platform.icon} text-xl ${platform.color}`} />
              <h3 className={`font-bold text-xs ${platform.color}`}>{platform.name}</h3>
            </div>
            <p className="text-green-700 text-[9px]">{platform.desc}</p>
            {active === platform.name && (
              <div className="mt-3 pt-3 border-t border-green-900/20 space-y-1">
                {platform.commands.map((cmd, i) => (
                  <div key={i} className="p-1.5 bg-[#020408] rounded font-mono text-[9px] text-green-400">
                    $ {cmd}
                  </div>
                ))}
                <button className="w-full mt-2 py-1.5 bg-cyan-950/20 border border-cyan-500/20 rounded text-cyan-400 text-[10px] font-bold hover:bg-cyan-950/30">
                  DEPLOY INSTANCE
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
