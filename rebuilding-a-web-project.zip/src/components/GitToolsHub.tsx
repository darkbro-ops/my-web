import { useState } from 'react';
import { allGitTools, gitToolCategories } from '../data/gitclonetools';

export default function GitToolsHub() {
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('ALL');
  const [selected, setSelected] = useState<string|null>(null);
  const [copied, setCopied] = useState('');

  const filtered = allGitTools.filter(t=>(cat==='ALL'||t.category===cat)&&(!search||t.name.toLowerCase().includes(search.toLowerCase())||t.desc.toLowerCase().includes(search.toLowerCase())||t.tags.some(tg=>tg.toLowerCase().includes(search.toLowerCase()))));

  const copy=(c:string)=>{navigator.clipboard.writeText(c);setCopied(c);setTimeout(()=>setCopied(''),1500);};

  return (
    <div className="space-y-4 animate-fadein">
      <div className="card border-red-900/20 p-4">
        <h2 className="text-3xl font-black text-white" style={{fontFamily:'Impact, sans-serif'}}>GIT CLONE TOOLS</h2>
        <p className="text-gray-500 text-sm mt-1">Every tool installs with ONE git clone command — no dependency hell</p>
      </div>

      <div className="flex gap-2">
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search tools..." className="flex-1 px-4 py-2 bg-[#0a0a12] border border-[#181830] rounded text-white text-sm outline-none"/>
      </div>

      <div className="flex flex-wrap gap-1">
        <button onClick={()=>setCat('ALL')} className={`px-2.5 py-1 text-[10px] font-bold rounded border ${cat==='ALL'?'bg-red-950/20 text-red-400 border-red-500/30':'text-gray-600 border-[#181830]'}`}>ALL ({allGitTools.length})</button>
        {gitToolCategories.map(ct=>(
          <button key={ct.id} onClick={()=>setCat(ct.id)} className={`px-2.5 py-1 text-[10px] font-bold rounded border ${cat===ct.id?'text-white border-opacity-40':'text-gray-600 border-[#181830]'}`} style={cat===ct.id?{borderColor:ct.color,color:ct.color,backgroundColor:`${ct.color}15`}:{}}>{ct.label} ({ct.count})</button>
        ))}
      </div>

      <div className="text-gray-600 text-xs">{filtered.length} tools</div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {filtered.map(t=>{
          const isOpen=selected===t.name;
          return(
            <div key={t.name} onClick={()=>setSelected(isOpen?null:t.name)} className={`card p-3 cursor-pointer transition-all ${isOpen?'border-[#00e0ff]/40':''}`}>
              <div className="flex items-start justify-between mb-1">
                <div className="flex-1 min-w-0">
                  <span className="text-white font-black text-sm block">{t.name}</span>
                  <span className="text-[10px] text-gray-500">{t.category}</span>
                </div>
                <span className="tag tag-green text-[7px] flex-shrink-0">{t.stars}</span>
              </div>
              <p className="text-[10px] text-gray-400 mb-1.5">{t.desc}</p>
              <div className="flex flex-wrap gap-0.5">
                {t.tags.map(tg=>(<span key={tg} className="tag tag-cyan text-[7px]">{tg}</span>))}
              </div>

              {isOpen&&(
                <div className="mt-2 pt-2 border-t border-[#181830] space-y-2">
                  <div>
                    <span className="text-[9px] text-gray-500 font-bold">📥 GIT CLONE:</span>
                    <div className="code text-[10px] mt-0.5 group cursor-pointer relative py-1.5" onClick={e=>{e.stopPropagation();copy(t.gitClone);}}>
                      $ {t.gitClone}
                      <button className="absolute right-1 top-0.5 text-[8px] px-1.5 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-gray-400 opacity-0 group-hover:opacity-100">{copied===t.gitClone?'✓':'COPY'}</button>
                    </div>
                  </div>
                  <div>
                    <span className="text-[9px] text-gray-500 font-bold">⚙️ INSTALL STEPS:</span>
                    {t.installAfter.map((s,i)=>(<div key={i} className="code text-[10px] mt-0.5">$ {s}</div>))}
                  </div>
                  <div>
                    <span className="text-[9px] text-gray-500 font-bold">💻 USAGE:</span>
                    {t.usage.map((u,i)=>(<div key={i} className="code text-[10px] mt-0.5 group cursor-pointer relative py-1" onClick={e=>{e.stopPropagation();copy(u);}}>$ {u}<button className="absolute right-1 top-0.5 text-[8px] px-1.5 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-gray-400 opacity-0 group-hover:opacity-100">{copied===u?'✓':'COPY'}</button></div>))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
