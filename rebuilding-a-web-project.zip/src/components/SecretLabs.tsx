import type { AccessLevel } from '../data/types';

interface Props {
  accessLevel: AccessLevel;
  secretsRevealed: Set<string>;
  onClose: () => void;
  onUnlock: (id: string) => void;
}

const secrets = [
  { id: 'founder', name: 'FOUNDER VAULT', icon: 'fa-crown', desc: 'Secret vault of Mr. Doulat Kumar — Founder of DOULATREX', color: 'text-yellow-400 border-yellow-500/30', unlockedBy: 'Type "doulat"' },
  { id: 'omega_protocol', name: 'OMEGA PROTOCOL', icon: 'fa-skull', desc: 'Top-level Omega classified operations and tools', color: 'text-purple-400 border-purple-500/30', unlockedBy: 'Type "omega"' },
  { id: 'zero_day', name: 'ZERO-DAY VAULT', icon: 'fa-bomb', desc: 'Collection of undisclosed zero-day exploits', color: 'text-red-400 border-red-500/30', unlockedBy: 'Omega access' },
  { id: 'dark_net', name: 'DARK NET MAP', icon: 'fa-mask', desc: 'Complete map of dark web infrastructure', color: 'text-purple-400 border-purple-500/30', unlockedBy: 'Classified access' },
];

export default function SecretLabs({ accessLevel, secretsRevealed, onClose }: Props) {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/90 backdrop-blur">
      <div className="w-full max-w-lg mx-4 bg-[#0a0a0a] border-2 border-red-500/30 rounded-lg overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 bg-red-950/20 border-b border-red-500/20">
          <div className="flex items-center gap-2">
            <span className="text-lg">🔒</span>
            <h2 className="text-red-400 font-black text-sm tracking-wider">SECRET LABS</h2>
          </div>
          <button onClick={onClose} className="text-red-400 hover:text-red-300 text-lg">✕</button>
        </div>

        <div className="p-4 space-y-3 max-h-[60vh] overflow-y-auto">
          <p className="text-green-600 text-[10px]">
            Welcome to the secret labs, <span className="text-red-400 font-bold">{accessLevel.toUpperCase()}</span> clearance.
            {accessLevel !== 'omega' && <span className="text-yellow-400"> Some areas require higher access.</span>}
          </p>

          {secrets.map(secret => {
            const revealed = secretsRevealed.has(secret.id);
            return (
              <div
                key={secret.id}
                className={`border rounded p-3 ${revealed ? 'bg-green-950/5 border-green-500/30' : 'bg-black border-red-900/20'}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <i className={`fas ${secret.icon} ${revealed ? 'text-green-400' : 'text-red-400'}`} />
                    <span className={`text-xs font-bold ${revealed ? 'text-green-400' : 'text-red-400'}`}>
                      {secret.name}
                    </span>
                  </div>
                  <span className={`text-[8px] ${revealed ? 'text-green-600' : 'text-red-600'}`}>
                    {revealed ? '✓ UNLOCKED' : '🔒 LOCKED'}
                  </span>
                </div>
                {revealed ? (
                  <div className="mt-2 pt-2 border-t border-green-900/20">
                    <p className="text-[10px] text-green-600">{secret.desc}</p>
                    <p className="text-[8px] text-green-500 mt-1">✅ Successfully unlocked</p>
                  </div>
                ) : (
                  <div className="mt-2 pt-2 border-t border-red-900/10">
                    <p className="text-[9px] text-red-600">🔐 {secret.unlockedBy}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="px-4 py-2 border-t border-red-500/20 text-[8px] text-red-600 text-center">
          CTRL+SHIFT+X to toggle • {secretsRevealed.size}/{secrets.length} secrets revealed
        </div>
      </div>
    </div>
  );
}
