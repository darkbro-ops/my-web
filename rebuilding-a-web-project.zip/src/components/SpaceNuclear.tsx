import { useState, useEffect } from 'react';

export default function SpaceNuclear() {
  const [nukeStatus, setNukeStatus] = useState<'armed' | 'disarmed' | 'launching'>('disarmed');
  const [launchCode, setLaunchCode] = useState('');
  const [warning, setWarning] = useState('');
  const [countdown, setCountdown] = useState<number | null>(null);
  const [spaceObjects, setSpaceObjects] = useState<{name:string;orbit:string;type:string}[]>([]);

  useEffect(() => {
    setSpaceObjects([
      { name: 'ISS', orbit: 'LEO 408km', type: 'Station' },
      { name: 'Hubble', orbit: 'LEO 547km', type: 'Telescope' },
      { name: 'GPS III-5', orbit: 'MEO 20,200km', type: 'Navigation' },
      { name: 'KH-11', orbit: 'LEO 250km', type: 'Recon' },
      { name: 'Starlink-1847', orbit: 'LEO 550km', type: 'Comm' },
      { name: 'X-37B', orbit: 'LEO 380km', type: 'Military' },
      { name: 'JLENS', orbit: 'LEO 300km', type: 'Surveillance' },
      { name: 'AEHF-5', orbit: 'GEO 35,786km', type: 'Military Comm' },
    ]);
  }, []);

  useEffect(() => {
    if (countdown !== null && countdown > 0) {
      const t = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(t);
    } else if (countdown === 0) {
      setNukeStatus('disarmed');
      setCountdown(null);
      setWarning('LAUNCH ABORTED — Simulation only');
    }
  }, [countdown]);

  const armNuke = () => {
    if (launchCode === 'DOULAT-OMEGA-007') {
      setNukeStatus('armed');
      setWarning('⚠ NUCLEAR SYSTEMS ARMED ⚠');
    } else {
      setWarning('INVALID LAUNCH CODE');
      setTimeout(() => setWarning(''), 2000);
    }
  };

  const launch = () => {
    if (nukeStatus === 'armed') {
      setNukeStatus('launching');
      setCountdown(10);
      setWarning('🚀 LAUNCH SEQUENCE INITIATED 🚀');
    }
  };

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-cyan-400 font-bold text-sm tracking-wider">🚀 SPACE & NUCLEAR COMMAND</h2>
        <span className={`text-[9px] font-bold ${
          nukeStatus === 'armed' ? 'text-red-400 animate-pulse' :
          nukeStatus === 'launching' ? 'text-yellow-400 animate-pulse' :
          'text-cyan-600'
        }`}>
          {nukeStatus.toUpperCase()}
        </span>
      </div>

      <div className="flex-1 flex gap-4">
        {/* Space Objects */}
        <div className="flex-1">
          <h3 className="text-[10px] text-cyan-500 font-bold mb-2">🛰 ORBITAL ASSETS</h3>
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {spaceObjects.map((obj, i) => (
              <div key={i} className="flex items-center justify-between p-1.5 border border-cyan-900/20 rounded text-[9px]">
                <span className="text-cyan-400">{obj.name}</span>
                <span className="text-cyan-700">{obj.orbit}</span>
                <span className="text-[8px] text-cyan-600">{obj.type}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Nuclear Panel */}
        <div className="w-64 border border-red-500/20 rounded p-3 bg-red-950/5">
          <h3 className="text-[10px] text-red-400 font-bold mb-3 text-center">☢ NUCLEAR CONTROL</h3>

          <div className="space-y-2">
            <input
              type="text"
              value={launchCode}
              onChange={(e) => setLaunchCode(e.target.value)}
              placeholder="Launch code..."
              className="w-full px-2 py-1 bg-black border border-red-500/30 rounded text-red-400 text-[10px] outline-none font-mono"
            />
            <button
              onClick={armNuke}
              disabled={nukeStatus !== 'disarmed'}
              className="w-full py-1.5 bg-red-950/30 border border-red-500/30 rounded text-red-400 hover:bg-red-950/50 text-[10px] font-bold disabled:opacity-30"
            >
              ARM SYSTEM
            </button>
            <button
              onClick={launch}
              disabled={nukeStatus !== 'armed'}
              className="w-full py-1.5 bg-red-950/50 border border-red-500/50 rounded text-red-300 hover:bg-red-900/30 text-[10px] font-bold disabled:opacity-30"
            >
              🚀 LAUNCH
            </button>
            <button
              onClick={() => { setNukeStatus('disarmed'); setLaunchCode(''); setWarning(''); setCountdown(null); }}
              className="w-full py-1.5 bg-green-950/20 border border-green-500/20 rounded text-green-400 hover:bg-green-950/30 text-[10px] font-bold"
            >
              DISARM
            </button>
          </div>

          {warning && (
            <div className="mt-2 p-2 border border-yellow-500/30 rounded bg-yellow-950/10 text-[9px] text-yellow-400 font-mono animate-pulse text-center">
              {warning}
            </div>
          )}

          {countdown !== null && (
            <div className="mt-2 text-center">
              <span className="text-4xl font-black text-red-400 animate-pulse">{countdown}</span>
            </div>
          )}

          <p className="text-[7px] text-red-700 mt-3 text-center">Hint: DOULAT-OMEGA-007</p>
        </div>
      </div>
    </div>
  );
}
