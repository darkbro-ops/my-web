import { useState } from 'react';

export default function TorGateway() {
  const [connected, setConnected] = useState(false);
  const [connecting, setConnecting] = useState(false);
  const [nodeInfo, setNodeInfo] = useState<{guard:string;middle:string;exit:string} | null>(null);
  const [circuitId, setCircuitId] = useState('');

  const connect = () => {
    setConnecting(true);
    const guards = ['DE-Berlin', 'NL-Amsterdam', 'CH-Zurich', 'FR-Paris'];
    const middles = ['SE-Stockholm', 'CA-Toronto', 'JP-Tokyo', 'UK-London'];
    const exits = ['US-NewYork', 'IS-Reykjavik', 'AU-Sydney', 'BR-SaoPaulo'];

    setTimeout(() => {
      const guard = guards[Math.floor(Math.random() * guards.length)];
      const middle = middles[Math.floor(Math.random() * middles.length)];
      const exit = exits[Math.floor(Math.random() * exits.length)];
      setNodeInfo({ guard, middle, exit });
      setCircuitId('DOULATREX-' + Math.random().toString(36).substring(2, 8).toUpperCase());
      setConnected(true);
      setConnecting(false);
    }, 2000);
  };

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-purple-400 font-bold text-sm tracking-wider">🧅 TOR GATEWAY</h2>
        <span className={`text-[9px] ${connected ? 'text-green-400' : 'text-red-400'}`}>
          {connected ? '● CONNECTED' : '○ DISCONNECTED'}
        </span>
      </div>

      {!connected ? (
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-6xl mb-4">🧅</div>
          <p className="text-purple-400 text-sm font-bold mb-2">TOR Gateway</p>
          <p className="text-green-700 text-xs mb-6 text-center max-w-sm">
            Route your traffic through the TOR anonymity network.
            3 encrypted hops for maximum privacy.
          </p>
          <button
            onClick={connect}
            disabled={connecting}
            className="px-8 py-3 bg-purple-950/30 border border-purple-500/30 rounded text-purple-400 hover:bg-purple-950/50 transition-all disabled:opacity-50 text-sm font-bold"
          >
            {connecting ? 'ESTABLISHING CIRCUIT...' : 'CONNECT TO TOR'}
          </button>
        </div>
      ) : (
        <div className="flex-1 space-y-4">
          {/* Circuit Info */}
          <div className="border border-purple-500/20 rounded p-4 bg-purple-950/5">
            <h3 className="text-purple-400 text-xs font-bold mb-3">🔗 TOR CIRCUIT</h3>
            <div className="flex items-center justify-between mb-2">
              <div className="text-center">
                <div className="text-[9px] text-green-700">YOU</div>
                <div className="text-green-400 text-xs">🖥</div>
              </div>
              <div className="text-green-600">→</div>
              <div className="text-center">
                <div className="text-[9px] text-purple-600">GUARD</div>
                <div className="text-purple-400 text-xs">🛡</div>
                <div className="text-[8px] text-purple-600">{nodeInfo?.guard}</div>
              </div>
              <div className="text-green-600">→</div>
              <div className="text-center">
                <div className="text-[9px] text-purple-600">MIDDLE</div>
                <div className="text-purple-400 text-xs">🔀</div>
                <div className="text-[8px] text-purple-600">{nodeInfo?.middle}</div>
              </div>
              <div className="text-green-600">→</div>
              <div className="text-center">
                <div className="text-[9px] text-purple-600">EXIT</div>
                <div className="text-purple-400 text-xs">🚪</div>
                <div className="text-[8px] text-purple-600">{nodeInfo?.exit}</div>
              </div>
              <div className="text-green-600">→</div>
              <div className="text-center">
                <div className="text-[9px] text-green-700">DEST</div>
                <div className="text-green-400 text-xs">🌐</div>
              </div>
            </div>
            <div className="text-[9px] text-green-700 font-mono mt-2">Circuit ID: {circuitId}</div>
          </div>

          {/* Features */}
          <div className="grid grid-cols-2 gap-2">
            {[
              { icon: '🔒', label: 'ENCRYPTION', value: 'AES-256-GCM' },
              { icon: '🔄', label: 'HOPS', value: '3 Layers' },
              { icon: '📡', label: 'BANDWIDTH', value: '10 MB/s' },
              { icon: '🕐', label: 'LATENCY', value: '~300ms' },
            ].map((f, i) => (
              <div key={i} className="p-2 border border-purple-900/20 rounded text-center">
                <div className="text-lg">{f.icon}</div>
                <div className="text-[9px] text-purple-500">{f.label}</div>
                <div className="text-[10px] text-purple-400 font-bold">{f.value}</div>
              </div>
            ))}
          </div>

          <button
            onClick={() => { setConnected(false); setNodeInfo(null); setCircuitId(''); }}
            className="w-full py-2 bg-red-950/20 border border-red-500/20 rounded text-red-400 hover:bg-red-950/30 text-xs font-bold"
          >
            DISCONNECT
          </button>
        </div>
      )}
    </div>
  );
}
