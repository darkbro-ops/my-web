import { useState } from 'react';
import { dockerContainers } from '../data/shadowsect';

export default function SHDockerLab() {
  const [selected, setSelected] = useState<string|null>(null);
  const [copied, setCopied] = useState('');

  const copy = (c:string)=>{navigator.clipboard.writeText(c);setCopied(c);setTimeout(()=>setCopied(''),1500);};

  return (
    <div className="space-y-4 animate-fadein">
      <div className="card-glow-cyan p-4"><h2 className="text-white font-black text-sm">🐳 SHADOW DOCKER LAB — 12 Security Containers</h2><p className="text-[#8888a0] text-[10px] mt-1">One-command deploy vulnerable labs, pentesting OS, and training environments via Docker.</p></div>

      {/* Docker Quick Install */}
      <div className="card-dark p-3">
        <div className="flex items-center gap-2 mb-2"><span className="text-xl">⚡</span><span className="text-white font-bold text-xs">DOCKER QUICK INSTALL</span></div>
        <div className="code-block text-[10px] group cursor-pointer" onClick={()=>copy('curl -fsSL https://get.docker.com | sudo sh && sudo usermod -aG docker $USER')}>
          $ curl -fsSL https://get.docker.com | sudo sh && sudo usermod -aG docker $USER
          <button className="absolute right-2 top-1 text-[8px] btn-cyan">{copied?'✓':'COPY'}</button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {dockerContainers.map(dc=>(
          <div key={dc.name} onClick={()=>setSelected(selected===dc.name?null:dc.name)}
            className={`card-dark p-3 cursor-pointer ${selected===dc.name?'ring-1 ring-[#00d4ff]/30':''}`}>
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-white font-bold text-xs">{dc.name}</span>
              <span className="text-[8px] text-[#5a5a72]">{dc.size}</span>
            </div>
            <code className="text-[9px] text-[#b388ff] block mb-1">{dc.image}</code>
            <p className="text-[10px] text-[#8888a0] mb-1">{dc.desc}</p>
            {dc.ports!=='N/A' && <span className="tag tag-red text-[7px]">PORTS: {dc.ports}</span>}

            {selected===dc.name && (
              <div className="mt-2 pt-2 border-t border-[#1e1e30] space-y-1.5">
                {dc.commands.map((c,i)=>(<div key={i} className="code-block text-[9px] py-1 group cursor-pointer relative" onClick={e=>{e.stopPropagation();copy(c);}}>$ {c}<button className="absolute right-1 top-0.5 text-[7px] px-1.5 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-[#8888a0] opacity-0 group-hover:opacity-100">{copied===c?'✓':'CP'}</button></div>))}
                <p className="text-[8px] text-[#ffab00]">📝 {dc.notes}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
