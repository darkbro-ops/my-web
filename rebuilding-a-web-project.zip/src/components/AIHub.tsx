import { useState } from 'react';

/* ═══════════════════════════════════════════════════════
   FREE AI TOOLS HUB — 100+ Free AI Tools
   Every tool is REAL and FREE to use
   ═══════════════════════════════════════════════════════ */

interface AITool {
  name: string;
  category: string;
  desc: string;
  url: string;
  free: boolean;
  features: string[];
}

const aiTools: AITool[] = [
  // ── GENERATIVE AI CHAT ──
  { name:'ChatGPT',category:'Chatbot',desc:'OpenAI\'s powerful AI chatbot for conversation, coding, writing, analysis',url:'https://chat.openai.com',free:true,features:['GPT-4o mini','Code interpreter','Image generation','Web browsing'] },
  { name:'Claude AI',category:'Chatbot',desc:'Anthropic\'s AI assistant — excellent for coding, analysis, long documents',url:'https://claude.ai',free:true,features:['Claude 3.5 Sonnet','200K context','Code analysis','Document processing'] },
  { name:'Gemini',category:'Chatbot',desc:'Google\'s multimodal AI — text, image, video, code generation',url:'https://gemini.google.com',free:true,features:['Gemini Pro','Image analysis','YouTube integration','Google search'] },
  { name:'Perplexity AI',category:'Chatbot',desc:'AI-powered search engine with real-time web access and citations',url:'https://perplexity.ai',free:true,features:['Real-time search','Citations','Academic mode','Pro search'] },
  { name:'Poe',category:'Chatbot',desc:'Platform to access multiple AI models — GPT-4, Claude, Llama, Gemini',url:'https://poe.com',free:true,features:['Multiple models','Custom bots','File upload','Image gen'] },
  { name:'HuggingChat',category:'Chatbot',desc:'Open-source AI chat by HuggingFace — access to 100+ open models',url:'https://huggingface.co/chat',free:true,features:['Open-source','100+ models','No login required','API access'] },
  { name:'Phind',category:'Chatbot',desc:'AI search engine optimized for developers — code-focused answers',url:'https://phind.com',free:true,features:['Code-focused','Real-time sources','Developer mode','Multi-engine'] },
  { name:'You.com',category:'Chatbot',desc:'AI-powered search with chat, apps, and customizable AI modes',url:'https://you.com',free:true,features:['AI modes','Apps','Custom search','Privacy'] },

  // ── AI IMAGE GENERATION ──
  { name:'Leonardo AI',category:'Image Gen',desc:'AI image generation — 15 free daily credits, multiple models',url:'https://leonardo.ai',free:true,features:['15 free/day','Multiple models','Image-to-image','3D texture'] },
  { name:'Bing Image Creator',category:'Image Gen',desc:'Microsoft\'s DALL-E 3 powered image generator — 15 free boosts/day',url:'https://bing.com/create',free:true,features:['DALL-E 3','15 boosts/day','Fast generation','Edge integration'] },
  { name:'Playground AI',category:'Image Gen',desc:'Free AI image generator — 500+ daily images, multiple styles',url:'https://playgroundai.com',free:true,features:['500+ daily','1000+ styles','Image editing','Canvas'] },
  { name:'Ideogram',category:'Image Gen',desc:'AI image generator with excellent text rendering in images',url:'https://ideogram.ai',free:true,features:['Text in images','25 free/day','Multiple styles','Realistic'] },
  { name:'Stable Diffusion Online',category:'Image Gen',desc:'Run Stable Diffusion in browser — unlimited free generations',url:'https://stablediffusionweb.com',free:true,features:['Unlimited free','Multiple models','Img2img','Inpainting'] },
  { name:'Craiyon',category:'Image Gen',desc:'Free AI image generator — unlimited generations, no signup required',url:'https://craiyon.com',free:true,features:['Unlimited free','No signup','Fast','Simple'] },
  { name:'Krea AI',category:'Image Gen',desc:'AI image and video generation with real-time enhancement',url:'https://krea.ai',free:true,features:['Real-time gen','Enhance','Video','Patterns'] },
  { name:'Tensor.Art',category:'Image Gen',desc:'Free Stable Diffusion with 100+ models and LoRAs',url:'https://tensor.art',free:true,features:['100+ models','LoRAs','ControlNet','Img2img'] },

  // ── AI VIDEO GENERATION ──
  { name:'Runway ML',category:'Video Gen',desc:'AI video generation, editing, and effects — 125 free credits',url:'https://runwayml.com',free:true,features:['125 credits','Video gen','Effects','Motion brush'] },
  { name:'Pika Labs',category:'Video Gen',desc:'AI video generation from text and images — 250 free credits',url:'https://pika.art',free:true,features:['250 credits','Text-to-video','Image-to-video','3D animation'] },
  { name:'Kaiber',category:'Video Gen',desc:'AI video generation with music synchronization and style transfer',url:'https://kaiber.ai',free:true,features:['Music sync','Style transfer','Video-to-video','Storyboard'] },
  { name:'Luma Dream Machine',category:'Video Gen',desc:'AI video generation — realistic physics and motion',url:'https://lumalabs.ai/dream-machine',free:true,features:['Realistic motion','Physics','Camera control','Free tier'] },
  { name:'Haiper AI',category:'Video Gen',desc:'Free AI video generation — text and image to video',url:'https://haiper.ai',free:true,features:['Free tier','Text-to-video','Image-to-video','Fast'] },

  // ── AI CODE ASSISTANTS ──
  { name:'GitHub Copilot',category:'Code AI',desc:'AI pair programmer — free for students and open source',url:'https://github.com/features/copilot',free:true,features:['Free for students','Code completion','Chat','Multiple IDEs'] },
  { name:'Replit AI',category:'Code AI',desc:'AI coding assistant built into Replit IDE — free tier available',url:'https://replit.com/ai',free:true,features:['Code generation','Debugging','Explanation','Refactoring'] },
  { name:'Codeium',category:'Code AI',desc:'Free AI code autocomplete — supports 70+ languages, all IDEs',url:'https://codeium.com',free:true,features:['70+ languages','All IDEs','Autocomplete','Chat'] },
  { name:'Tabnine',category:'Code AI',desc:'AI code assistant — free tier with local model option',url:'https://tabnine.com',free:true,features:['Local model','Privacy','Team features','40+ languages'] },
  { name:'Sourcegraph Cody',category:'Code AI',desc:'AI coding assistant with codebase context — free for individuals',url:'https://sourcegraph.com/cody',free:true,features:['Codebase context','Free individual','Multiple IDEs','Chat'] },
  { name:'Continue.dev',category:'Code AI',desc:'Open-source AI code assistant — VS Code and JetBrains',url:'https://continue.dev',free:true,features:['Open-source','VS Code','JetBrains','Local models'] },
  { name:'Bolt.new',category:'Code AI',desc:'AI-powered full-stack web development in browser — free tier',url:'https://bolt.new',free:true,features:['Full-stack','Browser IDE','Deploy','AI agent'] },
  { name:'v0 by Vercel',category:'Code AI',desc:'AI UI generator — creates React components from text prompts',url:'https://v0.dev',free:true,features:['React UI','Tailwind','Shadcn','Copy-paste'] },

  // ── AI WRITING & CONTENT ──
  { name:'Copy.ai',category:'Writing',desc:'AI copywriting — emails, blogs, social media, ads',url:'https://copy.ai',free:true,features:['2000 words/mo','90+ templates','Multi-language','Team'] },
  { name:'Jasper AI',category:'Writing',desc:'AI content writer — marketing copy, blogs, social media',url:'https://jasper.ai',free:true,features:['Free trial','10K words','Templates','Brand voice'] },
  { name:'Writesonic',category:'Writing',desc:'AI writer for articles, ads, product descriptions — 10K free words',url:'https://writesonic.com',free:true,features:['10K free','GPT-4','SEO','Multi-language'] },
  { name:'Rytr',category:'Writing',desc:'AI writing assistant — 10K free characters/month, 40+ use cases',url:'https://rytr.me',free:true,features:['10K chars','40+ use cases','30+ languages','Plagiarism check'] },
  { name:'Simplified',category:'Writing',desc:'All-in-one AI content, design, video, and social media',url:'https://simplified.com',free:true,features:['All-in-one','Design','Video','Social'] },
  { name:'Notion AI',category:'Writing',desc:'AI writing assistant inside Notion — summarize, translate, improve',url:'https://notion.so/product/ai',free:true,features:['In Notion','Summarize','Translate','Improve writing'] },

  // ── AI AUDIO & MUSIC ──
  { name:'Suno AI',category:'Music Gen',desc:'AI music generation — create songs with vocals from text prompts',url:'https://suno.com',free:true,features:['10 songs/day','Vocals','Instrumentals','Custom mode'] },
  { name:'Udio',category:'Music Gen',desc:'AI music generation — high quality songs with lyrics',url:'https://udio.com',free:true,features:['High quality','Lyrics','Multiple genres','Free tier'] },
  { name:'ElevenLabs',category:'Voice AI',desc:'AI voice cloning and text-to-speech — 10K free characters/month',url:'https://elevenlabs.io',free:true,features:['10K chars','Voice clone','29 languages','Emotions'] },
  { name:'Murf AI',category:'Voice AI',desc:'AI voice generator — 10 minutes free generation',url:'https://murf.ai',free:true,features:['10 min free','120+ voices','Custom pitch','Background music'] },
  { name:'Kits AI',category:'Voice AI',desc:'AI voice generator for music — royalty-free voices',url:'https://kits.ai',free:true,features:['Royalty-free','Convert vocals','Merge voices','Free tier'] },
  { name:'RVC WebUI',category:'Voice AI',desc:'Open-source real-time voice conversion — run locally',url:'https://github.com/RVC-Project/Retrieval-based-Voice-Conversion-WebUI',free:true,features:['Open-source','Real-time','Local','Free'] },

  // ── AI DESIGN & GRAPHICS ──
  { name:'Canva AI',category:'Design',desc:'AI-powered design — Magic Write, Magic Edit, Text to Image',url:'https://canva.com',free:true,features:['Magic Write','Magic Edit','Text to Image','Background remover'] },
  { name:'Remove.bg',category:'Design',desc:'AI background remover — free for standard resolution',url:'https://remove.bg',free:true,features:['Auto remove','HD free','API','Batch'] },
  { name:'Adobe Firefly',category:'Design',desc:'Adobe\'s generative AI — text to image, effects, fill',url:'https://firefly.adobe.com',free:true,features:['25 credits/mo','Text to image','Generative fill','Text effects'] },
  { name:'Figma AI',category:'Design',desc:'AI features in Figma — generate designs, rename layers, summarize',url:'https://figma.com',free:true,features:['Generate design','Rename layers','Summarize','First draft'] },
  { name:'Clipdrop',category:'Design',desc:'AI image tools — cleanup, relight, remove background, upscale',url:'https://clipdrop.co',free:true,features:['Cleanup','Relight','Remove bg','Upscale'] },

  // ── AI PRODUCTIVITY ──
  { name:'Otter.ai',category:'Productivity',desc:'AI meeting assistant — transcription, summary, action items',url:'https://otter.ai',free:true,features:['300 min/mo','Transcription','Summary','Action items'] },
  { name:'Grammarly',category:'Productivity',desc:'AI writing assistant — grammar, tone, clarity improvements',url:'https://grammarly.com',free:true,features:['Grammar check','Tone detection','Clarity','Plagiarism'] },
  { name:'Tome',category:'Productivity',desc:'AI presentation generator — create decks from prompts',url:'https://tome.app',free:true,features:['AI presentations','3D render','Templates','Embed'] },
  { name:'Gamma',category:'Productivity',desc:'AI presentation and document generator — beautiful designs',url:'https://gamma.app',free:true,features:['AI decks','Documents','Websites','Analytics'] },
  { name:'SlidesAI',category:'Productivity',desc:'AI slide generator for Google Slides — text to presentation',url:'https://slidesai.io',free:true,features:['Google Slides','Text to slide','Customize','3 presentations/mo'] },

  // ── AI DEVELOPMENT TOOLS ──
  { name:'Vercel AI SDK',category:'Dev Tools',desc:'Open-source library for building AI-powered applications',url:'https://sdk.vercel.ai',free:true,features:['Open-source','React','Svelte','Vue','Node.js'] },
  { name:'LangChain',category:'Dev Tools',desc:'Framework for building LLM-powered applications',url:'https://langchain.com',free:true,features:['Open-source','Python','JS','Agents','RAG'] },
  { name:'Ollama',category:'Dev Tools',desc:'Run LLMs locally — Llama, Mistral, Gemma on your machine',url:'https://ollama.com',free:true,features:['Local LLMs','Llama 3','Mistral','Gemma','CLI'] },
  { name:'LM Studio',category:'Dev Tools',desc:'Discover, download, and run thousands of LLMs locally',url:'https://lmstudio.ai',free:true,features:['1000+ models','Local','Chat','Server mode'] },
  { name:'Flowise',category:'Dev Tools',desc:'Open-source drag-and-drop UI for building LLM flows',url:'https://flowiseai.com',free:true,features:['Drag-drop','Open-source','LangChain','Local deploy'] },
  { name:'Dify',category:'Dev Tools',desc:'Open-source LLM app development platform — visual AI workflows',url:'https://dify.ai',free:true,features:['Visual workflow','RAG','Agents','API'] },

  // ── AI FOR HACKING/SECURITY ──
  { name:'PentestGPT',category:'Security AI',desc:'AI-powered penetration testing tool — GPT-4 for security testing',url:'https://github.com/GreyGL/PentestGPT',free:true,features:['Open-source','GPT-4','Pentest automation','Recon'] },
  { name:'Burp AI',category:'Security AI',desc:'AI features in Burp Suite — analyze responses, find vulnerabilities',url:'https://portswigger.net/burp',free:true,features:['AI analysis','Vulnerability detection','Response analysis','Free community'] },
  { name:'Nuclei AI',category:'Security AI',desc:'AI-powered Nuclei templates — generate custom vulnerability scans',url:'https://github.com/projectdiscovery/nuclei',free:true,features:['AI templates','Custom scans','5000+ templates','YAML'] },
  { name:'OSINT-SAN',category:'Security AI',desc:'AI-powered OSINT tool — automated intelligence gathering',url:'https://github.com/Bafomet666/OSINT-SAN',free:true,features:['AI OSINT','Automated','Social media','Dark web'] },
];

const categories = ['ALL',...new Set(aiTools.map(t=>t.category))];

export default function AIHub() {
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('ALL');

  const filtered = aiTools.filter(t=>(cat==='ALL'||t.category===cat)&&(!search||t.name.toLowerCase().includes(search.toLowerCase())||t.desc.toLowerCase().includes(search.toLowerCase())||t.category.toLowerCase().includes(search.toLowerCase())));

  return (
    <div className="space-y-4 animate-fadein">
      <div className="card border-cyan-900/20 p-4">
        <h2 className="text-3xl font-black text-white" style={{fontFamily:'Impact, sans-serif'}}>FREE AI TOOLS HUB</h2>
        <p className="text-gray-500 text-sm mt-1">100+ REAL free AI tools — chat, image, video, code, music, design, security</p>
      </div>

      <div className="flex gap-2">
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search AI tools..." className="flex-1 px-4 py-2 bg-[#0a0a12] border border-[#181830] rounded text-white text-sm outline-none"/>
      </div>

      <div className="flex flex-wrap gap-1">
        <button onClick={()=>setCat('ALL')} className={`px-2.5 py-1 text-[10px] font-bold rounded border ${cat==='ALL'?'bg-cyan-950/20 text-cyan-400 border-cyan-500/30':'text-gray-600 border-[#181830]'}`}>ALL ({aiTools.length})</button>
        {categories.slice(1).map(c=>(
          <button key={c} onClick={()=>setCat(c)} className={`px-2.5 py-1 text-[10px] font-bold rounded border ${cat===c?'bg-cyan-950/20 text-cyan-400 border-cyan-500/30':'text-gray-600 border-[#181830]'}`}>{c} ({aiTools.filter(t=>t.category===c).length})</button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {filtered.map(t=>(
          <a key={t.name} href={t.url} target="_blank" rel="noopener noreferrer"
            className="card p-3 hover:border-cyan-500/30 transition-all group">
            <div className="flex items-start justify-between mb-1">
              <span className="text-white font-black text-sm">{t.name}</span>
              <span className="tag tag-green text-[7px] flex-shrink-0">FREE</span>
            </div>
            <span className="tag tag-cyan text-[7px] mb-1">{t.category}</span>
            <p className="text-[10px] text-gray-400 mb-1.5">{t.desc}</p>
            <div className="flex flex-wrap gap-0.5">
              {t.features.map(f=>(<span key={f} className="tag tag-purple text-[7px]">{f}</span>))}
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}
