import { useState } from 'react';
import { cyberSites } from '../data/enhanced';

export default function CyberWebsiteDir() {
  const [search, setSearch] = useState('');
  const [catFilter, setCatFilter] = useState('ALL');

  const cats = ['ALL', ...new Set(cyberSites.map(s => s.category))];
  const filtered = cyberSites.filter(s =>
    (catFilter === 'ALL' || s.category === catFilter) &&
    (!search || s.name.toLowerCase().includes(search.toLowerCase()) || s.description.toLowerCase().includes(search.toLowerCase()))
  );

  const catIcons: Record<string, string> = { 'Practice Labs': '🧪', 'Exploits': '💣', 'OSINT': '🔍', 'Malware Analysis': '🦠', 'Dark Web': '🎭', 'Tools': '🛠', 'Threat Intel': '⚠️', 'Framework': '📋', 'Cracking': '🔑', 'Analysis': '🔬' };

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-cyan-500/20 rounded p-4">
        <h2 className="text-cyan-400 font-bold text-sm">🌐 CYBER WEBSITES DIRECTORY</h2>
        <p className="text-green-700 text-[10px]">Curated collection of 16+ essential cybersecurity websites, tools, and resources.</p>
      </div>

      <div className="flex gap-2">
        <input type="text" value={search} onChange={e => setSearch(e.target.value)}
          placeholder="🔍 Search websites..." className="flex-1 px-3 py-1.5 bg-black/80 border border-green-900/30 rounded text-green-400 text-[10px] outline-none font-mono" />
      </div>

      <div className="flex gap-1 flex-wrap">
        {cats.map(c => (
          <button key={c} onClick={() => setCatFilter(c)}
            className={`px-2 py-0.5 text-[9px] rounded border font-mono ${catFilter === c ? 'bg-cyan-950/20 text-cyan-400 border-cyan-500/30' : 'text-green-700 border-green-900/20 hover:text-cyan-500'}`}>
            {c === 'ALL' ? '🌐 ALL' : `${catIcons[c] || '🔗'} ${c}`}
          </button>
        ))}
      </div>

      <div className="text-[9px] text-green-700">{filtered.length} websites found</div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {filtered.map(site => (
          <a key={site.id} href={site.requiresOnion ? '#' : site.url} target={site.requiresOnion ? '_self' : '_blank'} rel="noopener noreferrer"
            className="bg-black/80 border border-green-900/20 rounded p-3 hover:border-cyan-700/30 transition-all block group">
            <div className="flex items-center justify-between mb-1">
              <span className="text-green-400 font-bold text-xs group-hover:text-cyan-400 transition-colors">{site.name}</span>
              <span className={`text-[7px] px-1.5 py-0.5 rounded border ${site.requiresOnion ? 'bg-purple-950/20 text-purple-400 border-purple-500/20' : 'bg-green-950/20 text-green-400 border-green-500/20'}`}>
                {site.requiresOnion ? '🧅 .ONION' : site.free ? '🆓 FREE' : '💰 PAID'}
              </span>
            </div>
            <p className="text-green-600 text-[9px] mb-1">{site.description}</p>
            <div className="flex items-center justify-between">
              <span className="text-[8px] text-green-800 truncate max-w-[150px]">{site.url}</span>
              <span className="text-[8px] text-green-700 bg-green-950/10 px-1 rounded">{site.category}</span>
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}
