import { useState } from 'react';
import { hackerCourseModules } from '../data/shadowsect';

export default function SHHackerCourse() {
  const [activePhase, setActivePhase] = useState(0);
  const [activeTopic, setActiveTopic] = useState<number|null>(null);

  const phase = hackerCourseModules[activePhase];

  return (
    <div className="h-full bg-[#0a0a0f] flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 bg-[#0d0d17] border-b border-[#1e1e30]">
        <div className="flex items-center gap-2"><span className="text-xl">🎓</span><h2 className="text-white font-black text-sm">HACKER WORLD COURSE — COMPLETE CURRICULUM</h2><span className="tag tag-red text-[7px]">7 PHASES</span><span className="tag tag-yellow text-[7px]">340h</span></div>
        <span className="text-[#5a5a72] text-[9px]">EDUCATIONAL ONLY</span>
      </div>

      {/* Phase selector */}
      <div className="flex overflow-x-auto bg-[#0d0d17] border-b border-[#1e1e30]">
        {hackerCourseModules.map((m,i)=>(
          <button key={m.id} onClick={()=>{setActivePhase(i);setActiveTopic(null);}}
            className={`px-3 py-2 text-[9px] font-bold whitespace-nowrap border-b-2 transition-all ${i===activePhase?'text-[#00d4ff] border-[#00d4ff]':'text-[#5a5a72] border-transparent hover:text-[#8888a0]'}`}>
            {m.phase}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        {/* Phase header */}
        <div className="card-glow-cyan p-4 mb-3">
          <h3 className="text-white font-black text-sm">{phase.title}</h3>
          <div className="flex items-center gap-3 mt-1">
            <span className="text-[#00d4ff] text-[10px] font-bold">{phase.phase}</span>
            <span className="text-[#5a5a72] text-[9px]">Duration: {phase.duration}</span>
            <span className="text-[#5a5a72] text-[9px]">Topics: {phase.topics.length}</span>
          </div>
        </div>

        {/* Topics grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
          {phase.topics.map((topic,i)=>(
            <div key={i} onClick={()=>setActiveTopic(activeTopic===i?null:i)}
              className={`card-dark p-3 cursor-pointer transition-all ${activeTopic===i?'ring-1 ring-[#00d4ff]/30':''}`}>
              <div className="flex items-center gap-2">
                <span className="text-[#00d4ff] font-bold text-xs">{String(i+1).padStart(2,'0')}</span>
                <span className="text-white font-bold text-xs">{topic.t}</span>
                <span className="tag tag-cyan text-[7px] ml-auto">{phase.phase.split('—')[0].trim()}</span>
              </div>
              {activeTopic===i && (
                <p className="text-[10px] text-[#8888a0] mt-2 pt-2 border-t border-[#1e1e30]">{topic.desc}</p>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Progress bar */}
      <div className="px-4 py-2 bg-[#0d0d17] border-t border-[#1e1e30]">
        <div className="flex items-center justify-between text-[9px] text-[#5a5a72] mb-1"><span>PROGRESS</span><span>{activePhase+1}/{hackerCourseModules.length} PHASES</span></div>
        <div className="h-1 bg-[#1e1e30] rounded-full overflow-hidden">
          <div className="h-full bg-gradient-to-r from-[#00d4ff] to-[#b388ff] rounded-full transition-all" style={{width:`${((activePhase+1)/hackerCourseModules.length)*100}%`}}/>
        </div>
      </div>
    </div>
  );
}
