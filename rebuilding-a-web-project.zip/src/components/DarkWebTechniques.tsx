import { useState } from 'react';
import { darkTechniques } from '../data/enhanced';

export default function DarkWebTechniques() {
  const [selected, setSelected] = useState<string | null>(null);
  const [difficultyFilter, setDifficultyFilter] = useState('ALL');

  const difficulties = ['ALL', 'Easy', 'Medium', 'Hard', 'Expert'];
  const filtered = difficultyFilter === 'ALL' ? darkTechniques : darkTechniques.filter(t => t.difficulty === difficultyFilter);

  const diffColors: Record<string, string> = { 'Easy': 'border-green-500/20 text-green-400', 'Medium': 'border-yellow-500/20 text-yellow-400', 'Hard': 'border-red-500/20 text-red-400', 'Expert': 'border-purple-500/20 text-purple-400' };
  const diffBg: Record<string, string> = { 'Easy': 'bg-green-950/20', 'Medium': 'bg-yellow-950/20', 'Hard': 'bg-red-950/20', 'Expert': 'bg-purple-950/20' };

  return (
    <div className="h-full bg-[#050508] p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-purple-400 font-bold text-sm tracking-wider">🎭 DARK WEB TECHNIQUES — OPSEC & ANONYMITY GUIDE</h2>
        <span className="text-[9px] text-purple-700">EDUCATIONAL ONLY</span>
      </div>

      <div className="mb-3 p-3 border border-purple-500/20 rounded bg-purple-950/5">
        <p className="text-[9px] text-purple-400">⚠️ <strong>DISCLAIMER:</strong> These techniques are provided for educational and defensive security research only. Unauthorized access to systems is illegal. Always obtain proper authorization.</p>
      </div>

      <div className="flex gap-1 flex-wrap mb-3">
        {difficulties.map(d => (
          <button key={d} onClick={() => setDifficultyFilter(d)}
            className={`px-2 py-0.5 text-[9px] rounded border font-mono ${difficultyFilter === d ? 'bg-purple-950/20 text-purple-400 border-purple-500/30' : 'text-green-700 border-green-900/20 hover:text-purple-500'}`}>
            {d === 'ALL' ? '🎯 ALL' : `${d === 'Expert' ? '💀' : d === 'Hard' ? '🔥' : d === 'Medium' ? '⚡' : '🟢'} ${d.toUpperCase()}`}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto space-y-2">
        {filtered.map(tech => (
          <div key={tech.id} onClick={() => setSelected(selected === tech.id ? null : tech.id)}
            className={`border rounded p-3 cursor-pointer transition-all ${diffBg[tech.difficulty]} ${
              selected === tech.id ? diffColors[tech.difficulty].replace('text-', 'border-').replace('border-', '') + ' border-opacity-50 bg-opacity-30' : 'border-green-900/10 hover:border-purple-700/30'
            }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">{tech.difficulty === 'Expert' ? '💀' : tech.difficulty === 'Hard' ? '🔥' : tech.difficulty === 'Medium' ? '⚡' : '🟢'}</span>
                <div>
                  <span className="text-green-400 text-xs font-bold">{tech.title}</span>
                  <span className="text-green-700 text-[9px] ml-2">{tech.category}</span>
                </div>
              </div>
              <span className={`text-[8px] px-1.5 py-0.5 rounded border ${diffColors[tech.difficulty]}`}>{tech.difficulty}</span>
            </div>
            {selected === tech.id && (
              <div className="mt-2 pt-2 border-t border-green-900/20">
                <div className="mb-2">
                  <span className="text-[9px] text-green-700 font-bold">📋 STEP-BY-STEP:</span>
                  <div className="mt-1 space-y-1">
                    {tech.steps.map((step, i) => (
                      <div key={i} className="flex items-start gap-2">
                        <span className="text-green-600 text-[9px] font-mono">{i + 1}.</span>
                        <span className="text-[9px] text-green-500">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="mb-2">
                  <span className="text-[9px] text-green-700 font-bold">🛠 TOOLS:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {tech.tools.map((t, i) => (
                      <span key={i} className="px-1.5 py-0.5 text-[8px] bg-purple-950/20 border border-purple-500/20 rounded text-purple-400 font-mono">{t}</span>
                    ))}
                  </div>
                </div>
                <div className="p-2 border border-red-500/20 rounded bg-red-950/10">
                  <p className="text-[8px] text-red-400">⚠️ {tech.warning}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
