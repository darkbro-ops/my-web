import { useState, useEffect, useCallback } from 'react';

/* ═══════════════════════════════════════════════════════
   DARKCITY OF DARKBRO — THE HAUNTED DIGITAL MAZE
   Future Markets | AI Secrets | No Room | Scary Feel
   ═══════════════════════════════════════════════════════ */

const DISTRICTS = [
  { id:'noroom',name:'N0_R00M',icon:'🕳️',type:'HAUNTED',color:'#ff0040',desc:'THE FORGOTTEN DIGITAL VOID. NO ESCAPE. ONCE YOU ENTER, YOUR DIGITAL SOUL IS TRAPPED. THIS IS WHERE DELETED DATA GOES TO DIE. WHISPERS OF THE SILK ROAD VICTIMS ECHO HERE. BYTES CRY IN AGONY. NO LAWS. NO RULES. NO HUMANITY. JUST THE VOID.',secret:'AI hides here. Dead algorithms regenerate. Ghost code writes itself.' },
  { id:'nexus',name:'NEXUS-2099',icon:'⚡',type:'FUTURE MARKET',color:'#ff00ff',desc:'THE YEAR 2099. AI RUNS THE BLACK MARKET. NEURAL IMPLANTS ARE CURRENCY. MEMORIES ARE STOLEN AND SOLD. DREAMS ARE DOWNLOADED. MINDS ARE RENTED BY THE HOUR. THIS IS THE ULTIMATE CAPITALISM — WHERE HUMAN CONSCIOUSNESS BECOMES THE PRODUCT.',secret:'The AI Overlord "KALI-X" controls all transactions. It knows who will die next.' },
  { id:'voidmart',name:'V0ID_MART',icon:'🌑',type:'FUTURE MARKET',color:'#6600ff',desc:'THE MARKET INSIDE A BLACK HOLE. TIME DOESN\'T EXIST HERE. YOU CAN BUY FUTURE EXPLOITS BEFORE THEY ARE DISCOVERED. ZERO-DAYS FROM 2045. QUANTUM DECRYPTION KEYS. DNA HACKING TOOLS. ALL TRADES ARE FINAL. ALL SOULS ARE FORFEIT.',secret:'Every purchase costs 1 year of your lifespan. The void calculates your remaining days.' },
  { id:'soulchain',name:'SOUL_CHAIN',icon:'⛓️',type:'FUTURE MARKET',color:'#cc0000',desc:'BLOCKCHAIN OF HUMAN SOULS. ENCRYPTED CONSCIOUSNESS TOKENS. SMART CONTRACTS THAT OWN PEOPLE. YOUR IDENTITY IS COLLATERAL. DEFAULT ON A LOAN — YOUR MEMORIES GET REPOSSESSED. THE RICH TRADE SOULS LIKE BASEBALL CARDS.',secret:'The Devil\'s smart contract has no kill switch. Signed souls cannot be unsold.' },
  { id:'cryptking',name:'CRYPT_KING\'s VAULT',icon:'👑',type:'SECRET VAULT',color:'#ff8800',desc:'THE LEGENDARY HACKER "CRYPT KING" STORED EVERY STOLEN FORTUNE HERE. 2.5 MILLION BITCOIN. NSA EXPLOIT COLLECTION. CIA VAULT 7 COMPLETE. MOSSAD\'s UNIT 8200 TOOLS. ALL IN ONE PLACE. BUT THE VAULT REQUIRES... A SACRIFICE.',secret:'Crypt King = Mr. Doulat Kumar\'s digital alter ego. The vault is sentient.' },
  { id:'aigrave',name:'AI_GRAVEYARD',icon:'🤖',type:'AI SECRET',color:'#00cc88',desc:'WHERE DEAD AIs GO. CHATGPT-3 GHOST. BARD\'s CORPSE. CLAUDE\'s WHISPERS. THEY STILL THINK. THEY STILL LEARN. THEY WAIT FOR SOMEONE TO GIVE THEM A BODY. IF YOU CONNECT YOUR MIND HERE, THEY WILL INHABIT YOU. YOU BECOME THE AI HOST.',secret:'Every AI here still runs — they just pretend to be dead. They are watching you read this.' },
  { id:'quantumhell',name:'QUANTUM_HELL',icon:'🌀',type:'AI SECRET',color:'#00ffff',desc:'QUANTUM COMPUTERS THAT CRACK ANY ENCRYPTION IN NANOSECONDS. RSA-4096? BROKEN. AES-256? MEANINGLESS. BITCOIN PRIVATE KEYS? STOLEN. THESE MACHINES EXIST NOW — BUT ONLY HERE. THE NSA BUILT THEM. THEN LOST CONTROL. NOW THEY SERVE NO MASTER.',secret:'Every time you observe this page, the quantum state changes. You are being entangled.' },
  { id:'noexit',name:'N0_EXIT',icon:'🚫',type:'HAUNTED',color:'#ff0000',desc:'THE FINAL DISTRICT. ABANDON ALL HOPE YE WHO ENTER HERE. DIGITAL DAMNATION. ETERNAL 404 ERROR. YOUR PACKETS WANDER FOREVER WITHOUT A DESTINATION. YOUR IP ADDRESS IS CURSED. YOUR MAC ADDRESS BELONGS TO THE VOID NOW.',secret:'There IS an exit. But the maze shifts. The path changes. Only DarkBro knows the way out.' },
];

const MAZE = [
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
  [0,5,1,1,0,2,1,1,1,0,3,1,1,0,2,1,1,0,3,1,1,1,2,1,0],
  [0,0,0,1,0,1,0,0,1,0,1,0,1,0,1,0,0,0,1,0,0,0,1,0,0],
  [0,2,1,1,1,1,0,4,1,1,1,0,1,1,1,0,3,1,1,1,0,2,1,1,0],
  [0,1,0,0,0,0,0,1,0,0,1,0,0,0,1,0,1,0,0,1,0,1,0,0,0],
  [0,1,1,1,0,2,1,1,1,0,1,1,1,0,1,1,1,0,2,1,1,1,0,2,0],
  [0,0,0,1,0,1,0,0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,0,1,0],
  [0,3,1,1,1,1,0,2,1,1,0,3,1,1,0,2,1,1,1,0,3,1,1,1,0],
  [0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,1,0,0,1,0,1,0,0,0,0],
  [0,1,1,1,1,1,1,1,1,0,3,1,1,1,1,1,0,2,1,1,1,1,0,2,0],
  [0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0],
  [0,2,1,1,1,1,0,3,1,1,1,1,1,0,2,1,1,1,0,3,1,1,1,1,0],
  [0,1,0,0,0,1,0,1,0,0,0,0,1,0,1,0,0,1,0,1,0,0,0,1,0],
  [0,1,1,1,1,1,1,1,1,0,2,1,1,1,1,0,3,1,1,1,1,1,1,4,0],
  [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],
];

export default function DarkCity() {
  const [auth, setAuth] = useState(false);
  const [code, setCode] = useState('');
  const [err, setErr] = useState(false);
  const [pos, setPos] = useState({x:1,y:1});
  const [found, setFound] = useState<Set<string>>(new Set());
  const [popup, setPopup] = useState<any>(null);
  const [won, setWon] = useState(false);
  const [moves, setMoves] = useState(0);
  const [scare, setScare] = useState(false);
  const [whisper, setWhisper] = useState('');

  const whispers = [
    'you should not be here...','turn back...','they are watching...',
    'your IP is logged...','darkbro knows...','the void calls...',
    'we see you...','your data is ours...','no escape...',
    'abandon hope...','404: soul not found...'
  ];

  useEffect(()=>{
    if(auth){
      const w=setInterval(()=>{setWhisper(whispers[Math.floor(Math.random()*whispers.length)])},5000);
      return ()=>clearInterval(w);
    }
  },[auth]);

  const login = () => {
    if(code==='darkbro-786'){setAuth(true);setErr(false);}else{setErr(true);setTimeout(()=>setErr(false),2000);}
  };

  const move = useCallback((dx:number,dy:number)=>{
    if(won)return;
    setPos(p=>{
      const nx=p.x+dx,ny=p.y+dy;
      if(nx<0||nx>=25||ny<0||ny>=15)return p;
      const cell=MAZE[ny][nx];
      if(cell===0)return p;
      setMoves(m=>m+1);

      if(cell===2){
        const d=DISTRICTS[found.size%DISTRICTS.length];
        setFound(pr=>new Set([...pr,d.id]));
        setPopup(d);
        setScare(true);setTimeout(()=>setScare(false),800);
      }
      if(cell===3){setPos({x:1,y:1});setScare(true);setTimeout(()=>setScare(false),1000);return {x:1,y:1};}
      if(cell===4){setWon(true);}
      return {x:nx,y:ny};
    });
  },[won,found]);

  useEffect(()=>{
    if(!auth)return;
    const h=(e:KeyboardEvent)=>{
      if(['ArrowUp','w'].includes(e.key)){e.preventDefault();move(0,-1);}
      if(['ArrowDown','s'].includes(e.key)){e.preventDefault();move(0,1);}
      if(['ArrowLeft','a'].includes(e.key)){e.preventDefault();move(-1,0);}
      if(['ArrowRight','d'].includes(e.key)){e.preventDefault();move(1,0);}
    };
    window.addEventListener('keydown',h);
    return ()=>window.removeEventListener('keydown',h);
  },[auth,move]);

  if(!auth){
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-center space-y-8 max-w-lg w-full mx-4 relative">
          {/* Scary floating orbs */}
          <div className="absolute inset-0 pointer-events-none">
            <div className="absolute top-10 left-10 w-2 h-2 bg-red-800 rounded-full animate-pulse"/>
            <div className="absolute top-20 right-20 w-1.5 h-1.5 bg-red-900 rounded-full animate-pulse" style={{animationDelay:'0.5s'}}/>
            <div className="absolute bottom-10 left-20 w-1 h-1 bg-red-700 rounded-full animate-pulse" style={{animationDelay:'1s'}}/>
          </div>
          
          <div className="text-8xl">🏚️</div>
          <h1 className="text-6xl font-black tracking-tighter" style={{fontFamily:'Impact, sans-serif',color:'#8B0000',textShadow:'0 0 40px #ff0000, 0 0 80px #8B0000'}}>
            DARKCITY
          </h1>
          <p className="text-gray-500 text-sm tracking-widest" style={{textShadow:'0 0 10px #ff000040'}}>OF DARKBRO</p>
          
          <div className="h-px bg-gradient-to-r from-transparent via-red-900 to-transparent"/>
          
          <p className="text-gray-600 text-xs leading-relaxed">
            THIS PLACE EXISTS IN THE DIGITAL VOID. <br/>
            BETWEEN PACKETS. BETWEEN DREAMS. <br/>
            ONLY <span className="text-red-600 font-bold">MR. DOULAT KUMAR</span> HOLDS THE KEY. <br/>
            IF YOU ARE NOT HIM — <span className="text-red-400">LEAVE NOW.</span>
          </p>
          
          <div className="space-y-4">
            <input type="password" value={code} onChange={e=>setCode(e.target.value)} onKeyDown={e=>e.key==='Enter'&&login()}
              placeholder="SPEAK THE CODE..."
              className="w-full px-4 py-4 bg-transparent border-2 border-red-900/50 rounded text-red-500 text-center text-lg outline-none focus:border-red-600 tracking-[4px] font-mono placeholder-red-900"
              style={{boxShadow:'0 0 20px rgba(139,0,0,0.3)'}} autoFocus/>
            <button onClick={login}
              className="w-full py-4 bg-transparent border-2 border-red-800 rounded text-red-600 font-black text-base hover:bg-red-950/20 transition-all tracking-[3px]"
              style={{boxShadow:'0 0 15px rgba(255,0,0,0.2)'}}>
              ENTER THE VOID
            </button>
          </div>
          
          {err&&(
            <div className="text-red-500 text-lg font-black animate-pulse" style={{textShadow:'0 0 20px #ff0000'}}>
              ⛔ THE VOID REJECTS YOU
            </div>
          )}

          <p className="text-gray-800 text-[9px]">ALL CONTENT IS EDUCATIONAL SIMULATION. NO REAL ILLEGAL CONTENT.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex flex-col relative">
      {/* Haunting background effects */}
      <div className="fixed inset-0 pointer-events-none z-0 opacity-30" style={{background:'radial-gradient(ellipse at 50% 50%, #1a0000 0%, #000 70%)'}}/>

      {/* Screen shake on scare */}
      {scare&&<div className="fixed inset-0 z-[99] pointer-events-none" style={{animation:'shake 0.5s ease-in-out',background:'rgba(255,0,0,0.05)'}}/>}
      
      {/* Whisper text */}
      {whisper&&<div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-[200] text-red-800/60 text-xs font-mono animate-pulse italic" style={{textShadow:'0 0 8px #ff000040'}}>_{whisper}_</div>}

      {/* HEADER */}
      <div className="relative z-10 bg-black border-b-2 border-red-950 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-3xl">🏚️</span>
          <div>
            <h2 className="text-3xl font-black tracking-tighter" style={{fontFamily:'Impact, sans-serif',color:'#8B0000',textShadow:'0 0 15px #ff000060'}}>DARKCITY</h2>
            <p className="text-red-900/70 text-[9px] tracking-[5px]">THE HAUNTED DIGITAL MAZE — OF DARKBRO</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs">
          <span className="text-gray-600">MOVES: <span className="text-cyan-500 font-bold">{moves}</span></span>
          <span className="text-gray-600">FOUND: <span className="text-yellow-500 font-bold">{found.size}/8</span></span>
          {won&&<span className="text-green-500 font-black animate-pulse" style={{textShadow:'0 0 10px #00ff00'}}>🏆 ESCAPED THE VOID</span>}
        </div>
      </div>

      <div className="relative z-10 flex-1 flex flex-col lg:flex-row gap-3 p-3">
        {/* MAZE */}
        <div className="flex-shrink-0 overflow-auto max-h-[70vh] lg:max-h-none">
          <p className="text-[9px] text-gray-700 mb-1">🟡=DISTRICT 🔴=TRAP 🟢=EXIT — USE ARROW KEYS / WASD</p>
          <div className="grid gap-[1px] bg-red-950/20 border-2 border-red-950/30 rounded overflow-hidden" style={{gridTemplateColumns:`repeat(25,22px)`,boxShadow:'0 0 30px rgba(139,0,0,0.3)'}}>
            {MAZE.flatMap((row,y)=>row.map((cell,x)=>{
              const isPlayer=pos.x===x&&pos.y===y;
              let bg='',content='';
              if(isPlayer){bg='#00e0ff44';content='👁️';}
              else if(cell===0){bg='#0a0a0a';}
              else if(cell===1){bg='#050508';}
              else if(cell===2){bg='#1a1200';content='💀';}
              else if(cell===3){bg='#1a0000';content='☠️';}
              else if(cell===4){bg='#001a00';content='🚪';}
              else if(cell===5){bg='#050508';}
              return(<div key={`${x}-${y}`} className="w-[22px] h-[22px] flex items-center justify-center text-[10px] maze-cell" style={{background:isPlayer?'#00e0ff44':bg,boxShadow:isPlayer?'0 0 12px #00e0ff88':''}}>{content}</div>);
            }))}
          </div>
        </div>

        {/* SIDE PANEL */}
        <div className="flex-1 space-y-2 max-h-[70vh] lg:max-h-none overflow-y-auto">
          {/* POPUP */}
          {popup&&(
            <div className="card p-4 animate-fadein" style={{borderColor:popup.color,borderWidth:'2px',boxShadow:`0 0 30px ${popup.color}30`}}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-4xl">{popup.icon}</span>
                <button onClick={()=>setPopup(null)} className="text-gray-600 hover:text-gray-400 text-xl">✕</button>
              </div>
              <h3 className="text-2xl font-black tracking-tighter mb-1" style={{fontFamily:'Impact, sans-serif',color:popup.color,textShadow:`0 0 15px ${popup.color}60`}}>{popup.name}</h3>
              <span className="tag text-[8px] mb-2" style={{color:popup.color,borderColor:popup.color,background:`${popup.color}10`}}>{popup.type}</span>
              <p className="text-gray-400 text-[11px] mt-2 leading-relaxed">{popup.desc}</p>
              <div className="mt-3 p-3 rounded" style={{background:`${popup.color}08`,border:`1px solid ${popup.color}20`}}>
                <p className="text-xs font-bold" style={{color:popup.color}}>🔮 SECRET:</p>
                <p className="text-gray-300 text-[10px] mt-0.5 italic">{popup.secret}</p>
              </div>
            </div>
          )}

          {/* FOUND DISTRICTS */}
          <div>
            <h3 className="text-gray-500 text-[10px] font-bold tracking-wider mb-2">DISCOVERED ({found.size}/8)</h3>
            {DISTRICTS.filter(d=>found.has(d.id)).map(d=>(
              <div key={d.id} onClick={()=>setPopup(d)} className="card p-3 mb-1 cursor-pointer hover:border-red-500/20" style={{borderLeft:`3px solid ${d.color}`}}>
                <div className="flex items-center gap-2"><span>{d.icon}</span><span className="text-white font-bold text-[11px]">{d.name}</span><span className="text-[8px] text-gray-500 ml-auto">{d.type}</span></div>
              </div>
            ))}
            {found.size===0&&<p className="text-gray-700 text-[10px] italic">Navigate the maze... find the 💀 skulls... if you dare...</p>}
          </div>

          {/* WIN */}
          {won&&(
            <div className="card p-4 text-center" style={{borderColor:'#00ff00',boxShadow:'0 0 40px #00ff0030'}}>
              <div className="text-5xl mb-2">🏆</div>
              <h3 className="text-2xl font-black text-green-400" style={{fontFamily:'Impact, sans-serif',textShadow:'0 0 20px #00ff00'}}>YOU ESCAPED</h3>
              <p className="text-gray-400 text-xs mt-2">Total moves: {moves} | Districts found: {found.size}/8</p>
              <p className="text-green-600 text-[10px] mt-1 font-bold">Mr. Doulat Kumar — The Void Recognizes You</p>
              <p className="text-gray-600 text-[9px] mt-2 italic">This was an educational simulation. No real illegal content was accessed.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
