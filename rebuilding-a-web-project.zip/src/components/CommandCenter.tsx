import { useState } from 'react';
import { terminalCommands } from '../data/categories';

export default function CommandCenter() {
  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState<string>('ALL');

  const categories = ['ALL', ...new Set(terminalCommands.map(c => c.category))];

  const filtered = terminalCommands.filter(c =>
    (selectedCat === 'ALL' || c.category === selectedCat) &&
    (!search || c.cmd.toLowerCase().includes(search.toLowerCase()) || c.desc.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="bg-black/80 border border-green-900/20 rounded p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-green-400 font-bold text-sm">💻 COMMAND CENTER — 500+ Commands</h2>
        <span className="text-[9px] text-green-700">{filtered.length} commands</span>
      </div>

      <div className="flex gap-2 mb-4">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search commands..."
          className="flex-1 px-3 py-1.5 bg-[#020408] border border-green-900/30 rounded text-green-400 text-[10px] outline-none font-mono"
        />
      </div>

      <div className="flex flex-wrap gap-1 mb-4">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCat(cat)}
            className={`px-2 py-0.5 text-[9px] rounded border font-mono transition-all ${
              selectedCat === cat
                ? 'bg-green-950/20 text-green-400 border-green-500/30'
                : 'text-green-700 border-green-900/20 hover:text-green-500'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="space-y-1 max-h-[60vh] overflow-y-auto">
        {filtered.map((cmd, i) => (
          <div key={i} className="flex items-center justify-between p-2 border border-green-900/10 rounded hover:bg-green-950/5 transition-all">
            <div>
              <span className="text-green-400 font-mono text-xs font-bold">{cmd.cmd}</span>
              <span className="text-green-600 text-[10px] ml-2">{cmd.desc}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-[7px] px-1 rounded ${
                cmd.level === 'omega' ? 'bg-purple-950/20 text-purple-400' :
                cmd.level === 'classified' ? 'bg-red-950/20 text-red-400' :
                'bg-green-950/20 text-green-600'
              }`}>
                {cmd.level}
              </span>
              <span className="text-[8px] text-green-800">{cmd.category}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
