import { useState } from 'react';
import type { AccessLevel } from '../data/types';
import { stealthTools } from '../data/enhanced';

interface Props { accessLevel: AccessLevel; }

export default function StealthToolkit({ accessLevel }: Props) {
  const [revealed, setRevealed] = useState<Set<string>>(new Set());
  const [masterKey, setMasterKey] = useState('');
  const [error, setError] = useState(false);

  const revealAll = () => {
    if (masterKey.toLowerCase() === 'doulat-omega-007' || masterKey === 'omega') {
      setRevealed(new Set(stealthTools.map(t => t.id)));
      setError(false);
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  const toggleReveal = (id: string) => {
    if (accessLevel === 'omega') {
      setRevealed(p => { const n = new Set(p); if (n.has(id)) n.delete(id); else n.add(id); return n; });
    }
  };

  const catColors: Record<string, string> = { 'Exfiltration': 'border-yellow-500/20 text-yellow-400', 'C2 Communication': 'border-red-500/20 text-red-400', 'Evasion': 'border-purple-500/20 text-purple-400', 'Persistence': 'border-orange-500/20 text-orange-400', 'Data Exfiltration': 'border-yellow-500/20 text-yellow-400' };

  return (
    <div className="h-full bg-[#050508] p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-purple-400 font-bold text-sm tracking-wider">👻 INVISIBLE TOOLS — STEALTH & EVASION ARSENAL</h2>
        <span className="text-[9px] text-purple-700">{revealed.size}/{stealthTools.length} UNLOCKED</span>
      </div>

      <div className="mb-3 p-3 border border-purple-500/20 rounded bg-purple-950/5">
        <p className="text-[10px] text-purple-400 mb-2 font-bold">⚠️ OMEGA-CLASS TOOLKIT — STRICTLY CLASSIFIED</p>
        <p className="text-[9px] text-green-700 mb-2">These tools are invisible to standard detection. Each requires OMEGA clearance to reveal.</p>
        {accessLevel === 'omega' ? (
          <div className="flex gap-2">
            <input type="text" value={masterKey} onChange={e => setMasterKey(e.target.value)} onKeyDown={e => e.key === 'Enter' && revealAll()}
              placeholder="Master key: doulat-omega-007" className="flex-1 px-2 py-1 bg-black border border-purple-500/30 rounded text-purple-400 text-[10px] outline-none font-mono" />
            <button onClick={revealAll} className="px-3 py-1 bg-purple-950/30 border border-purple-500/30 rounded text-purple-400 text-[10px] font-bold hover:bg-purple-950/50">REVEAL ALL</button>
          </div>
        ) : (
          <p className="text-[9px] text-red-400">🔒 OMEGA clearance required. Press CTRL+SHIFT+R to cycle access levels.</p>
        )}
        {error && <p className="text-red-400 text-[9px] mt-1 animate-pulse">INVALID MASTER KEY — ACCESS DENIED</p>}
      </div>

      <div className="flex-1 overflow-y-auto space-y-2">
        {stealthTools.map(tool => {
          const isRevealed = revealed.has(tool.id);
          return (
            <div key={tool.id} onClick={() => toggleReveal(tool.id)}
              className={`border rounded p-3 cursor-pointer transition-all ${isRevealed ? 'border-purple-500/50 bg-purple-950/10' : 'border-green-900/10 bg-black/40 hover:border-purple-800/30'} ${catColors[tool.category] || ''}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-lg">{isRevealed ? '👁️' : '👻'}</span>
                  <div>
                    <span className={`text-xs font-bold ${isRevealed ? 'text-green-400' : 'text-green-700'}`}>
                      {isRevealed ? tool.name : `[REDACTED — Level ${tool.level.toUpperCase()}]`}
                    </span>
                    <span className="text-[8px] text-purple-600 ml-2">{tool.category}</span>
                  </div>
                </div>
                <span className="text-[8px] text-purple-700">{tool.hidden ? '🔒 INVISIBLE' : '🔓'}</span>
              </div>
              {isRevealed && (
                <div className="mt-2 pt-2 border-t border-purple-900/20">
                  <p className="text-[10px] text-green-600 mb-2">{tool.description}</p>
                  <div className="space-y-1">
                    {tool.commands.map((cmd, i) => (
                      <div key={i} className="p-1.5 bg-[#020408] rounded font-mono text-[9px] text-purple-400 border border-purple-900/10">
                        $ {cmd}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
