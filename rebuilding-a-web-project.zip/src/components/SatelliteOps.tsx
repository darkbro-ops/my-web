import { useState } from 'react';
import type { AccessLevel } from '../data/types';
import { satellites } from '../data/enhanced';

interface Props { accessLevel: AccessLevel; }

export default function SatelliteOps({ accessLevel }: Props) {
  const [selected, setSelected] = useState<string | null>(null);
  const [typeFilter, setTypeFilter] = useState('ALL');

  const types = ['ALL', ...new Set(satellites.map(s => s.type))];
  const filtered = typeFilter === 'ALL' ? satellites : satellites.filter(s => s.type === typeFilter);
  const visible = filtered.filter(s => {
    if (accessLevel === 'omega') return true;
    if (accessLevel === 'classified') return s.level !== 'omega';
    return s.level === 'public' || s.level === 'researcher';
  });

  const typeEmoji = (t: string) => {
    const map: Record<string, string> = { 'Reconnaissance': '📸', 'Communication': '📡', 'Navigation': '🧭', 'Early Warning': '🚨', 'ELINT': '👂', 'Weather': '🌤', 'Anti-Satellite': '🎯' };
    return map[t] || '🛰';
  };

  return (
    <div className="h-full bg-[#050508] p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-cyan-400 font-bold text-sm tracking-wider">🛰 SATELLITE OPERATIONS — ORBITAL ASSET DATABASE</h2>
        <span className={`text-[9px] font-bold ${accessLevel === 'omega' ? 'text-purple-400 animate-pulse' : 'text-cyan-600'}`}>
          {accessLevel === 'omega' ? '● FULL SPECTRUM' : `● ${accessLevel.toUpperCase()}`}
        </span>
      </div>

      <div className="flex gap-1 flex-wrap mb-3">
        {types.map(t => (
          <button key={t} onClick={() => setTypeFilter(t)}
            className={`px-2 py-0.5 text-[9px] rounded border font-mono ${typeFilter === t ? 'bg-cyan-950/20 text-cyan-400 border-cyan-500/30' : 'text-green-700 border-green-900/20 hover:text-cyan-500'}`}>
            {t === 'ALL' ? '🛰 ALL' : `${typeEmoji(t)} ${t}`}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto space-y-2">
        {visible.map(s => (
          <div key={s.id} onClick={() => setSelected(selected === s.id ? null : s.id)}
            className={`border rounded p-3 cursor-pointer transition-all ${
              s.level === 'omega' ? 'border-purple-500/20 bg-purple-950/5' :
              'border-cyan-900/20 bg-cyan-950/5 hover:border-cyan-700/30'
            } ${selected === s.id ? 'border-cyan-500/50 bg-cyan-950/10' : ''}`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">{typeEmoji(s.type)}</span>
                <div>
                  <span className="text-green-400 text-xs font-bold">{s.name}</span>
                  <span className="text-green-700 text-[9px] ml-2">{s.operator}</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {s.level === 'omega' && <span className="text-[7px] bg-purple-950/30 text-purple-400 px-1 rounded border border-purple-500/20">Ω</span>}
                <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${s.status === 'Operational' ? 'bg-green-950/20 text-green-400' : s.status === 'Classified' ? 'bg-red-950/20 text-red-400' : 'bg-yellow-950/20 text-yellow-400'}`}>{s.status}</span>
              </div>
            </div>
            {selected === s.id && (
              <div className="mt-2 pt-2 border-t border-green-900/20">
                <div className="grid grid-cols-2 gap-1 text-[10px] mb-2">
                  <div className="text-green-600">Orbit: <span className="text-cyan-400">{s.orbit}</span></div>
                  <div className="text-green-600">Launch: <span className="text-green-400">{s.launchDate}</span></div>
                  <div className="text-green-600">Type: <span className="text-green-400">{s.type}</span></div>
                </div>
                <div className="flex flex-wrap gap-1">
                  {s.capabilities.map((c, i) => (
                    <span key={i} className="px-1.5 py-0.5 text-[8px] bg-cyan-950/20 border border-cyan-500/20 rounded text-cyan-400 font-mono">{c}</span>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-2 grid grid-cols-4 gap-1 text-center text-[8px]">
        <div className="p-1.5 border border-cyan-900/20 rounded"><div className="text-cyan-400 font-bold">{satellites.length}</div><div className="text-cyan-700">Tracked</div></div>
        <div className="p-1.5 border border-cyan-900/20 rounded"><div className="text-cyan-400 font-bold">{new Set(satellites.map(s => s.operator)).size}</div><div className="text-cyan-700">Operators</div></div>
        <div className="p-1.5 border border-cyan-900/20 rounded"><div className="text-cyan-400 font-bold">GEO/LEO</div><div className="text-cyan-700">Orbits</div></div>
        <div className="p-1.5 border border-cyan-900/20 rounded"><div className="text-purple-400 font-bold">{satellites.filter(s => s.level === 'omega').length}</div><div className="text-cyan-700">Classified</div></div>
      </div>
    </div>
  );
}
