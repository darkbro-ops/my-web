import { useState } from 'react';
import { courses } from '../data/enhanced';

export default function CyberAcademy() {
  const [selected, setSelected] = useState<string | null>(null);
  const [levelFilter, setLevelFilter] = useState('ALL');

  const levels = ['ALL', 'Beginner', 'Intermediate', 'Advanced', 'Expert', 'Omega'];
  const filtered = levelFilter === 'ALL' ? courses : courses.filter(c => c.level === levelFilter);

  const levelColors: Record<string, string> = {
    'Beginner': 'bg-green-950/20 text-green-400 border-green-500/20',
    'Intermediate': 'bg-cyan-950/20 text-cyan-400 border-cyan-500/20',
    'Advanced': 'bg-yellow-950/20 text-yellow-400 border-yellow-500/20',
    'Expert': 'bg-red-950/20 text-red-400 border-red-500/20',
    'Omega': 'bg-purple-950/20 text-purple-400 border-purple-500/20',
  };

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-green-500/20 rounded p-4">
        <h2 className="text-green-400 font-bold text-sm">🎓 CYBER ACADEMY — DOULATREX TRAINING DIVISION</h2>
        <p className="text-green-700 text-[10px]">Comprehensive cybersecurity curriculum from beginner to OMEGA level. Master every domain.</p>
      </div>

      <div className="flex gap-1 flex-wrap">
        {levels.map(l => (
          <button key={l} onClick={() => setLevelFilter(l)}
            className={`px-3 py-1 text-[9px] rounded border font-mono ${levelFilter === l ? 'text-white border-green-500/50 bg-green-950/20' : 'text-green-700 border-green-900/20 hover:text-green-500'}`}>
            {l === 'ALL' ? '📚 ALL LEVELS' : `${l === 'Omega' ? 'Ω' : '⬡'} ${l.toUpperCase()}`}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filtered.map(course => (
          <div key={course.id} onClick={() => setSelected(selected === course.id ? null : course.id)}
            className={`border rounded p-4 cursor-pointer transition-all bg-black/80 ${
              selected === course.id ? 'border-green-500/50 bg-green-950/5' : 'border-green-900/20 hover:border-green-700/30'
            }`}>
            <div className="flex items-start justify-between mb-2">
              <h3 className="text-green-400 font-bold text-xs">{course.title}</h3>
              <span className={`text-[8px] px-2 py-0.5 rounded border font-bold ${levelColors[course.level]}`}>
                {course.level.toUpperCase()}
              </span>
            </div>
            <div className="flex gap-3 text-[9px] text-green-700 mb-2">
              <span>⏱ {course.duration}</span>
              <span>📜 {course.cert}</span>
            </div>

            {selected === course.id && (
              <div className="mt-2 pt-2 border-t border-green-900/20 space-y-2">
                <div>
                  <span className="text-[9px] text-green-700 font-bold">📦 MODULES ({course.modules.length}):</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {course.modules.map((m, i) => (
                      <span key={i} className="px-2 py-0.5 text-[8px] bg-green-950/10 border border-green-900/20 rounded text-green-500">{m}</span>
                    ))}
                  </div>
                </div>
                <div>
                  <span className="text-[9px] text-green-700 font-bold">🎯 TOPICS:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {course.topics.map((t, i) => (
                      <span key={i} className="px-2 py-0.5 text-[8px] bg-cyan-950/10 border border-cyan-900/20 rounded text-cyan-500">{t}</span>
                    ))}
                  </div>
                </div>
                <button className="w-full py-1.5 bg-green-950/20 border border-green-500/20 rounded text-green-400 text-[10px] font-bold hover:bg-green-950/30">
                  🚀 ENROLL NOW — {course.cert}
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-2 text-center">
        {[
          { value: '8', label: 'Courses', icon: '📚' },
          { value: '40+', label: 'Modules', icon: '📦' },
          { value: '525h', label: 'Content', icon: '⏱' },
          { value: '5', label: 'Certs', icon: '📜' },
        ].map((s, i) => (
          <div key={i} className="bg-black/80 border border-green-900/20 rounded p-2">
            <div className="text-lg">{s.icon}</div>
            <div className="text-green-400 font-bold text-xs">{s.value}</div>
            <div className="text-green-700 text-[8px]">{s.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
