import { useState } from 'react';
import { agencies } from '../data/categories';

export default function AgencyArsenal() {
  const [selected, setSelected] = useState<string | null>(null);

  const countryFlag = (country: string) => {
    const flags: Record<string, string> = {
      'USA': '🇺🇸', 'UK': '🇬🇧', 'Israel': '🇮🇱', 'Russia': '🇷🇺', 'China': '🇨🇳', 'Germany': '🇩🇪', 'France': '🇫🇷'
    };
    return flags[country] || '🏴';
  };

  const typeColor = (type: string) =>
    type === 'intelligence' ? 'text-purple-400' :
    type === 'military' ? 'text-red-400' :
    type === 'cyber' ? 'text-green-400' :
    'text-yellow-400';

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-red-500 font-bold text-sm tracking-wider">🦅 AGENCY ARSENAL — NSA/CIA/INTEL</h2>
        <span className="text-[9px] text-red-700">CLASSIFIED DATABASE</span>
      </div>

      <div className="flex-1 overflow-y-auto space-y-2">
        {agencies.map((agency) => (
          <div
            key={agency.id}
            onClick={() => setSelected(agency.id === selected ? null : agency.id)}
            className={`border rounded p-3 cursor-pointer transition-all ${
              agency.id === selected
                ? 'border-red-500/50 bg-red-950/10'
                : 'border-green-900/20 bg-green-950/5 hover:border-red-700/30'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">{countryFlag(agency.country)}</span>
                <div>
                  <span className="text-red-400 text-sm font-bold">{agency.name}</span>
                  <span className="text-green-700 text-[9px] ml-2">{agency.country}</span>
                </div>
              </div>
              <span className={`text-[9px] font-bold ${typeColor(agency.type)}`}>
                {agency.type.toUpperCase()}
              </span>
            </div>
            {agency.id === selected && (
              <div className="mt-2 pt-2 border-t border-green-900/20">
                <p className="text-[10px] text-green-600 mb-2">{agency.description}</p>
                <div>
                  <span className="text-[9px] text-red-600 font-bold">KNOWN TOOLS/OPERATIONS:</span>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {agency.knownTools.map((tool, i) => (
                      <span key={i} className="px-1.5 py-0.5 text-[8px] bg-red-950/20 border border-red-500/20 rounded text-red-400 font-mono">
                        {tool}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
