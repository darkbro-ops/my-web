import { useState } from 'react';
import type { AccessLevel } from '../data/types';

interface Props {
  accessLevel: AccessLevel;
  secretsRevealed: Set<string>;
}

const labs = [
  { id: 'web', name: 'Web App Lab', icon: 'fa-globe', desc: 'Practice web app pentesting with DVWA, Juice Shop, and custom vulnerable apps.', color: 'green' },
  { id: 'network', name: 'Network Lab', icon: 'fa-network-wired', desc: 'Network exploitation practice with virtual networks and firewalls.', color: 'cyan' },
  { id: 'crypto', name: 'Crypto Lab', icon: 'fa-lock', desc: 'Cryptography challenges: RSA, AES, elliptic curves, hashing.', color: 'yellow' },
  { id: 'reverse', name: 'Reverse Engineering', icon: 'fa-microchip', desc: 'Binary analysis, decompilation, and malware reverse engineering.', color: 'red' },
  { id: 'forensics', name: 'Forensics Lab', icon: 'fa-search', desc: 'Digital forensics: memory analysis, disk forensics, file carving.', color: 'purple' },
  { id: 'exploit', name: 'Exploit Dev Lab', icon: 'fa-skull', desc: 'Buffer overflows, ROP chains, format strings, heap exploitation.', color: 'red' },
  { id: 'wireless', name: 'Wireless Lab', icon: 'fa-wifi', desc: 'WiFi cracking, BLE attacks, RFID cloning, SDR exploration.', color: 'cyan' },
  { id: 'cloud', name: 'Cloud Security Lab', icon: 'fa-cloud', desc: 'AWS/Azure/GCP security testing and cloud penetration testing.', color: 'blue' },
];

export default function VirtualLab({ accessLevel }: Props) {
  const [active, setActive] = useState<string | null>(null);

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-green-900/20 rounded p-4">
        <h2 className="text-green-400 font-bold text-sm mb-1">🧪 VIRTUAL LABS</h2>
        <p className="text-green-700 text-[10px]">Practice your skills in isolated virtual environments.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {labs.filter(l => accessLevel !== 'public' || ['web', 'network', 'crypto'].includes(l.id)).map(lab => (
          <div
            key={lab.id}
            onClick={() => setActive(active === lab.id ? null : lab.id)}
            className={`border rounded p-4 cursor-pointer transition-all ${
              active === lab.id
                ? 'border-green-500/50 bg-green-950/10'
                : 'border-green-900/20 bg-black/80 hover:border-green-700/30'
            }`}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">
                <i className={`fas ${lab.icon} text-${lab.color}-400`} />
              </span>
              <div>
                <h3 className="text-green-400 font-bold text-xs">{lab.name}</h3>
                <p className="text-green-700 text-[9px]">{lab.desc}</p>
              </div>
            </div>
            {active === lab.id && (
              <div className="mt-3 pt-3 border-t border-green-900/20">
                <div className="flex gap-2">
                  <button className="px-3 py-1 bg-green-950/20 border border-green-500/30 rounded text-green-400 text-[10px] font-bold hover:bg-green-950/30">
                    START LAB
                  </button>
                  <button className="px-3 py-1 bg-cyan-950/20 border border-cyan-500/30 rounded text-cyan-400 text-[10px] font-bold hover:bg-cyan-950/30">
                    RESET
                  </button>
                </div>
                <div className="mt-2 p-2 bg-[#020408] rounded font-mono text-[9px] text-green-600">
                  $ docker-compose -f lab/{lab.id}.yml up -d<br/>
                  $ lab-connect {lab.id}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
