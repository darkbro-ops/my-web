import { useState } from 'react';
import { learningSites } from '../data/shadowsect';
import { realOnionSites } from '../data/shadowsect';

export default function SHSecretSites() {
  const [search, setSearch] = useState('');
  const [tab, setTab] = useState<'learning'|'onion'>('learning');

  const filtered = learningSites.filter(s=>!search||s.name.toLowerCase().includes(search.toLowerCase())||s.type.toLowerCase().includes(search.toLowerCase())||s.desc.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-4 animate-fadein">
      <div className="card-glow-cyan p-4"><h2 className="text-white font-black text-sm">🌐 SECRET HACKING SITES — 100+ Learning Resources</h2><p className="text-[#8888a0] text-[10px] mt-1">Training platforms, CTF challenges, wargames, reference databases, and onion sites.</p></div>

      <div className="flex gap-2 items-center">
        <button onClick={()=>setTab('learning')} className={`px-3 py-1.5 text-[9px] font-bold rounded border ${tab==='learning'?'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30':'text-[#5a5a72] border-[#1e1e30]'}`}>📚 LEARNING ({learningSites.length})</button>
        <button onClick={()=>setTab('onion')} className={`px-3 py-1.5 text-[9px] font-bold rounded border ${tab==='onion'?'bg-[#b388ff]/10 text-[#b388ff] border-[#b388ff]/30':'text-[#5a5a72] border-[#1e1e30]'}`}>🧅 ONION SITES ({realOnionSites.length})</button>
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search..."
          className="ml-auto px-3 py-1.5 bg-[#111118] border border-[#1e1e30] rounded-lg text-[#e0e0f0] text-[10px] outline-none focus:border-[#00d4ff]/30 w-48"/>
      </div>

      {tab==='learning'?(
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-1.5">
          {filtered.map(s=>(
            <a key={s.name} href={`https://${s.url}`} target="_blank" rel="noopener noreferrer"
              className="card-dark p-2.5 hover:border-[#00d4ff]/30 transition-all group flex items-center justify-between">
              <div className="min-w-0">
                <span className="text-white font-bold text-[10px] block truncate">{s.name}</span>
                <span className="text-[8px] text-[#5a5a72]">{s.desc}</span>
              </div>
              <div className="flex items-center gap-1.5 ml-2 flex-shrink-0">
                <span className={`tag text-[7px] ${s.type==='Training'?'tag-green':s.type==='CTF'?'tag-red':s.type==='Challenge'?'tag-yellow':s.type==='Lab'?'tag-purple':s.type==='Reference'?'tag-cyan':s.type==='Bug Bounty'?'tag-red':'tag-cyan'}`}>{s.type}</span>
                {s.free && <span className="tag tag-green text-[7px]">FREE</span>}
              </div>
            </a>
          ))}
        </div>
      ):(
        <div className="space-y-1.5">
          {realOnionSites.map(s=>(
            <div key={s.name} className="card-dark p-3 flex items-center justify-between">
              <div className="flex items-center gap-3"><span className="text-lg">🧅</span><div><span className="text-white font-bold text-xs">{s.name}</span><span className="text-[9px] text-[#5a5a72] block">{s.desc}</span></div></div>
              <div className="text-right"><span className="tag tag-purple text-[7px]">{s.category}</span>{s.verified&&<span className="tag tag-green text-[7px] ml-1">✓</span>}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
