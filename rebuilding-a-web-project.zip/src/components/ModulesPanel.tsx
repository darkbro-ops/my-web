import { useState, useMemo } from 'react';
import { allModules, moduleCategories, moduleTypes } from '../data/modulesdb';

export default function ModulesPanel() {
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('ALL');
  const [type, setType] = useState('ALL');
  const [page, setPage] = useState(0);
  const [expanded, setExpanded] = useState<string | null>(null);
  const [copied, setCopied] = useState('');
  const perPage = 30;

  const filtered = useMemo(() => {
    return allModules.filter(m => {
      if (cat !== 'ALL' && m.category !== cat) return false;
      if (type !== 'ALL' && m.type !== type) return false;
      if (search) {
        const s = search.toLowerCase();
        return m.name.toLowerCase().includes(s) || m.desc.toLowerCase().includes(s) || m.cmd.toLowerCase().includes(s);
      }
      return true;
    });
  }, [cat, type, search]);

  const totalPages = Math.ceil(filtered.length / perPage);
  const currentModules = filtered.slice(page * perPage, (page + 1) * perPage);

  const copy = (c: string) => { navigator.clipboard.writeText(c); setCopied(c); setTimeout(() => setCopied(''), 1500); };

  // Generate installation steps based on module type
  const getInstallSteps = (m: typeof allModules[0]) => {
    const baseSteps: { title: string; cmd: string }[] = [];

    if (m.category === 'OSINT') {
      baseSteps.push(
        { title: 'STEP 1 — Install Python & pip', cmd: 'sudo apt update && sudo apt install python3 python3-pip -y' },
        { title: 'STEP 2 — Create virtual environment', cmd: 'python3 -m venv osint-env && source osint-env/bin/activate' },
        { title: 'STEP 3 — Install core dependencies', cmd: 'pip install requests beautifulsoup4 selenium scrapy' },
      );
      if (m.name.includes('Sherlock') || m.name.includes('Username')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/sherlock-project/sherlock.git && cd sherlock' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Holehe') || m.name.includes('Email')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/megadose/holehe.git && cd holehe' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Maigret') || m.name.includes('Dossier')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/soxoj/maigret.git && cd maigret' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Subfinder') || m.name.includes('Subdomain')) {
        baseSteps.push({ title: 'STEP 4 — Install Go', cmd: 'sudo apt install golang-go -y' });
        baseSteps.push({ title: 'STEP 5 — Install tool', cmd: 'go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest' });
      } else if (m.name.includes('Nmap') || m.name.includes('Port') || m.name.includes('Scan')) {
        baseSteps.push({ title: 'STEP 4 — Install Nmap', cmd: 'sudo apt install nmap -y' });
        baseSteps.push({ title: 'STEP 5 — Verify installation', cmd: 'nmap --version' });
      } else if (m.name.includes('DNS') || m.name.includes('dnsrecon')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/darkoperator/dnsrecon.git && cd dnsrecon' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Exif') || m.name.includes('Metadata') || m.name.includes('Image')) {
        baseSteps.push({ title: 'STEP 4 — Install ExifTool', cmd: 'sudo apt install exiftool -y' });
        baseSteps.push({ title: 'STEP 5 — Verify installation', cmd: 'exiftool -ver' });
      } else if (m.name.includes('Shodan')) {
        baseSteps.push({ title: 'STEP 4 — Install Shodan CLI', cmd: 'pip install shodan' });
        baseSteps.push({ title: 'STEP 5 — Initialize API key', cmd: 'shodan init YOUR_API_KEY' });
      } else if (m.name.includes('Censys')) {
        baseSteps.push({ title: 'STEP 4 — Install Censys', cmd: 'pip install censys' });
        baseSteps.push({ title: 'STEP 5 — Configure credentials', cmd: 'censys config' });
      } else if (m.name.includes('Wayback') || m.name.includes('Archive')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/tomnomnom/waybackurls.git && cd waybackurls' });
        baseSteps.push({ title: 'STEP 5 — Build tool', cmd: 'go build' });
      } else {
        baseSteps.push({ title: 'STEP 4 — Clone relevant tool', cmd: 'git clone https://github.com/example/osint-tool.git && cd osint-tool' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt || make install' });
      }
    } else if (m.category === 'SOCIAL_MEDIA_CRACKER') {
      baseSteps.push(
        { title: 'STEP 1 — Install Python & pip', cmd: 'sudo apt update && sudo apt install python3 python3-pip -y' },
        { title: 'STEP 2 — Create virtual environment', cmd: 'python3 -m venv social-env && source social-env/bin/activate' },
        { title: 'STEP 3 — Install dependencies', cmd: 'pip install requests selenium beautifulsoup4 mechanicalsoup' },
      );
      if (m.name.includes('Instagram')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/avramit/instagram-brute.git && cd instagram-brute' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Facebook')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/xHak9x/fbbrute.git && cd fbbrute' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Twitter')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/darksecgithub/Brute-Forcer.git && cd Brute-Forcer' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('TikTok')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/netz98/TikTok-Brute.git && cd TikTok-Brute' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Phish')) {
        baseSteps.push({ title: 'STEP 4 — Clone SET', cmd: 'git clone https://github.com/trustedsec/social-engineer-toolkit.git && cd social-engineer-toolkit' });
        baseSteps.push({ title: 'STEP 5 — Install SET', cmd: 'pip install -r requirements.txt && python3 setup.py' });
      } else if (m.name.includes('Spray') || m.name.includes('Stuffing')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/GreyNoah/BlueGrey.git && cd BlueGrey' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/example/social-cracker.git && cd social-cracker' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      }
    } else if (m.category === 'DESTROYER') {
      baseSteps.push(
        { title: 'STEP 1 — Install Python & pip', cmd: 'sudo apt update && sudo apt install python3 python3-pip -y' },
        { title: 'STEP 2 — Create virtual environment', cmd: 'python3 -m venv destroy-env && source destroy-env/bin/activate' },
        { title: 'STEP 3 — Install dependencies', cmd: 'pip install scapy requests aiohttp asyncio' },
      );
      if (m.name.includes('DDoS') || m.name.includes('Flood')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/Ha3MrX/DDos-Attack.git && cd DDos-Attack' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Deauth') || m.name.includes('WiFi')) {
        baseSteps.push({ title: 'STEP 4 — Install Aircrack-ng', cmd: 'sudo apt install aircrack-ng -y' });
        baseSteps.push({ title: 'STEP 5 — Verify installation', cmd: 'aircrack-ng --version' });
      } else if (m.name.includes('SMS') || m.name.includes('Email') || m.name.includes('Call') || m.name.includes('Bomber')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/example/bomber.git && cd bomber' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else if (m.name.includes('Wiper') || m.name.includes('Destroy')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/example/wiper.git && cd wiper' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/example/destroyer.git && cd destroyer' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      }
    } else if (m.category === 'INVISIBLE') {
      baseSteps.push(
        { title: 'STEP 1 — Install Python & pip', cmd: 'sudo apt update && sudo apt install python3 python3-pip -y' },
        { title: 'STEP 2 — Create virtual environment', cmd: 'python3 -m venv stealth-env && source stealth-env/bin/activate' },
        { title: 'STEP 3 — Install dependencies', cmd: 'pip install scapy netifaces cryptography' },
      );
      if (m.name.includes('Ghost') || m.name.includes('Stealth')) {
        baseSteps.push({ title: 'STEP 4 — Install Nmap', cmd: 'sudo apt install nmap -y' });
        baseSteps.push({ title: 'STEP 5 — Configure stealth mode', cmd: 'echo "Stealth mode configured"' });
      } else if (m.name.includes('VPN') || m.name.includes('Proxy')) {
        baseSteps.push({ title: 'STEP 4 — Install OpenVPN', cmd: 'sudo apt install openvpn proxychains4 -y' });
        baseSteps.push({ title: 'STEP 5 — Configure proxychains', cmd: 'sudo nano /etc/proxychains4.conf' });
      } else if (m.name.includes('Tunnel')) {
        baseSteps.push({ title: 'STEP 4 — Install tunneling tools', cmd: 'sudo apt install iodine ptunnel -y' });
        baseSteps.push({ title: 'STEP 5 — Configure tunnel', cmd: 'sudo modprobe nf_conntrack' });
      } else if (m.name.includes('Rootkit') || m.name.includes('Backdoor')) {
        baseSteps.push({ title: 'STEP 4 — Install build tools', cmd: 'sudo apt install build-essential linux-headers-$(uname -r) -y' });
        baseSteps.push({ title: 'STEP 5 — Compile rootkit', cmd: 'make && sudo insmod rootkit.ko' });
      } else if (m.name.includes('Keylog') || m.name.includes('Screen') || m.name.includes('Mic') || m.name.includes('Camera')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/example/stealth.git && cd stealth' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/example/invisible.git && cd invisible' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      }
    } else if (m.category === 'SECRET') {
      baseSteps.push(
        { title: 'STEP 1 — Install Python & pip', cmd: 'sudo apt update && sudo apt install python3 python3-pip -y' },
        { title: 'STEP 2 — Create virtual environment', cmd: 'python3 -m venv secret-env && source secret-env/bin/activate' },
        { title: 'STEP 3 — Install dependencies', cmd: 'pip install cryptography scapy impacket' },
      );
      if (m.name.includes('Zero-Day') || m.name.includes('Exploit')) {
        baseSteps.push({ title: 'STEP 4 — Install Metasploit', cmd: 'curl https://raw.githubusercontent.com/rapid7/metasploit-framework/master/msfinstall | bash' });
        baseSteps.push({ title: 'STEP 5 — Initialize database', cmd: './msfdb init' });
      } else if (m.name.includes('Shellcode') || m.name.includes('Payload')) {
        baseSteps.push({ title: 'STEP 4 — Install msfvenom', cmd: 'sudo apt install metasploit-framework -y' });
        baseSteps.push({ title: 'STEP 5 — Test payload generation', cmd: 'msfvenom -p cmd/unix/reverse_netcat LHOST=127.0.0.1 LPORT=4444 R' });
      } else if (m.name.includes('C2') || m.name.includes('Beacon')) {
        baseSteps.push({ title: 'STEP 4 — Clone C2 framework', cmd: 'git clone https://github.com/BC-SECURITY/Empire.git && cd Empire' });
        baseSteps.push({ title: 'STEP 5 — Install Empire', cmd: './setup/install.sh' });
      } else if (m.name.includes('Lateral') || m.name.includes('Mover')) {
        baseSteps.push({ title: 'STEP 4 — Install Impacket', cmd: 'pip install impacket' });
        baseSteps.push({ title: 'STEP 5 — Test movement', cmd: 'impacket-psexec domain/user:pass@target' });
      } else if (m.name.includes('Credential') || m.name.includes('Password') || m.name.includes('Hash')) {
        baseSteps.push({ title: 'STEP 4 — Install tools', cmd: 'sudo apt install hashcat john mimikatz -y' });
        baseSteps.push({ title: 'STEP 5 — Verify installation', cmd: 'hashcat --version && john --version' });
      } else if (m.name.includes('Token') || m.name.includes('Cookie') || m.name.includes('JWT')) {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/example/token-hack.git && cd token-hack' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      } else {
        baseSteps.push({ title: 'STEP 4 — Clone tool', cmd: 'git clone https://github.com/example/secret.git && cd secret' });
        baseSteps.push({ title: 'STEP 5 — Install requirements', cmd: 'pip install -r requirements.txt' });
      }
    }

    baseSteps.push(
      { title: 'STEP 6 — Configure tool', cmd: `# Configure ${m.name} for your target\n# Edit config files as needed` },
      { title: 'STEP 7 — Set target', cmd: `# Set your target: ${m.target}\n# Example: export TARGET=example.com` },
      { title: 'STEP 8 — Run initial test', cmd: `# Test ${m.name} in safe environment\n# Use --help to see all options` },
      { title: 'STEP 9 — Verify output', cmd: `# Check tool output\n# Verify results are as expected` },
      { title: 'STEP 10 — Clean up', cmd: `# Remove temporary files\n# Clear logs if needed` },
    );

    return baseSteps;
  };

  // Generate usage guide based on module type
  const getUsageSteps = (m: typeof allModules[0]) => {
    const usage: { title: string; cmd: string }[] = [];

    if (m.category === 'OSINT') {
      usage.push(
        { title: 'BASIC USAGE', cmd: m.cmd },
        { title: 'ADVANCED USAGE', cmd: `${m.cmd} --advanced --output=results.txt` },
        { title: 'EXPORT RESULTS', cmd: `${m.cmd} --export=json > results.json` },
        { title: 'AUTOMATE', cmd: `for target in $(cat targets.txt); do ${m.cmd}; done` },
      );
    } else if (m.category === 'SOCIAL_MEDIA_CRACKER') {
      usage.push(
        { title: 'BASIC USAGE', cmd: m.cmd },
        { title: 'WITH WORDLIST', cmd: `${m.cmd} -p /usr/share/wordlists/rockyou.txt` },
        { title: 'MULTITHREADED', cmd: `${m.cmd} -t 10` },
        { title: 'USE PROXY', cmd: `${m.cmd} --proxy=socks5://127.0.0.1:9050` },
      );
    } else if (m.category === 'DESTROYER') {
      usage.push(
        { title: 'BASIC USAGE', cmd: m.cmd },
        { title: 'INCREASE INTENSITY', cmd: `${m.cmd} --threads=1000` },
        { title: 'USE PROXY', cmd: `${m.cmd} --proxy=proxy.txt` },
        { title: 'VERIFY RESULTS', cmd: `# Check target status after attack` },
      );
    } else if (m.category === 'INVISIBLE') {
      usage.push(
        { title: 'BASIC USAGE', cmd: m.cmd },
        { title: 'STEALTH MODE', cmd: `${m.cmd} --stealth --evade` },
        { title: 'USE TOR', cmd: `torsocks ${m.cmd}` },
        { title: 'CLEAR TRACES', cmd: `${m.cmd} && sudo rm -rf /var/log/*` },
      );
    } else if (m.category === 'SECRET') {
      usage.push(
        { title: 'BASIC USAGE', cmd: m.cmd },
        { title: 'ADVANCED USAGE', cmd: `${m.cmd} --advanced --evade` },
        { title: 'C2 MODE', cmd: `${m.cmd} --c2 --listener=4444` },
        { title: 'EXTRACT DATA', cmd: `${m.cmd} --extract --output=data.bin` },
      );
    }

    return usage;
  };

  const typeColor = (t: string) => {
    if (t === 'LEGAL') return '#00e040';
    if (t === 'INVISIBLE') return '#a070ff';
    if (t === 'SECRET') return '#ffb000';
    if (t === 'DESTROYER') return '#ff3050';
    return '#8080a0';
  };

  const catColor = (c: string) => {
    if (c === 'OSINT') return '#00e0ff';
    if (c === 'SOCIAL_MEDIA_CRACKER') return '#ff3050';
    if (c === 'DESTROYER') return '#ff3050';
    if (c === 'INVISIBLE') return '#a070ff';
    if (c === 'SECRET') return '#ffb000';
    return '#8080a0';
  };

  return (
    <div className="space-y-4 animate-fadein">
      {/* Header */}
      <div className="card border-red-900/20 p-4">
        <h2 className="text-3xl font-black text-white" style={{fontFamily:'Impact, sans-serif'}}>MODULES</h2>
        <p className="text-gray-500 text-sm mt-1">2000+ MODULES — Full Installation + Usage for EVERY module</p>
        <div className="flex gap-3 mt-2">
          <span className="tag tag-green">LEGAL: {allModules.filter(m=>m.type==='LEGAL').length}</span>
          <span className="tag tag-purple">INVISIBLE: {allModules.filter(m=>m.type==='INVISIBLE').length}</span>
          <span className="tag tag-yellow">SECRET: {allModules.filter(m=>m.type==='SECRET').length}</span>
          <span className="tag tag-red">DESTROYER: {allModules.filter(m=>m.type==='DESTROYER').length}</span>
        </div>
      </div>

      {/* Search */}
      <div className="flex gap-2">
        <input type="text" value={search} onChange={e => { setSearch(e.target.value); setPage(0); }}
          placeholder="Search 2000+ modules by name, description, command..."
          className="flex-1 px-4 py-2 bg-[#0a0a12] border border-[#181830] rounded text-white text-sm outline-none focus:border-red-500/50"/>
      </div>

      {/* Categories */}
      <div className="flex flex-wrap gap-1">
        {moduleCategories.map(c => (
          <button key={c.id} onClick={() => { setCat(c.id); setPage(0); }}
            className={`px-2.5 py-1 text-[10px] font-bold rounded border ${cat === c.id ? 'text-white' : 'text-gray-600 border-[#181830]'}`}
            style={cat === c.id ? { borderColor: catColor(c.id), color: catColor(c.id), backgroundColor: `${catColor(c.id)}15` } : {}}>
            {c.label} ({c.count})
          </button>
        ))}
      </div>

      {/* Types */}
      <div className="flex flex-wrap gap-1">
        {moduleTypes.map(t => (
          <button key={t} onClick={() => { setType(t); setPage(0); }}
            className={`px-2.5 py-1 text-[10px] font-bold rounded border ${type === t ? 'text-white' : 'text-gray-600 border-[#181830]'}`}
            style={type === t ? { borderColor: typeColor(t), color: typeColor(t), backgroundColor: `${typeColor(t)}15` } : {}}>
            {t}
          </button>
        ))}
      </div>

      {/* Results info */}
      <div className="flex items-center justify-between text-xs text-gray-500">
        <span>{filtered.length} modules found</span>
        <span>Page {page + 1} of {totalPages}</span>
      </div>

      {/* Modules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {currentModules.map(m => {
          const isOpen = expanded === m.id;
          const installSteps = getInstallSteps(m);
          const usageSteps = getUsageSteps(m);

          return (
            <div key={m.id} className={`card p-3 transition-all ${isOpen ? 'border-purple-500/40 md:col-span-2' : 'hover:border-red-500/20'}`}>
              {/* Header */}
              <div className="flex items-start justify-between mb-1 cursor-pointer" onClick={() => setExpanded(isOpen ? null : m.id)}>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-white font-black text-sm">{m.name}</span>
                    <span className="tag text-[7px]" style={{ color: typeColor(m.type), borderColor: typeColor(m.type), background: `${typeColor(m.type)}10` }}>{m.type}</span>
                  </div>
                  <div className="flex gap-1 mt-0.5">
                    <span className="tag tag-cyan text-[7px]">{m.category.replace('_', ' ')}</span>
                    <span className={`tag text-[7px] ${m.difficulty === 'Easy' ? 'tag-green' : m.difficulty === 'Medium' ? 'tag-yellow' : m.difficulty === 'Advanced' ? 'tag-red' : 'tag-purple'}`}>{m.difficulty}</span>
                  </div>
                </div>
                <span className="text-gray-500 text-xs">{isOpen ? '▲' : '▼'}</span>
              </div>
              <p className="text-[10px] text-gray-400 mb-1">{m.desc}</p>
              <div className="code text-[9px] py-1 px-2 truncate">{m.cmd}</div>

              {/* Expanded Content — Installation + Usage */}
              {isOpen && (
                <div className="mt-3 pt-3 border-t border-[#181830] space-y-3">
                  {/* INSTALLATION */}
                  <div>
                    <h4 className="text-cyan-400 font-black text-xs mb-2">📥 FULL INSTALLATION:</h4>
                    <div className="space-y-1.5">
                      {installSteps.map((s, i) => (
                        <div key={i}>
                          <span className="text-[9px] text-cyan-300 font-bold">{s.title}</span>
                          <div className="code text-[9px] mt-0.5 group cursor-pointer relative py-1" onClick={e => { e.stopPropagation(); copy(s.cmd); }}>
                            {s.cmd}
                            <button className="absolute right-1 top-0.5 text-[7px] px-1.5 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-gray-400 opacity-0 group-hover:opacity-100">{copied === s.cmd ? '✓' : 'COPY'}</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* USAGE */}
                  <div>
                    <h4 className="text-green-400 font-black text-xs mb-2">💻 USAGE GUIDE:</h4>
                    <div className="space-y-1.5">
                      {usageSteps.map((u, i) => (
                        <div key={i}>
                          <span className="text-[9px] text-green-300 font-bold">{u.title}</span>
                          <div className="code text-[9px] mt-0.5 group cursor-pointer relative py-1" onClick={e => { e.stopPropagation(); copy(u.cmd); }}>
                            {u.cmd}
                            <button className="absolute right-1 top-0.5 text-[7px] px-1.5 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-gray-400 opacity-0 group-hover:opacity-100">{copied === u.cmd ? '✓' : 'COPY'}</button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* WARNING */}
                  {m.type === 'DESTROYER' && (
                    <div className="p-2 border border-red-500/20 rounded bg-red-950/10">
                      <p className="text-red-400 text-[9px]">⚠ WARNING: This module is for educational purposes only. Unauthorized use is illegal.</p>
                    </div>
                  )}
                  {m.type === 'INVISIBLE' && (
                    <div className="p-2 border border-purple-500/20 rounded bg-purple-950/10">
                      <p className="text-purple-400 text-[9px]">👻 STEALTH: This module operates invisibly. Use responsibly and legally.</p>
                    </div>
                  )}
                  {m.type === 'SECRET' && (
                    <div className="p-2 border border-yellow-500/20 rounded bg-yellow-950/10">
                      <p className="text-yellow-400 text-[9px]">🔮 SECRET: Advanced module. Requires proper authorization for use.</p>
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-center gap-2 py-4">
        <button onClick={() => setPage(Math.max(0, page - 1))} disabled={page === 0}
          className="px-3 py-1 text-xs font-bold rounded border border-[#181830] text-gray-400 hover:text-white hover:border-red-500/30 disabled:opacity-30">
          ← PREV
        </button>
        <div className="flex gap-1">
          {Array.from({ length: Math.min(10, totalPages) }, (_, i) => {
            const p = Math.max(0, Math.min(totalPages - 10, page - 5)) + i;
            return (
              <button key={p} onClick={() => setPage(p)}
                className={`w-8 h-8 text-[10px] font-bold rounded border ${p === page ? 'bg-red-950/20 text-red-400 border-red-500/30' : 'border-[#181830] text-gray-500 hover:text-white'}`}>
                {p + 1}
              </button>
            );
          })}
        </div>
        <button onClick={() => setPage(Math.min(totalPages - 1, page + 1))} disabled={page >= totalPages - 1}
          className="px-3 py-1 text-xs font-bold rounded border border-[#181830] text-gray-400 hover:text-white hover:border-red-500/30 disabled:opacity-30">
          NEXT →
        </button>
      </div>
    </div>
  );
}
