import { useState } from 'react';
import { allOperatingSystems } from '../data/ultimatedata';

export default function OSUltimateArsenal() {
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('ALL');
  const [selected, setSelected] = useState<string|null>(null);

  const types = ['ALL',...new Set(allOperatingSystems.map(o=>o.type))];
  const filtered = allOperatingSystems.filter(o =>
    (typeFilter==='ALL'||o.type===typeFilter) &&
    (!search||o.name.toLowerCase().includes(search.toLowerCase())||o.desc.toLowerCase().includes(search.toLowerCase())||o.country.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-4 animate-fadein">
      <div className="card-glow-cyan p-4">
        <h2 className="text-white font-black text-sm">💻 ULTIMATE OS ARSENAL — 50+ OPERATING SYSTEMS WORLDWIDE</h2>
        <p className="text-[#8888a0] text-[10px] mt-1">Every security, military, government, and classified OS — from Kali to Kylin, Qubes to Red Star.</p>
      </div>

      <div className="flex gap-2">
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)}
          placeholder="Search OS by name, country, or description..."
          className="flex-1 px-4 py-2 bg-[#111118] border border-[#1e1e30] rounded-lg text-[#e0e0f0] text-xs outline-none focus:border-[#00d4ff]/50"/>
      </div>

      <div className="flex flex-wrap gap-1.5">
        {types.map(t=>(
          <button key={t} onClick={()=>setTypeFilter(t)}
            className={`px-2.5 py-1 text-[9px] font-bold rounded-full border ${typeFilter===t?'bg-[#00d4ff]/10 border-[#00d4ff]/40 text-[#00d4ff]':'border-[#1e1e30] text-[#5a5a72]'}`}>
            {t}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {filtered.map(os=>(
          <div key={os.name} onClick={()=>setSelected(selected===os.name?null:os.name)}
            className={`card-dark p-3 cursor-pointer transition-all ${selected===os.name?'ring-1 ring-[#00d4ff]/30':''}`}
            style={selected===os.name?{borderColor:'rgba(0,212,255,0.4)'}:{}}>
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-2">
                <span className="text-xl">{os.icon}</span>
                <div>
                  <span className="text-white font-bold text-xs">{os.name}</span>
                  <span className="text-[8px] text-[#5a5a72] block">{os.country}</span>
                </div>
              </div>
              <span className={`tag ${os.level==='Classified'?'tag-purple':os.level==='Expert'?'tag-red':os.level==='Advanced'?'tag-yellow':'tag-green'}`}>{os.level}</span>
            </div>
            <p className="text-[10px] text-[#8888a0]">{os.desc}</p>
            <div className="flex flex-wrap gap-1 mt-1.5">
              {os.tags.map((t,i)=>(<span key={i} className="tag tag-cyan text-[7px]">{t}</span>))}
            </div>
            {selected===os.name && (
              <div className="mt-2 pt-2 border-t border-[#1e1e30] space-y-1.5">
                <div className="code-block text-[9px]">{os.type} | {os.url}</div>
                {os.commands.map((c,i)=>(<div key={i} className="code-block text-[9px]">$ {c}</div>))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
