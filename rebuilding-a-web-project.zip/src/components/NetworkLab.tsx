import { useState } from 'react';

export default function NetworkLab() {
  const [scanning, setScanning] = useState(false);
  const [results, setResults] = useState<string[]>([]);
  const [target, setTarget] = useState('192.168.1.0/24');

  const startScan = () => {
    setScanning(true);
    setResults([]);
    const steps = [
      '[*] Initializing network mapper...',
      '[*] Loading Nmap scripts...',
      '[*] Starting ARP ping scan on ' + target,
      '[+] Host 192.168.1.1 — Router (TP-Link Archer)',
      '[+] Host 192.168.1.10 — 22/ssh, 80/http, 443/https, 8080/admin',
      '[+] Host 192.168.1.15 — 445/smb, 139/netbios, 3389/rdp',
      '[+] Host 192.168.1.20 — 21/ftp, 3306/mysql',
      '[+] Host 192.168.1.25 — 6379/redis, 27017/mongodb',
      '[*] Running vulnerability scripts...',
      '[!] Host 192.168.1.15: SMBv1 enabled (EternalBlue)',
      '[!] Host 192.168.1.20: Anonymous FTP login allowed',
      '[!] Host 192.168.1.25: Redis unprotected — no auth',
      '[*] Scan complete. 5 hosts up. 3 vulnerabilities found.',
    ];
    steps.forEach((step, i) => {
      setTimeout(() => {
        setResults(prev => [...prev, step]);
        if (i === steps.length - 1) setScanning(false);
      }, i * 300);
    });
  };

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-cyan-400 font-bold text-sm tracking-wider">📡 NETWORK LAB</h2>
        <span className="text-[9px] text-cyan-700">SIMULATED</span>
      </div>

      <div className="flex gap-2 mb-3">
        <input
          type="text"
          value={target}
          onChange={(e) => setTarget(e.target.value)}
          className="flex-1 px-3 py-1.5 bg-black border border-cyan-500/30 rounded text-cyan-400 text-xs outline-none font-mono"
          placeholder="Target IP/Range..."
        />
        <button
          onClick={startScan}
          disabled={scanning}
          className="px-4 py-1.5 bg-cyan-950/30 border border-cyan-500/30 rounded text-cyan-400 hover:bg-cyan-950/50 text-xs font-bold disabled:opacity-50"
        >
          {scanning ? 'SCANNING...' : 'SCAN'}
        </button>
      </div>

      <div className="flex-1 bg-[#020408] border border-cyan-900/20 rounded p-3 overflow-y-auto font-mono text-xs">
        {results.length === 0 && !scanning && (
          <div className="text-cyan-800 text-center mt-8">
            <p className="text-4xl mb-2">📡</p>
            <p>Enter a target and click SCAN to begin network reconnaissance.</p>
          </div>
        )}
        {results.map((line, i) => (
          <div
            key={i}
            className={`${
              line.startsWith('[!]') ? 'text-red-400' :
              line.startsWith('[+]') ? 'text-green-400' :
              line.startsWith('[*]') ? 'text-cyan-500' :
              'text-cyan-700'
            }`}
          >
            {line}
          </div>
        ))}
        {scanning && <span className="animate-pulse text-cyan-400">▌</span>}
      </div>

      <div className="mt-3 grid grid-cols-4 gap-2 text-[9px]">
        <div className="p-2 border border-cyan-900/20 rounded text-center">
          <div className="text-cyan-500">TCP</div>
          <div className="text-cyan-400">1000 ports</div>
        </div>
        <div className="p-2 border border-cyan-900/20 rounded text-center">
          <div className="text-cyan-500">UDP</div>
          <div className="text-cyan-400">100 ports</div>
        </div>
        <div className="p-2 border border-cyan-900/20 rounded text-center">
          <div className="text-cyan-500">Scripts</div>
          <div className="text-cyan-400">50+ loaded</div>
        </div>
        <div className="p-2 border border-cyan-900/20 rounded text-center">
          <div className="text-cyan-500">Rate</div>
          <div className="text-cyan-400">1000 pps</div>
        </div>
      </div>
    </div>
  );
}
