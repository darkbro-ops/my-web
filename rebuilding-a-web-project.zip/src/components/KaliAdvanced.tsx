import { useState } from 'react';
import { kaliModules } from '../data/enhanced';

export default function KaliAdvanced() {
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const filtered = kaliModules.filter(m =>
    !search || m.name.toLowerCase().includes(search.toLowerCase()) || m.category.toLowerCase().includes(search.toLowerCase()) || m.description.toLowerCase().includes(search.toLowerCase())
  );

  const copyCmd = (cmd: string) => { navigator.clipboard.writeText(cmd); setCopied(cmd); setTimeout(() => setCopied(null), 1500); };

  const diffColors: Record<string, string> = {
    'Beginner': 'bg-green-950/20 text-green-400 border-green-500/20',
    'Intermediate': 'bg-cyan-950/20 text-cyan-400 border-cyan-500/20',
    'Advanced': 'bg-yellow-950/20 text-yellow-400 border-yellow-500/20',
    'Expert': 'bg-red-950/20 text-red-400 border-red-500/20',
  };

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-blue-500/20 rounded p-4">
        <h2 className="text-green-400 font-bold text-sm">🐉 KALI LINUX — ADVANCED COMMAND ARSENAL</h2>
        <p className="text-green-700 text-[10px]">Complete Kali Linux toolkit reference — from beginner setup to expert exploitation.</p>
      </div>

      <input type="text" value={search} onChange={e => setSearch(e.target.value)}
        placeholder="🔍 Search Kali modules & commands..." className="w-full px-3 py-1.5 bg-black/80 border border-green-900/30 rounded text-green-400 text-[10px] outline-none font-mono" />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filtered.map(mod => (
          <div key={mod.id} className="bg-black/80 border border-green-900/20 rounded overflow-hidden">
            <button onClick={() => setActiveModule(activeModule === mod.id ? null : mod.id)}
              className="w-full flex items-center gap-3 px-4 py-3 hover:bg-green-950/5 transition-all text-left">
              <span className="text-2xl">🐉</span>
              <div className="flex-1">
                <span className="text-green-400 font-bold text-xs">{mod.name}</span>
                <div className="flex items-center gap-2 mt-0.5">
                  <span className="text-[8px] text-green-700">{mod.category}</span>
                  <span className={`text-[7px] px-1.5 py-0.5 rounded border ${diffColors[mod.difficulty]}`}>{mod.difficulty}</span>
                </div>
              </div>
              <span className="text-green-700 text-[9px]">{mod.commands.length} cmds</span>
            </button>
            {activeModule === mod.id && (
              <div className="px-4 pb-3 space-y-1.5">
                <p className="text-[10px] text-green-600 mb-2">{mod.description}</p>
                {mod.commands.map((cmd, i) => (
                  <div key={i} className="flex items-center justify-between p-2 bg-[#020408] rounded border border-green-900/10 hover:border-green-700/20 group">
                    <div className="flex-1 min-w-0">
                      <p className="font-mono text-[9px] text-green-400 truncate">$ {cmd.cmd}</p>
                      <p className="text-[8px] text-green-700">{cmd.desc}</p>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); copyCmd(cmd.cmd); }}
                      className="ml-2 px-2 py-0.5 text-[8px] bg-green-950/20 border border-green-500/20 rounded text-green-400 hover:bg-green-950/30 opacity-0 group-hover:opacity-100 transition-all">
                      {copied === cmd.cmd ? '✓' : 'COPY'}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
