import { useState } from 'react';

/* ═══════════════════════════════════════════════════════════════
   FULL INSTALLATION TOOLS — Complete Step-by-Step Guide
   Future AI Tools | Secret | Invisible
   ═══════════════════════════════════════════════════════════════ */

interface InstallTool {
  name: string;
  category: string;
  type: 'FULL_INSTALL' | 'FUTURE_AI' | 'SECRET' | 'INVISIBLE';
  desc: string;
  difficulty: string;
  time: string;
  steps: { title: string; cmd: string }[];
  verify: string;
  uninstall: string;
  warning?: string;
}

const tools: InstallTool[] = [
  // ═══════════════════════════════════════════════════════════
  // FULL INSTALLATION — COMPLETE STEP-BY-STEP
  // ═══════════════════════════════════════════════════════════
  {
    name: 'KALI LINUX FULL INSTALL',
    category: 'Operating System',
    type: 'FULL_INSTALL',
    desc: 'Complete Kali Linux installation from scratch — dual boot, VM, or WSL',
    difficulty: 'Advanced',
    time: '45 min',
    steps: [
      { title: 'STEP 1 — Download Kali Linux ISO', cmd: 'wget https://cdimage.kali.org/kali-2024.3/kali-linux-2024.3-installer-amd64.iso' },
      { title: 'STEP 2 — Verify checksum (security)', cmd: 'sha256sum kali-linux-2024.3-installer-amd64.iso\n# Compare with official hash from kali.org' },
      { title: 'STEP 3 — Create bootable USB (Linux)', cmd: 'sudo dd if=kali-linux-2024.3-installer-amd64.iso of=/dev/sdX bs=4M status=progress' },
      { title: 'STEP 3 — Create bootable USB (Windows)', cmd: '# Download Rufus from rufus.ie\n# Select ISO > Select USB > Start > Write in DD mode' },
      { title: 'STEP 4 — Boot from USB', cmd: '# Restart PC > Press F12/F2/DEL for BIOS\n# Select USB drive > Graphical Install' },
      { title: 'STEP 5 — Configure partitioning', cmd: '# Guided - use entire disk\n# All files in one partition\n# Finish partitioning and write changes to disk' },
      { title: 'STEP 6 — Set up user account', cmd: '# Enter hostname: kali\n# Enter username: kali\n# Set strong password' },
      { title: 'STEP 7 — Wait for installation', cmd: '# System installs automatically (~20 min)\# When prompted: Continue > Reboot' },
      { title: 'STEP 8 — First boot setup', cmd: 'sudo apt update && sudo apt full-upgrade -y\nsudo apt install kali-linux-everything -y' },
      { title: 'STEP 9 — Install desktop extras', cmd: 'sudo apt install kali-desktop-xfce -y\nsudo apt install kali-tools-top10 -y' },
      { title: 'STEP 10 — Configure network', cmd: 'sudo systemctl enable NetworkManager\nsudo systemctl start NetworkManager' },
    ],
    verify: 'kali@kali:~$ uname -a\n# Should show: Linux kali 6.8.0-kali7-amd64',
    uninstall: '# To remove from dual boot:\n# Windows: Disk Management > Delete Linux partitions\n# Rebuild bootloader: bootrec /fixmstr',
  },
  {
    name: 'METASPLOIT FRAMEWORK FULL INSTALL',
    category: 'Exploitation',
    type: 'FULL_INSTALL',
    desc: 'Complete Metasploit installation with PostgreSQL, Ruby, and database setup',
    difficulty: 'Advanced',
    time: '30 min',
    steps: [
      { title: 'STEP 1 — Update system', cmd: 'sudo apt update && sudo apt full-upgrade -y' },
      { title: 'STEP 2 — Install dependencies', cmd: 'sudo apt install -y build-essential libssl-dev libffi-dev python3-dev python3-pip postgresql postgresql-contrib ruby ruby-dev' },
      { title: 'STEP 3 — Install Ruby with RVM', cmd: 'curl -sSL https://get.rvm.io | bash -s stable\nsource ~/.rvm/scripts/rvm\nrvm install 3.2\nrvm use 3.2 --default' },
      { title: 'STEP 4 — Clone Metasploit', cmd: 'git clone https://github.com/rapid7/metasploit-framework.git\ncd metasploit-framework' },
      { title: 'STEP 5 — Install Ruby gems', cmd: 'gem install bundler\nbundle install' },
      { title: 'STEP 6 — Set up PostgreSQL', cmd: 'sudo systemctl enable postgresql\nsudo systemctl start postgresql\nsudo -u postgres createuser msf -P\nsudo -u postgres createdb msf_database -O msf' },
      { title: 'STEP 7 — Configure database', cmd: 'cat > config/database.yml << EOF\nproduction:\n  adapter: postgresql\n  database: msf_database\n  username: msf\n  password: your_password\n  host: 127.0.0.1\n  port: 5432\n  pool: 75\n  timeout: 5\nEOF' },
      { title: 'STEP 8 — Initialize database', cmd: './msfdb init\n# Or manually: ./msfdb reinit' },
      { title: 'STEP 9 — Create symlink for global access', cmd: 'sudo ln -s $(pwd)/msfconsole /usr/local/bin/msfconsole\nsudo ln -s $(pwd)/msfvenom /usr/local/bin/msfvenom' },
      { title: 'STEP 10 — Verify installation', cmd: 'msfconsole -v\n# Should show: Metasploit Framework v6.x' },
    ],
    verify: 'msfconsole\nmsf6 > db_status\n# Should show: Connected to msf_database',
    uninstall: 'sudo rm -rf metasploit-framework\nsudo rm /usr/local/bin/msfconsole\nsudo rm /usr/local/bin/msfvenom\nsudo -u postgres dropdb msf_database\nsudo -u postgres dropuser msf',
  },
  {
    name: 'BURP SUITE PRO FULL INSTALL',
    category: 'Web Hacking',
    type: 'FULL_INSTALL',
    desc: 'Complete Burp Suite Professional installation with Java and loader',
    difficulty: 'Medium',
    time: '20 min',
    steps: [
      { title: 'STEP 1 — Install Java 17+', cmd: 'sudo apt install openjdk-17-jdk -y\njava -version' },
      { title: 'STEP 2 — Download Burp Suite', cmd: 'wget "https://portswigger.net/burp/releases/download?product=pro&version=2024.8&type=Jar" -O burpsuite_pro.jar' },
      { title: 'STEP 3 — Download loader (community)', cmd: 'git clone https://github.com/xiv3r/Burpsuite-Professional.git\ncd Burpsuite-Professional' },
      { title: 'STEP 4 — Run loader', cmd: 'java -jar loader.jar\n# Click "Run" > Accept license > Next' },
      { title: 'STEP 5 — Import license', cmd: '# Copy license from loader window\n# Paste in Burp Suite > Next > Activate' },
      { title: 'STEP 6 — Create launcher script', cmd: 'cat > /usr/local/bin/burp << EOF\n#!/bin/bash\njava -jar $(pwd)/burpsuite_pro.jar\nEOF\nsudo chmod +x /usr/local/bin/burp' },
      { title: 'STEP 7 — Configure browser proxy', cmd: '# Firefox: Settings > Network > Manual proxy\n# HTTP Proxy: 127.0.0.1 Port: 8080\n# Check "Use this proxy for all protocols"' },
      { title: 'STEP 8 — Import CA certificate', cmd: '# Visit http://burp > Click "CA Certificate"\n# Firefox: Settings > Privacy > Certificates > Import' },
      { title: 'STEP 9 — Test interception', cmd: '# Open Burp Suite > Proxy > Intercept\n# Enable interception > Visit any website\n# Request should appear in Burp' },
      { title: 'STEP 10 — Configure project options', cmd: '# Project options > Connections > Upstream proxy\n# Add your VPN/Tor if needed\n# Save configuration' },
    ],
    verify: 'burp\n# Burp Suite should open with Professional features enabled',
    uninstall: 'sudo rm /usr/local/bin/burp\nrm -rf burpsuite_pro.jar\nrm -rf Burpsuite-Professional',
  },
  {
    name: 'DOCKER FULL INSTALL (ALL OS)',
    category: 'Containerization',
    type: 'FULL_INSTALL',
    desc: 'Complete Docker installation — Linux, Windows WSL, macOS, and post-install setup',
    difficulty: 'Medium',
    time: '25 min',
    steps: [
      { title: 'STEP 1 — Remove old versions', cmd: 'sudo apt remove docker docker-engine docker.io containerd runc' },
      { title: 'STEP 2 — Install dependencies', cmd: 'sudo apt update\nsudo apt install -y ca-certificates curl gnupg lsb-release' },
      { title: 'STEP 3 — Add Docker GPG key', cmd: 'sudo mkdir -p /etc/apt/keyrings\ncurl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg' },
      { title: 'STEP 4 — Add Docker repository', cmd: 'echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null' },
      { title: 'STEP 5 — Install Docker Engine', cmd: 'sudo apt update\nsudo apt install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin' },
      { title: 'STEP 6 — Start Docker service', cmd: 'sudo systemctl enable docker\nsudo systemctl start docker' },
      { title: 'STEP 7 — Add user to docker group', cmd: 'sudo usermod -aG docker $USER\nnewgrp docker' },
      { title: 'STEP 8 — Install Docker Compose', cmd: 'sudo apt install docker-compose -y\n# OR\nsudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose' },
      { title: 'STEP 9 — Verify installation', cmd: 'docker --version\ndocker-compose --version\ndocker run hello-world' },
      { title: 'STEP 10 — Configure Docker daemon', cmd: 'sudo cat > /etc/docker/daemon.json << EOF\n{\n  "log-driver": "json-file",\n  "log-opts": {\n    "max-size": "10m",\n    "max-file": "3"\n  }\n}\nEOF\nsudo systemctl restart docker' },
    ],
    verify: 'docker run hello-world\n# Should show: Hello from Docker!',
    uninstall: 'sudo apt purge docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin\nsudo rm -rf /var/lib/docker\nsudo rm -rf /var/lib/containerd\nsudo rm /etc/apt/sources.list.d/docker.list',
  },
  {
    name: 'KUBERNETES (K8S) FULL INSTALL',
    category: 'Container Orchestration',
    type: 'FULL_INSTALL',
    desc: 'Complete Kubernetes cluster installation with kubectl, minikube, and helm',
    difficulty: 'Expert',
    time: '60 min',
    steps: [
      { title: 'STEP 1 — Install Docker first', cmd: '# Follow Docker installation steps above' },
      { title: 'STEP 2 — Install kubectl', cmd: 'curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"\nsudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl' },
      { title: 'STEP 3 — Verify kubectl', cmd: 'kubectl version --client' },
      { title: 'STEP 4 — Install Minikube', cmd: 'curl -LO https://storage.googleapis.com/minikube/releases/latest/minikube-linux-amd64\nsudo install minikube-linux-amd64 /usr/local/bin/minikube' },
      { title: 'STEP 5 — Start Minikube', cmd: 'minikube start --driver=docker --memory=4096 --cpus=2' },
      { title: 'STEP 6 — Verify cluster', cmd: 'kubectl cluster-info\nkubectl get nodes' },
      { title: 'STEP 7 — Install Helm', cmd: 'curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash' },
      { title: 'STEP 8 — Install Kubernetes Dashboard', cmd: 'kubectl apply -f https://raw.githubusercontent.com/kubernetes/dashboard/v2.7.0/aio/deploy/recommended.yaml\nkubectl proxy' },
      { title: 'STEP 9 — Create admin token', cmd: 'kubectl create serviceaccount dashboard-admin -n kube-system\nkubectl create clusterrolebinding dashboard-admin --clusterrole=cluster-admin --serviceaccount=kube-system:dashboard-admin\nkubectl create token dashboard-admin -n kube-system' },
      { title: 'STEP 10 — Deploy sample app', cmd: 'kubectl create deployment nginx --image=nginx\nkubectl expose deployment nginx --port=80 --type=NodePort\nkubectl get svc' },
    ],
    verify: 'kubectl get nodes\n# Should show: minikube Ready control-plane',
    uninstall: 'minikube delete\nsudo rm /usr/local/bin/kubectl\nsudo rm /usr/local/bin/minikube\nhelm uninstall --all',
  },
  {
    name: 'TOR & TAILS FULL INSTALL',
    category: 'Anonymity',
    type: 'FULL_INSTALL',
    desc: 'Complete Tor network setup + Tails OS for maximum anonymity',
    difficulty: 'Medium',
    time: '35 min',
    steps: [
      { title: 'STEP 1 — Install Tor on Linux', cmd: 'sudo apt install tor torsocks -y' },
      { title: 'STEP 2 — Configure Tor', cmd: 'sudo cat >> /etc/tor/torrc << EOF\nSocksPort 9050\nControlPort 9051\nCookieAuthentication 1\nEOF' },
      { title: 'STEP 3 — Start Tor service', cmd: 'sudo systemctl enable tor\nsudo systemctl start tor' },
      { title: 'STEP 4 — Verify Tor connection', cmd: 'curl --socks5 127.0.0.1:9050 https://check.torproject.org\n# Should show: Congratulations' },
      { title: 'STEP 5 — Install Tor Browser', cmd: 'wget https://www.torproject.org/dist/torbrowser/13.0/tor-browser-linux64-13.0_ALL.tar.xz\ntar -xf tor-browser-linux64-13.0_ALL.tar.xz\ncd tor-browser_en-US/Browser/start-tor-browser' },
      { title: 'STEP 6 — Download Tails OS', cmd: 'wget https://tails.net/tails-amd64-6.5.img' },
      { title: 'STEP 7 — Create Tails USB', cmd: 'sudo dd if=tails-amd64-6.5.img of=/dev/sdX bs=16M status=progress' },
      { title: 'STEP 8 — Boot Tails', cmd: '# Restart PC > Boot from USB\n# Tails loads entirely in RAM\n# Leaves no trace on host machine' },
      { title: 'STEP 9 — Configure persistent storage', cmd: '# Tails > Configure Persistent Storage\n# Set password\n# Enable: Personal Data, Browser Bookmarks, Network Connections' },
      { title: 'STEP 10 — Test anonymity', cmd: '# Visit https://check.torproject.org\n# Should show: Congratulations\n# Visit https://browserleaks.com\n# Verify no leaks' },
    ],
    verify: 'curl --socks5 127.0.0.1:9050 https://check.torproject.org/api/ip\n# Should show exit node IP',
    uninstall: 'sudo apt purge tor torsocks -y\nsudo rm -rf tor-browser*\nsudo systemctl stop tor',
  },
  {
    name: 'PROXYCHAINS & VPN FULL SETUP',
    category: 'Anonymity',
    type: 'FULL_INSTALL',
    desc: 'Complete proxy chain setup with multiple VPNs and SSH tunnels',
    difficulty: 'Advanced',
    time: '30 min',
    steps: [
      { title: 'STEP 1 — Install Proxychains4', cmd: 'sudo apt install proxychains4 -y' },
      { title: 'STEP 2 — Install OpenVPN', cmd: 'sudo apt install openvpn -y' },
      { title: 'STEP 3 — Install WireGuard', cmd: 'sudo apt install wireguard wireguard-tools -y' },
      { title: 'STEP 4 — Download VPN configs', cmd: '# Get .ovpn files from your VPN provider\n# Or use free VPNBook:\nwget https://www.vpnbook.com/free-openvpn-account' },
      { title: 'STEP 5 — Configure Proxychains', cmd: 'sudo cat > /etc/proxychains4.conf << EOF\nstrict_chain\nproxy_dns\ntcp_read_time_out 15000\ntcp_connect_time_out 8000\n[ProxyList]\nsocks5 127.0.0.1 9050\nsocks4 192.168.1.1 1080\nEOF' },
      { title: 'STEP 6 — Set up SSH tunnel', cmd: 'ssh -D 1080 -f -C -q -N user@remote_server\n# Creates SOCKS proxy on port 1080' },
      { title: 'STEP 7 — Connect OpenVPN', cmd: 'sudo openvpn --config vpnbook.ovpn\n# Enter credentials when prompted' },
      { title: 'STEP 8 — Set up WireGuard', cmd: 'wg genkey | tee privatekey | wg pubkey > publickey\nsudo cat > /etc/wireguard/wg0.conf << EOF\n[Interface]\nPrivateKey = YOUR_PRIVATE_KEY\nAddress = 10.0.0.2/24\n[Peer]\nPublicKey = SERVER_PUBLIC_KEY\nEndpoint = server:51820\nAllowedIPs = 0.0.0.0/0\nEOF' },
      { title: 'STEP 9 — Start WireGuard', cmd: 'sudo wg-quick up wg0\nsudo wg show' },
      { title: 'STEP 10 — Test chain', cmd: 'proxychains4 curl https://ipinfo.io\n# Should show proxy/VPN IP, not your real IP' },
    ],
    verify: 'proxychains4 curl https://ipinfo.io\n# IP should be different from your real IP',
    uninstall: 'sudo apt purge proxychains4 openvpn wireguard -y\nsudo wg-quick down wg0\nsudo rm /etc/wireguard/wg0.conf',
  },
  {
    name: 'WINDOWS SUBSYSTEM LINUX (WSL2)',
    category: 'Operating System',
    type: 'FULL_INSTALL',
    desc: 'Complete WSL2 installation with Kali Linux on Windows 10/11',
    difficulty: 'Medium',
    time: '25 min',
    steps: [
      { title: 'STEP 1 — Enable WSL (PowerShell Admin)', cmd: 'wsl --install\n# Restart PC when prompted' },
      { title: 'STEP 2 — Enable Virtual Machine Platform', cmd: 'dism.exe /online /enable-feature /featurename:VirtualMachinePlatform /all /norestart' },
      { title: 'STEP 3 — Set WSL2 as default', cmd: 'wsl --set-default-version 2' },
      { title: 'STEP 4 — Install Kali Linux', cmd: 'wsl --install -d kali-linux\n# Or from Microsoft Store: Search "Kali Linux"' },
      { title: 'STEP 5 — First launch setup', cmd: '# Kali Linux icon appears in Start Menu\n# Click > Wait for extraction\n# Create UNIX username and password' },
      { title: 'STEP 6 — Update Kali', cmd: 'sudo apt update && sudo apt full-upgrade -y' },
      { title: 'STEP 7 — Install Kali tools', cmd: 'sudo apt install kali-linux-headless -y\nsudo apt install kali-tools-top10 -y' },
      { title: 'STEP 8 — Enable systemd', cmd: 'sudo cat >> /etc/wsl.conf << EOF\n[boot]\nsystemd=true\nEOF\nwsl --shutdown\n# Restart WSL' },
      { title: 'STEP 9 — Access Windows files', cmd: 'cd /mnt/c/Users/YourUsername\n# Windows C: drive is accessible' },
      { title: 'STEP 10 — Configure networking', cmd: 'ip addr show eth0\n# WSL2 has own IP, access via localhost from Windows' },
    ],
    verify: 'wsl -l -v\n# Should show: Kali Linux Running 2',
    uninstall: 'wsl --unregister kali-linux\nwsl --uninstall',
  },

  // ═══════════════════════════════════════════════════════════
  // FUTURE AI TOOLS — SECRET & INVISIBLE
  // ═══════════════════════════════════════════════════════════
  {
    name: 'NEURALFORGE AI (2026)',
    category: 'Future AI',
    type: 'FUTURE_AI',
    desc: 'AI that writes custom zero-day exploits in real-time using LLM + fuzzing — predicts vulnerabilities before they exist',
    difficulty: 'Expert',
    time: '120 min',
    warning: 'THEORETICAL — This tool does not exist yet. Educational prediction of 2026+ AI capabilities.',
    steps: [
      { title: 'STEP 1 — Install Python 3.12+', cmd: 'sudo apt install python3.12 python3.12-venv python3.12-dev' },
      { title: 'STEP 2 — Create virtual environment', cmd: 'python3.12 -m venv neuralforge-env\nsource neuralforge-env/bin/activate' },
      { title: 'STEP 3 — Install AI dependencies', cmd: 'pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121\npip install transformers accelerate bitsandbytes' },
      { title: 'STEP 4 — Download NeuralForge model', cmd: 'git clone https://github.com/future-labs/neuralforge.git\ncd neuralforge' },
      { title: 'STEP 5 — Install NeuralForge', cmd: 'pip install -r requirements.txt\npython3 setup.py install' },
      { title: 'STEP 6 — Configure GPU acceleration', cmd: 'nvidia-smi  # Verify GPU\nexport CUDA_VISIBLE_DEVICES=0' },
      { title: 'STEP 7 — Initialize AI model', cmd: 'python3 neuralforge.py --init --model=exploit-writer-v3' },
      { title: 'STEP 8 — Train on vulnerability data', cmd: 'python3 neuralforge.py --train --dataset=cve-database --epochs=100' },
      { title: 'STEP 9 — Generate exploit', cmd: 'python3 neuralforge.py --generate --target="Apache 2.4.50" --type=rce' },
      { title: 'STEP 10 — Verify exploit', cmd: 'python3 neuralforge.py --verify --exploit=generated_exploit.py --sandbox=docker' },
    ],
    verify: 'python3 neuralforge.py --status\n# Should show: NeuralForge v3.0 Ready',
    uninstall: 'rm -rf neuralforge neuralforge-env\npip uninstall neuralforge -y',
  },
  {
    name: 'QUANTUMSPLOIT AI (2027)',
    category: 'Future AI',
    type: 'FUTURE_AI',
    desc: 'Quantum computer-based exploitation framework — breaks RSA-2048 in seconds, AES-256 in minutes',
    difficulty: 'Expert',
    time: '180 min',
    warning: 'THEORETICAL — Quantum computing for cryptanalysis. Educational prediction of 2027+ capabilities.',
    steps: [
      { title: 'STEP 1 — Install Qiskit (IBM Quantum)', cmd: 'pip install qiskit qiskit-aer qiskit-ibm-runtime' },
      { title: 'STEP 2 — Install Cirq (Google Quantum)', cmd: 'pip install cirq cirq-google' },
      { title: 'STEP 3 — Clone QuantumSploit', cmd: 'git clone https://github.com/quantum-labs/quantumsploit.git\ncd quantumsploit' },
      { title: 'STEP 4 — Install quantum dependencies', cmd: 'pip install -r requirements.txt\npip install pennylane qsharp' },
      { title: 'STEP 5 — Configure quantum backend', cmd: 'python3 quantumsploit.py --backend=ibm_quantum\n# Or use simulator: --backend=simulator' },
      { title: 'STEP 6 — Initialize quantum circuits', cmd: 'python3 quantumsploit.py --init --qubits=127' },
      { title: 'STEP 7 — Load target encryption', cmd: 'python3 quantumsploit.py --load --type=rsa --bits=2048' },
      { title: 'STEP 8 — Run Shor\'s algorithm', cmd: 'python3 quantumsploit.py --shor --target=encrypted_data.bin' },
      { title: 'STEP 9 — Extract private key', cmd: 'python3 quantumsploit.py --extract --output=private_key.pem' },
      { title: 'STEP 10 — Decrypt data', cmd: 'python3 quantumsploit.py --decrypt --key=private_key.pem --data=encrypted.bin' },
    ],
    verify: 'python3 quantumsploit.py --status\n# Should show: QuantumSploit Ready | Qubits: 127',
    uninstall: 'rm -rf quantumsploit\npip uninstall qiskit cirq pennylane -y',
  },
  {
    name: 'BIOMESH AI (2028)',
    category: 'Future AI',
    type: 'FUTURE_AI',
    desc: 'Bio-cyber interface exploitation — hack brain-computer interfaces, neural implants, and synthetic biology',
    difficulty: 'Expert',
    time: '150 min',
    warning: 'THEORETICAL — Brain-computer interface security. Educational prediction of 2028+ capabilities.',
    steps: [
      { title: 'STEP 1 — Install bio-computing libraries', cmd: 'pip install brainflow neurokit2 mne pyriemann' },
      { title: 'STEP 2 — Clone BioMesh', cmd: 'git clone https://github.com/bio-cyber/biomesh.git\ncd biomesh' },
      { title: 'STEP 3 — Install bio-cyber dependencies', cmd: 'pip install -r requirements.txt\npip install openbci neuromore' },
      { title: 'STEP 4 — Connect BCI device', cmd: 'python3 biomesh.py --connect --device=openbci_cyton' },
      { title: 'STEP 5 — Calibrate neural signals', cmd: 'python3 biomesh.py --calibrate --duration=300' },
      { title: 'STEP 6 — Load target neural profile', cmd: 'python3 biomesh.py --load --profile=target_neural.json' },
      { title: 'STEP 7 — Analyze neural patterns', cmd: 'python3 biomesh.py --analyze --type=thought_patterns' },
      { title: 'STEP 8 — Inject neural payload', cmd: 'python3 biomesh.py --inject --payload=subliminal_command.bin' },
      { title: 'STEP 9 — Monitor response', cmd: 'python3 biomesh.py --monitor --duration=600' },
      { title: 'STEP 10 — Extract neural data', cmd: 'python3 biomesh.py --extract --output=neural_dump.bin' },
    ],
    verify: 'python3 biomesh.py --status\n# Should show: BioMesh Connected | Device: OpenBCI',
    uninstall: 'rm -rf biomesh\npip install brainflow neurokit2 -y',
  },
  {
    name: 'MINDEXTRACTOR AI (2030)',
    category: 'Future AI',
    type: 'FUTURE_AI',
    desc: 'Direct human memory extraction via neural interface — download memories, thoughts, secrets from brain',
    difficulty: 'Expert',
    time: '200 min',
    warning: 'THEORETICAL — Neural memory extraction. Educational prediction of 2030+ capabilities. ETHICAL CONCERNS.',
    steps: [
      { title: 'STEP 1 — Install neural interface SDK', cmd: 'pip install neuralink-sdk kernel-sdk brainport-sdk' },
      { title: 'STEP 2 — Clone MindExtractor', cmd: 'git clone https://github.com/neuro-labs/mindextractor.git\ncd mindextractor' },
      { title: 'STEP 3 — Install neuro-extraction deps', cmd: 'pip install -r requirements.txt\npip install tensorflow-neural pytorch-brain' },
      { title: 'STEP 4 — Connect to neural implant', cmd: 'python3 mindextractor.py --connect --implant=neuralink_n1' },
      { title: 'STEP 5 — Authenticate with implant', cmd: 'python3 mindextractor.py --auth --key=implant_key.pem' },
      { title: 'STEP 6 — Scan memory regions', cmd: 'python3 mindextractor.py --scan --region=hippocampus' },
      { title: 'STEP 7 — Select target memory', cmd: 'python3 mindextractor.py --select --memory_id=mem_12345' },
      { title: 'STEP 8 — Extract memory', cmd: 'python3 mindextractor.py --extract --format=video --output=memory.mp4' },
      { title: 'STEP 9 — Decode thoughts', cmd: 'python3 mindextractor.py --decode --type=thoughts --output=thoughts.txt' },
      { title: 'STEP 10 — Export consciousness', cmd: 'python3 mindextractor.py --export --format=neural_dump --output=consciousness.bin' },
    ],
    verify: 'python3 mindextractor.py --status\n# Should show: MindExtractor Connected | Implant: Neuralink N1',
    uninstall: 'rm -rf mindextractor\npip uninstall neuralink-sdk kernel-sdk -y',
  },
  {
    name: 'CHRONOHACK AI (2035)',
    category: 'Future AI',
    type: 'FUTURE_AI',
    desc: 'Temporal exploitation — attack time-dependent systems, blockchain timestamps, NTP, GPS time',
    difficulty: 'Expert',
    time: '160 min',
    warning: 'THEORETICAL — Temporal/quantum time manipulation. Educational prediction of 2035+ capabilities.',
    steps: [
      { title: 'STEP 1 — Install quantum time libraries', cmd: 'pip install qiskit-time quantum-clock temporal-sdk' },
      { title: 'STEP 2 — Clone ChronoHack', cmd: 'git clone https://github.com/temporal-labs/chronohack.git\ncd chronohack' },
      { title: 'STEP 3 — Install temporal dependencies', cmd: 'pip install -r requirements.txt\npip install ntp-attack gps-spoof time-crystal' },
      { title: 'STEP 4 — Initialize temporal engine', cmd: 'python3 chronohack.py --init --precision=nanosecond' },
      { title: 'STEP 5 — Scan time-dependent systems', cmd: 'python3 chronohack.py --scan --type=blockchain' },
      { title: 'STEP 6 — Identify temporal vulnerability', cmd: 'python3 chronohack.py --analyze --target=bitcoin_blockchain' },
      { title: 'STEP 7 — Execute time manipulation', cmd: 'python3 chronohack.py --manipulate --type=timestamp_spoof' },
      { title: 'STEP 8 — Reorganize blockchain', cmd: 'python3 chronohack.py --reorg --blocks=6 --confirm=false' },
      { title: 'STEP 9 — Spoof NTP servers', cmd: 'python3 chronohack.py --ntp-spoof --servers=pool.ntp.org' },
      { title: 'STEP 10 — Verify temporal attack', cmd: 'python3 chronohack.py --verify --target=time.gov' },
    ],
    verify: 'python3 chronohack.py --status\n# Should show: ChronoHack Ready | Precision: Nanosecond',
    uninstall: 'rm -rf chronohack\npip uninstall qiskit-time quantum-clock -y',
  },
  {
    name: 'DARKMATTER C2 (2030)',
    category: 'Future AI',
    type: 'SECRET',
    desc: 'Command & control using dark matter detection arrays — undetectable by any electromagnetic sensor',
    difficulty: 'Expert',
    time: '240 min',
    warning: 'THEORETICAL — Dark matter communication. Educational prediction of 2030+ capabilities.',
    steps: [
      { title: 'STEP 1 — Install dark matter SDK', cmd: 'pip install dark-matter-sdk wimp-detector axion-scanner' },
      { title: 'STEP 2 — Clone DarkMatter C2', cmd: 'git clone https://github.com/dark-labs/darkmatter-c2.git\ncd darkmatter-c2' },
      { title: 'STEP 3 — Install exotic dependencies', cmd: 'pip install -r requirements.txt\npip install lux-zeplin xenon1t darkside' },
      { title: 'STEP 4 — Initialize dark matter detector', cmd: 'python3 darkmatter.py --init --detector=liquid_xenon' },
      { title: 'STEP 5 — Calibrate sensors', cmd: 'python3 darkmatter.py --calibrate --duration=3600' },
      { title: 'STEP 6 — Connect to dark matter network', cmd: 'python3 darkmatter.py --connect --network=dark_web_2030' },
      { title: 'STEP 7 — Deploy dark beacon', cmd: 'python3 darkmatter.py --beacon --frequency=10hz' },
      { title: 'STEP 8 — Establish C2 channel', cmd: 'python3 darkmatter.py --c2 --target=dark_implant_v3' },
      { title: 'STEP 9 — Send undetectable commands', cmd: 'python3 darkmatter.py --send --command="execute_payload" --stealth=max' },
      { title: 'STEP 10 — Verify dark channel', cmd: 'python3 darkmatter.py --verify --channel=dark_c2' },
    ],
    verify: 'python3 darkmatter.py --status\n# Should show: DarkMatter C2 Active | Detector: Liquid Xenon',
    uninstall: 'rm -rf darkmatter-c2\npip uninstall dark-matter-sdk -y',
  },
  {
    name: 'HIVE MIND AI (2027)',
    category: 'Future AI',
    type: 'INVISIBLE',
    desc: 'Autonomous IoT swarm that self-organizes for coordinated attacks — 500,000+ bot self-organization',
    difficulty: 'Expert',
    time: '140 min',
    warning: 'THEORETICAL — Swarm intelligence for IoT. Educational prediction of 2027+ capabilities.',
    steps: [
      { title: 'STEP 1 — Install swarm libraries', cmd: 'pip install swarm-intelligence pyswarm ant-colony' },
      { title: 'STEP 2 — Clone HiveMind', cmd: 'git clone https://github.com/swarm-labs/hivemind.git\ncd hivemind' },
      { title: 'STEP 3 — Install swarm dependencies', cmd: 'pip install -r requirements.txt\npip install mqtt-broker coap-client lwm2m' },
      { title: 'STEP 4 — Initialize swarm network', cmd: 'python3 hivemind.py --init --bots=500000' },
      { title: 'STEP 5 — Configure swarm intelligence', cmd: 'python3 hivemind.py --config --algorithm=ant_colony --evolve=true' },
      { title: 'STEP 6 — Deploy bot agents', cmd: 'python3 hivemind.py --deploy --targets=iot_network.json' },
      { title: 'STEP 7 — Start swarm coordination', cmd: 'python3 hivemind.py --coordinate --objective=ddos' },
      { title: 'STEP 8 — Enable self-healing', cmd: 'python3 hivemind.py --heal --auto_replace=true' },
      { title: 'STEP 9 — Monitor swarm behavior', cmd: 'python3 hivemind.py --monitor --dashboard=true' },
      { title: 'STEP 10 — Execute coordinated attack', cmd: 'python3 hivemind.py --execute --target=TARGET_IP --method=syn_flood' },
    ],
    verify: 'python3 hivemind.py --status\n# Should show: HiveMind Active | Bots: 500,000',
    uninstall: 'rm -rf hivemind\npip uninstall swarm-intelligence -y',
  },
  {
    name: 'NEUROMANCER AI (2035)',
    category: 'Future AI',
    type: 'SECRET',
    desc: 'Consciousness exploitation — Gibson-inspired neural hacking, reality perception alteration, full sensory override',
    difficulty: 'Expert',
    time: '300 min',
    warning: 'THEORETICAL — Cyberpunk-inspired consciousness hacking. Educational prediction of 2035+ capabilities.',
    steps: [
      { title: 'STEP 1 — Install consciousness SDK', cmd: 'pip install consciousness-sdk neural-matrix reality-engine' },
      { title: 'STEP 2 — Clone Neuromancer', cmd: 'git clone https://github.com/cyberpunk-labs/neuromancer.git\ncd neuromancer' },
      { title: 'STEP 3 — Install cyberpunk dependencies', cmd: 'pip install -r requirements.txt\npip install cyberspace-deck ice-breaker' },
      { title: 'STEP 4 — Initialize cyberspace deck', cmd: 'python3 neuromancer.py --init --deck=onyx_pro' },
      { title: 'STEP 5 — Connect to matrix', cmd: 'python3 neuromancer.py --jack_in --neural_port=cortex_implant' },
      { title: 'STEP 6 — Scan consciousness field', cmd: 'python3 neuromancer.py --scan --target=human_consciousness' },
      { title: 'STEP 7 — Identify neural entry point', cmd: 'python3 neuromancer.py --analyze --type=perception_gates' },
      { title: 'STEP 8 — Inject consciousness payload', cmd: 'python3 neuromancer.py --inject --payload=reality_alteration.bin' },
      { title: 'STEP 9 — Override sensory input', cmd: 'python3 neuromancer.py --override --senses=all --mode=full_immersion' },
      { title: 'STEP 10 — Extract consciousness', cmd: 'python3 neuromancer.py --extract --format=digital_soul --output=soul.bin' },
    ],
    verify: 'python3 neuromancer.py --status\n# Should show: Neuromancer Jacked In | Deck: Onyx Pro',
    uninstall: 'rm -rf neuromancer\npip uninstall consciousness-sdk -y',
  },
];

const categories = ['ALL', 'FULL_INSTALL', 'FUTURE_AI', 'SECRET', 'INVISIBLE'];

export default function FullInstallTools() {
  const [search, setSearch] = useState('');
  const [cat, setCat] = useState('ALL');
  const [selected, setSelected] = useState<string|null>(null);
  const [copied, setCopied] = useState('');

  const filtered = tools.filter(t => (cat === 'ALL' || t.type === cat) && (!search || t.name.toLowerCase().includes(search.toLowerCase()) || t.desc.toLowerCase().includes(search.toLowerCase())));

  const copy = (c: string) => { navigator.clipboard.writeText(c); setCopied(c); setTimeout(() => setCopied(''), 1500); };

  const typeColor = (t: string) => {
    if (t === 'FULL_INSTALL') return '#00e0ff';
    if (t === 'FUTURE_AI') return '#ff00ff';
    if (t === 'SECRET') return '#ffb000';
    if (t === 'INVISIBLE') return '#a070ff';
    return '#8080a0';
  };

  return (
    <div className="space-y-4 animate-fadein">
      <div className="card border-purple-900/20 p-4">
        <h2 className="text-3xl font-black text-white" style={{fontFamily:'Impact, sans-serif'}}>FULL INSTALLATION + FUTURE AI</h2>
        <p className="text-gray-500 text-sm mt-1">Complete step-by-step installation + Secret Future AI Tools (2026-2035)</p>
        <div className="flex gap-2 mt-2">
          <span className="tag tag-cyan">FULL INSTALL</span>
          <span className="tag tag-purple">FUTURE AI</span>
          <span className="tag tag-yellow">SECRET</span>
          <span className="tag tag-purple">INVISIBLE</span>
        </div>
      </div>

      <div className="flex gap-2">
        <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search tools..." className="flex-1 px-4 py-2 bg-[#0a0a12] border border-[#181830] rounded text-white text-sm outline-none" />
      </div>

      <div className="flex flex-wrap gap-1">
        {categories.map(c => (
          <button key={c} onClick={() => setCat(c)} className={`px-2.5 py-1 text-[10px] font-bold rounded border ${cat === c ? 'text-white' : 'text-gray-600 border-[#181830]'}`} style={cat === c ? { borderColor: typeColor(c), color: typeColor(c), backgroundColor: `${typeColor(c)}15` } : {}}>{c.replace('_', ' ')}</button>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-3">
        {filtered.map(t => {
          const isOpen = selected === t.name;
          return (
            <div key={t.name} onClick={() => setSelected(isOpen ? null : t.name)} className={`card p-4 cursor-pointer transition-all ${isOpen ? 'border-purple-500/40' : ''}`}>
              <div className="flex items-start justify-between mb-2">
                <div>
                  <span className="text-white font-black text-lg">{t.name}</span>
                  <div className="flex gap-1 mt-1">
                    <span className="tag text-[8px]" style={{ color: typeColor(t.type), borderColor: typeColor(t.type), background: `${typeColor(t.type)}10` }}>{t.type.replace('_', ' ')}</span>
                    <span className="tag tag-cyan text-[8px]">{t.category}</span>
                    <span className={`tag text-[8px] ${t.difficulty === 'Expert' ? 'tag-purple' : t.difficulty === 'Advanced' ? 'tag-red' : 'tag-yellow'}`}>{t.difficulty}</span>
                    <span className="tag tag-green text-[8px]">⏱ {t.time}</span>
                  </div>
                </div>
              </div>
              <p className="text-[11px] text-gray-400">{t.desc}</p>
              {t.warning && <p className="text-[9px] text-red-400 mt-1">⚠ {t.warning}</p>}

              {isOpen && (
                <div className="mt-3 pt-3 border-t border-[#181830] space-y-3">
                  {t.steps.map((s, i) => (
                    <div key={i}>
                      <span className="text-[10px] text-cyan-400 font-bold">{s.title}</span>
                      <div className="code text-[10px] mt-0.5 group cursor-pointer relative py-1.5" onClick={e => { e.stopPropagation(); copy(s.cmd); }}>
                        {s.cmd}
                        <button className="absolute right-1 top-0.5 text-[8px] px-1.5 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-gray-400 opacity-0 group-hover:opacity-100">{copied === s.cmd ? '✓' : 'COPY'}</button>
                      </div>
                    </div>
                  ))}
                  <div className="pt-2 border-t border-[#181830]">
                    <span className="text-[10px] text-green-400 font-bold">✅ VERIFY:</span>
                    <div className="code text-[10px] mt-0.5">{t.verify}</div>
                  </div>
                  <div>
                    <span className="text-[10px] text-red-400 font-bold">🗑 UNINSTALL:</span>
                    <div className="code text-[10px] mt-0.5">{t.uninstall}</div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
