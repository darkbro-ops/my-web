import { useState, useRef, useEffect, KeyboardEvent } from 'react';
import type { AccessLevel } from '../data/types';

interface Props {
  id: number;
  accessLevel: AccessLevel;
  onCommand: (msg: string) => void;
}

export default function Terminal({ id, accessLevel, onCommand }: Props) {
  const [lines, setLines] = useState<string[]>([
    `╔══════════════════════════════════════════════╗`,
    `║     DOULATREX TERMINAL v4.2 — TERM ${id}        ║`,
    `║     Access: ${accessLevel.toUpperCase()}                         ║`,
    `╚══════════════════════════════════════════════╝`,
    ``,
    `root@doulatrex:~# _`
  ]);
  const [input, setInput] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const [historyIdx, setHistoryIdx] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [lines]);

  const processCommand = (cmd: string) => {
    const c = cmd.trim().toLowerCase();
    let output: string[] = [];

    if (c === '') {
      output = [''];
    } else if (c === 'help') {
      output = [
        '╔══════════════════════════════════════════════╗',
        '║          DOULATREX COMMAND REFERENCE          ║',
        '╠══════════════════════════════════════════════╣',
        '║  help      — Show this help                  ║',
        '║  clear     — Clear terminal                  ║',
        '║  whoami    — Display current user            ║',
        '║  date      — Show system date/time           ║',
        '║  ls        — List virtual directory          ║',
        '║  scan      — Run simulated network scan      ║',
        '║  status    — Show system status              ║',
        '║  neofetch  — Display system info             ║',
        '║  matrix    — Toggle matrix background        ║',
        '║  hack      — [RESTRICTED]                    ║',
        '║  exit      — Close terminal                  ║',
        '╚══════════════════════════════════════════════╝',
      ];
    } else if (c === 'clear') {
      setLines([]);
      return [];
    } else if (c === 'whoami') {
      output = [`root@doulatrex (access: ${accessLevel})`];
    } else if (c === 'date') {
      output = [new Date().toString()];
    } else if (c === 'ls') {
      output = [
        'drwxr-xr-x  root  doulatrex/',
        'drwxr-xr-x  root  tools/',
        'drwxr-xr-x  root  exploits/',
        'drwxr-xr-x  root  payloads/',
        'drwxr-xr-x  root  intelligence/',
        'drwx------  root  classified/',
        '-rw-r--r--  root  readme.md',
        '-rwxr-xr-x  root  doulat.sh',
      ];
    } else if (c.startsWith('scan')) {
      output = [
        '[*] Initiating network scan...',
        '[*] Target: ' + (c.split(' ')[1] || '192.168.1.0/24'),
        '[+] Host 192.168.1.1 — Router/ Gateway',
        '[+] Host 192.168.1.10 — 22/ssh, 80/http, 443/https',
        '[+] Host 192.168.1.15 — 445/smb, 3389/rdp',
        '[+] Host 192.168.1.20 — 8080/http, 8443/https',
        '[*] Scan complete. 4 hosts found.',
      ];
    } else if (c === 'status') {
      output = [
        '╔══════════════════════════════════════╗',
        '║       DOULATREX SYSTEM STATUS        ║',
        '╠══════════════════════════════════════╣',
        `║  Access Level: ${accessLevel.toUpperCase().padEnd(20)}║`,
        `║  Terminals:   ${id.toString().padEnd(20)}║`,
        `║  Matrix:      ACTIVE${' '.repeat(15)}║`,
        `║  Encryption:  AES-256-GCM${' '.repeat(11)}║`,
        `║  Proxy Chain: TOR → VPN → SOCKS5${' '.repeat(5)}║`,
        '╚══════════════════════════════════════╝',
      ];
    } else if (c === 'neofetch') {
      output = [
        '       ⣴⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣤       ',
        '       ⣿  DOULATREX Cyber Command v4.2    ⣿       ',
        '       ⣿  ─────────────────────────────    ⣿       ',
        `       ⣿  OS: DOULATREX OS (classified)     ⣿       `,
        `       ⣿  Host: DarkBro-${id.toString().padStart(4, '0')}                  ⣿       `,
        `       ⣿  Kernel: DARK-6.9.0-omega          ⣿       `,
        `       ⣿  Shell: DSH 3.0                     ⣿       `,
        `       ⣿  Uptime: ${Math.floor(Math.random() * 999)} days                 ⣿       `,
        `       ⣿  Access: ${accessLevel.toUpperCase()}                      ⣿       `,
        '       ⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤⣤       ',
      ];
    } else if (c === 'hack') {
      if (accessLevel === 'omega') {
        output = [
          '[!] OMEGA PROTOCOL INITIATED',
          '[>>>] Bypassing firewalls... DONE',
          '[>>>] Injecting payload... DONE',
          '[>>>] Escalating privileges... DONE',
          '[>>>] Exfiltrating data... DONE',
          '[✔] Target compromised. Ghost protocol active.',
        ];
        onCommand('OMEGA HACK EXECUTED');
      } else {
        output = ['[✘] ACCESS DENIED — OMEGA clearance required'];
      }
    } else if (c === 'doulat') {
      output = [
        '╔══════════════════════════════════════════════╗',
        '║                                              ║',
        '║     Mr. Doulat Kumar (DarkBro)              ║',
        '║     Founder & Creator of DOULATREX           ║',
        '║     Global Cyber Command Center              ║',
        '║                                              ║',
        '╚══════════════════════════════════════════════╝',
      ];
    } else if (c === 'exit') {
      output = ['[*] Session terminated. Goodbye, operator.'];
    } else {
      output = [`bash: ${cmd.trim()}: command not found. Type 'help' for commands.`];
    }

    return output;
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const cmd = input;
      const newLines = [...lines.slice(0, -1), `root@doulatrex:~# ${cmd}`];
      const output = processCommand(cmd);
      newLines.push(...output);
      newLines.push('root@doulatrex:~# _');
      setLines(newLines);
      setHistory([...history, cmd]);
      setHistoryIdx(-1);
      setInput('');
      onCommand(`Term ${id}: ${cmd}`);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (history.length > 0) {
        const newIdx = historyIdx === -1 ? history.length - 1 : Math.max(0, historyIdx - 1);
        setHistoryIdx(newIdx);
        setInput(history[newIdx]);
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (historyIdx !== -1) {
        const newIdx = historyIdx + 1;
        if (newIdx >= history.length) {
          setHistoryIdx(-1);
          setInput('');
        } else {
          setHistoryIdx(newIdx);
          setInput(history[newIdx]);
        }
      }
    }
  };

  const handleContainerClick = () => {
    inputRef.current?.focus();
  };

  return (
    <div
      className="flex flex-col bg-black border border-green-900/30 rounded overflow-hidden h-full"
      onClick={handleContainerClick}
    >
      <div className="flex items-center justify-between bg-green-950/20 px-3 py-1 border-b border-green-900/20 text-[10px]">
        <span className="text-green-500 font-bold">TERMINAL {id}</span>
        <span className="text-green-700">{accessLevel.toUpperCase()}</span>
      </div>
      <div
        ref={containerRef}
        className="flex-1 overflow-y-auto p-3 font-mono text-[11px] leading-relaxed cursor-text"
        style={{ whiteSpace: 'pre-wrap' }}
      >
        {lines.map((line, i) => (
          <div
            key={i}
            className={
              line.includes('ACCESS DENIED') ? 'text-red-400' :
              line.includes('[✔]') || line.includes('DONE') ? 'text-green-300' :
              line.includes('[!]') ? 'text-yellow-400' :
              line.includes('╔') || line.includes('╚') || line.includes('╠') || line.includes('║') ? 'text-green-500' :
              line.includes('root@doulatrex') ? 'text-green-400' :
              'text-green-600'
            }
          >
            {line}
          </div>
        ))}
      </div>
      <div className="flex items-center bg-green-950/10 border-t border-green-900/20">
        <span className="text-green-500 pl-3 text-[10px]">▶</span>
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          className="flex-1 bg-transparent text-green-400 outline-none px-2 py-1.5 text-[11px] font-mono"
          spellCheck={false}
          autoFocus
        />
      </div>
    </div>
  );
}
