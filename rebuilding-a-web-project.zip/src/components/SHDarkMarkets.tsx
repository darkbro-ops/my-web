import { useState } from 'react';
import { darkMarkets, realOnionSites } from '../data/shadowsect';

export default function SHDarkMarkets() {
  const [tab, setTab] = useState<'markets'|'onion'>('markets');

  return (
    <div className="h-full bg-[#0a0a0f] flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 bg-[#0d0d17] border-b border-[#1e1e30]">
        <div className="flex items-center gap-2"><span className="text-xl">🎭</span><h2 className="text-white font-black text-sm">DARK WEB INTELLIGENCE</h2><span className="tag tag-purple">EDUCATIONAL</span></div>
        <div className="flex gap-2">
          <button onClick={()=>setTab('markets')} className={`px-3 py-1 text-[9px] font-bold rounded border ${tab==='markets'?'bg-[#b388ff]/10 text-[#b388ff] border-[#b388ff]/30':'text-[#5a5a72] border-[#1e1e30]'}`}>🏴 MARKETS</button>
          <button onClick={()=>setTab('onion')} className={`px-3 py-1 text-[9px] font-bold rounded border ${tab==='onion'?'bg-[#00d4ff]/10 text-[#00d4ff] border-[#00d4ff]/30':'text-[#5a5a72] border-[#1e1e30]'}`}>🧅 ONION SITES</button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <div className="mb-3 p-3 border border-[#ff3b5c]/20 rounded bg-[#ff3b5c]/5">
          <p className="text-[9px] text-[#ff3b5c]"><strong>⚠ STRICTLY EDUCATIONAL:</strong> Historical market data for OpSec learning. Real onion sites listed are legal services. Never access illegal content.</p>
        </div>

        {tab==='markets'?(
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            {darkMarkets.map(m=>(
              <div key={m.name} className="card-glow-red p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-white font-bold text-xs">{m.name}</span>
                  <span className={`tag ${m.status.includes('SEIZED')?'tag-red':m.status.includes('EXIT')?'tag-yellow':'tag-purple'}`}>{m.status}</span>
                </div>
                <p className="text-[10px] text-[#8888a0] mb-1"><strong>Founder:</strong> {m.founder}</p>
                <p className="text-[10px] text-[#8888a0] mb-2">{m.desc}</p>
                <div><span className="text-[9px] text-[#ffab00] font-bold">📖 OPSEC LESSONS:</span><div className="space-y-0.5 mt-1">{m.lessons.map((l,i)=><div key={i} className="text-[9px] text-[#ffab00]/70">• {l}</div>)}</div></div>
              </div>
            ))}
          </div>
        ):(
          <div className="space-y-2">
            <h3 className="text-[10px] text-[#00d4ff] font-bold mb-2">🧅 LEGAL & VERIFIED .ONION SITES ({realOnionSites.length})</h3>
            {realOnionSites.map(s=>(
              <div key={s.name} className="card-dark p-3 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="text-lg">{s.category==='News'?'📰':s.category==='Search'?'🔍':s.category==='Government'?'🏛️':s.category==='Whistleblowing'?'📢':'🔗'}</span>
                  <div>
                    <span className="text-white font-bold text-xs">{s.name}</span>
                    <span className="text-[9px] text-[#5a5a72] block">{s.desc}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="tag tag-cyan text-[7px]">{s.category}</span>
                  {s.verified && <span className="tag tag-green text-[7px] ml-1">✓ VERIFIED</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
