import type { AccessLevel } from '../data/types';

interface Props {
  onSearchChange: (term: string) => void;
  accessLevel: AccessLevel;
  onNavigate: (tab: string) => void;
}

const quickActions = [
  { icon: 'fa-bomb', label: '400+ TOOLS', desc: 'Hacking tools collection', tab: 'tools', color: 'text-red-400 border-red-500/20 hover:bg-red-950/10' },
  { icon: 'fa-terminal', label: '500+ COMMANDS', desc: 'Command reference', tab: 'commands', color: 'text-green-400 border-green-500/20 hover:bg-green-950/10' },
  { icon: 'fa-flask', label: 'VIRTUAL LAB', desc: 'Practice environment', tab: 'labs', color: 'text-cyan-400 border-cyan-500/20 hover:bg-cyan-950/10' },
  { icon: 'fa-globe-americas', label: 'GLOBAL OS', desc: 'All OS tools', tab: 'os', color: 'text-yellow-400 border-yellow-500/20 hover:bg-yellow-950/10' },
  { icon: 'fa-cloud', label: 'CLOUD DEPLOY', desc: 'Cloud platforms', tab: 'cloud', color: 'text-purple-400 border-purple-500/20 hover:bg-purple-950/10' },
  { icon: 'fa-skull', label: 'THREAT INTEL', desc: 'Live threat feed', tab: 'threat', color: 'text-red-400 border-red-500/20 hover:bg-red-950/10' },
];

export default function WelcomeContent({ onSearchChange, accessLevel, onNavigate }: Props) {
  return (
    <div className="space-y-4">
      {/* Hero */}
      <div className="bg-black/80 border border-red-500/20 rounded p-6 text-center">
        <div className="text-4xl mb-3">🏴‍☠️</div>
        <h2 className="text-2xl font-black text-white mb-1">DOULA<span className="text-red-500">TREX</span></h2>
        <p className="text-green-600 text-xs mb-1">Global Cyber Command Center</p>
        <p className="text-red-500 text-[10px] font-bold">by DarkBro — Mr. Doulat Kumar</p>
        <div className="mt-3 flex items-center justify-center gap-2">
          <span className={`text-[9px] px-2 py-0.5 rounded border font-bold ${
            accessLevel === 'omega' ? 'bg-purple-950/30 text-purple-400 border-purple-500/30' :
            accessLevel === 'classified' ? 'bg-red-950/30 text-red-400 border-red-500/30' :
            'bg-green-950/30 text-green-400 border-green-500/30'
          }`}>
            {accessLevel.toUpperCase()} ACCESS
          </span>
        </div>
      </div>

      {/* Search */}
      <div>
        <input
          type="text"
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder="🔍 Search 400+ hacking tools, commands & resources..."
          className="w-full px-4 py-2.5 bg-black/80 border border-green-900/30 rounded text-green-400 text-xs outline-none font-mono placeholder-green-800 focus:border-green-500/50"
        />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-2 text-center">
        {[
          { value: '400+', label: 'Tools' },
          { value: '500+', label: 'Commands' },
          { value: '50+', label: 'OS Systems' },
          { value: 'GLOBAL', label: 'Coverage' },
        ].map((stat, i) => (
          <div key={i} className="p-3 bg-black/80 border border-green-900/20 rounded">
            <div className="text-green-400 text-lg font-black">{stat.value}</div>
            <div className="text-green-700 text-[9px]">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div>
        <h3 className="text-[10px] text-green-700 font-bold mb-2 tracking-wider">QUICK ACTIONS</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {quickActions.map((action, i) => (
            <button
              key={i}
              onClick={() => onNavigate(action.tab)}
              className={`flex items-center gap-2 p-3 border rounded transition-all ${action.color} text-left`}
            >
              <i className={`fas ${action.icon} text-lg`} />
              <div>
                <div className="text-[10px] font-bold">{action.label}</div>
                <div className="text-[8px] opacity-70">{action.desc}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Keyboard shortcuts */}
      <div className="bg-black/80 border border-green-900/20 rounded p-3">
        <h3 className="text-[9px] text-green-700 font-bold mb-2">⌨ KEYBOARD SHORTCUTS</h3>
        <div className="grid grid-cols-2 gap-1 text-[9px]">
          <div className="text-green-600"><span className="text-yellow-400 font-bold">CTRL+SHIFT+R</span> — Cycle access level</div>
          <div className="text-green-600"><span className="text-yellow-400 font-bold">CTRL+`</span> — Open terminal</div>
          <div className="text-green-600"><span className="text-yellow-400 font-bold">CTRL+SHIFT+T</span> — TOR gateway</div>
          <div className="text-green-600"><span className="text-yellow-400 font-bold">CTRL+SHIFT+X</span> — Secret labs</div>
          <div className="text-green-600 col-span-2"><span className="text-yellow-400 font-bold">Type "matrix"</span> — Toggle matrix rain</div>
        </div>
      </div>
    </div>
  );
}
