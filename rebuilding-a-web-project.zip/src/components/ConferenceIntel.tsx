import { useState } from 'react';

const conferences = [
  { id: 'defcon', name: 'DEF CON 33', location: 'Las Vegas, USA', date: 'Aug 2026', type: 'Hacking', status: 'UPCOMING', icon: 'fa-skull', color: 'text-red-400' },
  { id: 'blackhat', name: 'Black Hat USA', location: 'Las Vegas, USA', date: 'Aug 2026', type: 'Security', status: 'UPCOMING', icon: 'fa-hat-cowboy', color: 'text-yellow-400' },
  { id: 'rsa', name: 'RSA Conference', location: 'San Francisco, USA', date: 'May 2026', type: 'Industry', status: 'PAST', icon: 'fa-shield', color: 'text-green-400' },
  { id: 'ccc', name: 'Chaos Communication Congress', location: 'Hamburg, Germany', date: 'Dec 2026', type: 'Hacking', status: 'UPCOMING', icon: 'fa-fire', color: 'text-orange-400' },
  { id: 'bsides', name: 'BSides Global', location: 'Worldwide', date: 'Ongoing', type: 'Community', status: 'ACTIVE', icon: 'fa-users', color: 'text-cyan-400' },
  { id: 'hacktivity', name: 'Hacktivity', location: 'Budapest, Hungary', date: 'Oct 2026', type: 'Conference', status: 'UPCOMING', icon: 'fa-bolt', color: 'text-purple-400' },
  { id: 'insomnihack', name: 'Insomni\'hack', location: 'Geneva, Switzerland', date: 'Mar 2026', type: 'CTF', status: 'PAST', icon: 'fa-moon', color: 'text-blue-400' },
  { id: 'nullcon', name: 'Nullcon', location: 'Goa, India', date: 'Feb 2026', type: 'Security', status: 'PAST', icon: 'fa-globe-asia', color: 'text-orange-400' },
];

const trainers = [
  { name: 'DarkBro (Doulat Kumar)', expertise: 'Advanced Exploitation, Malware Dev, OSINT', rating: '★★★★★', country: '🇮🇳 India' },
  { name: 'The Grugq', expertise: 'OpSec, Counter Intelligence', rating: '★★★★★', country: '🇹🇭 Thailand' },
  { name: 'LiveOverflow', expertise: 'Binary Exploitation, CTF', rating: '★★★★★', country: '🇩🇪 Germany' },
  { name: 'IppSec', expertise: 'HTB Walkthroughs, Pentesting', rating: '★★★★★', country: '🇺🇸 USA' },
];

export default function ConferenceIntel() {
  const [tab, setTab] = useState<'events' | 'training'>('events');

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <button
          onClick={() => setTab('events')}
          className={`px-4 py-1.5 text-[10px] font-bold rounded border transition-all ${
            tab === 'events' ? 'bg-green-950/20 text-green-400 border-green-500/30' : 'text-green-700 border-green-900/20'
          }`}
        >
          📅 EVENTS
        </button>
        <button
          onClick={() => setTab('training')}
          className={`px-4 py-1.5 text-[10px] font-bold rounded border transition-all ${
            tab === 'training' ? 'bg-green-950/20 text-green-400 border-green-500/30' : 'text-green-700 border-green-900/20'
          }`}
        >
          🎓 TRAINERS
        </button>
      </div>

      {tab === 'events' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {conferences.map(conf => (
            <div key={conf.id} className="bg-black/80 border border-green-900/20 rounded p-4 hover:border-green-700/30 transition-all">
              <div className="flex items-center gap-2 mb-2">
                <i className={`fas ${conf.icon} text-lg ${conf.color}`} />
                <h3 className="text-green-400 font-bold text-xs">{conf.name}</h3>
              </div>
              <div className="space-y-1 text-[9px]">
                <p className="text-green-600">📍 {conf.location}</p>
                <p className="text-green-600">📅 {conf.date}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-green-700">{conf.type}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[7px] font-bold ${
                    conf.status === 'UPCOMING' ? 'bg-green-950/20 text-green-400' :
                    conf.status === 'ACTIVE' ? 'bg-cyan-950/20 text-cyan-400 animate-pulse' :
                    'bg-red-950/10 text-red-600'
                  }`}>
                    {conf.status}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {trainers.map((t, i) => (
            <div key={i} className="bg-black/80 border border-green-900/20 rounded p-4 hover:border-green-700/30 transition-all">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-green-400 font-bold text-xs">{t.name}</h3>
                <span className="text-sm">{t.country}</span>
              </div>
              <p className="text-green-600 text-[9px] mb-1">{t.expertise}</p>
              <p className="text-yellow-400 text-[9px]">{t.rating}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
