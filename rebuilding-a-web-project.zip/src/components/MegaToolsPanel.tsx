import { useState, useMemo } from 'react';
import { allMegaTools, toolCategories } from '../data/megatools';
import type { MegaTool } from '../data/megatools';

interface Props {
  categoryFilter?: string;
}

export default function MegaToolsPanel({ categoryFilter }: Props) {
  const [search, setSearch] = useState('');
  const [activeCat, setActiveCat] = useState(categoryFilter ? categoryFilter.split(',')[0] : 'ALL');
  const [selectedTool, setSelectedTool] = useState<MegaTool | null>(null);
  const [copied, setCopied] = useState('');

  const cats = categoryFilter
    ? categoryFilter.split(',').map(c => ({ id: c, icon: 'fa-tools', color: 'cyan', count: 0 }))
    : toolCategories;

  const filtered = useMemo(() => {
    let tools = allMegaTools;

    if (categoryFilter) {
      const cats = categoryFilter.split(',');
      tools = allMegaTools.filter(t => cats.some(c => t.category === c || t.category.startsWith(c)));
    } else if (activeCat !== 'ALL') {
      tools = allMegaTools.filter(t => t.category === activeCat || t.category.startsWith(activeCat));
    }

    if (search) {
      const s = search.toLowerCase();
      tools = tools.filter(t =>
        t.name.toLowerCase().includes(s) ||
        t.description.toLowerCase().includes(s) ||
        t.subcategory.toLowerCase().includes(s) ||
        t.commands.some(c => c.toLowerCase().includes(s))
      );
    }

    return tools;
  }, [activeCat, search, categoryFilter]);

  const copyCmd = (cmd: string) => { navigator.clipboard.writeText(cmd); setCopied(cmd); setTimeout(() => setCopied(''), 1500); };

  const diffColor = (d: string) => d === 'Expert' ? 'diff-expert' : d === 'Hard' ? 'diff-hard' : d === 'Medium' ? 'diff-medium' : 'diff-easy';
  const catColor = (cat: string) => {
    if (cat.includes('OSINT')) return '#00d4ff';
    if (cat.includes('Social')) return '#b388ff';
    if (cat.includes('Agency/NSA') || cat.includes('Agency/CIA')) return '#ff3b5c';
    if (cat.includes('Agency/Mossad')) return '#448aff';
    if (cat.includes('Agency/GRU')) return '#ff3b5c';
    if (cat.includes('Agency/MSS')) return '#ffab00';
    if (cat.includes('Agency/GCHQ')) return '#448aff';
    if (cat.includes('Agency/BND')) return '#ffab00';
    if (cat.includes('Exploitation')) return '#ff3b5c';
    if (cat.includes('Vulnerability')) return '#ff3b5c';
    if (cat.includes('Password')) return '#ffab00';
    if (cat.includes('Wireless')) return '#00e676';
    if (cat.includes('WebApplication')) return '#448aff';
    return '#00d4ff';
  };

  return (
    <div className="space-y-3 animate-[fadeIn_0.3s_ease-out]">
      {/* Header */}
      <div className="card-glow-red p-4">
        <h2 className="text-white font-black text-sm">
          💣 {categoryFilter ? categoryFilter.replace(',', ' + ') : 'MEGA TOOLS DATABASE'}
          <span className="text-[#5a5a72] text-xs ml-2 font-normal">{filtered.length} tools</span>
        </h2>
        <p className="text-[#8888a0] text-[10px] mt-1">
          Every tool has real commands, install instructions, and usage examples. Click any tool to expand.
        </p>
      </div>

      {/* Search */}
      <div className="flex gap-2">
        <div className="relative flex-1">
          <i className="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-[#5a5a72] text-xs"/>
          <input type="text" value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search 200+ tools by name, description, command..."
            className="w-full pl-9 pr-4 py-2 bg-[#111118] border border-[#1e1e30] rounded-lg text-[#e0e0f0] text-xs outline-none focus:border-[#00d4ff]/50 placeholder-[#5a5a72] transition-colors"
          />
        </div>
      </div>

      {/* Categories */}
      {!categoryFilter && (
        <div className="flex flex-wrap gap-1.5">
          <button onClick={() => setActiveCat('ALL')}
            className={`px-2.5 py-1 text-[9px] font-bold rounded-full border transition-all ${activeCat==='ALL'?'bg-[#00d4ff]/10 border-[#00d4ff]/40 text-[#00d4ff]':'border-[#1e1e30] text-[#5a5a72] hover:text-[#8888a0]'}`}>
            🌐 ALL ({allMegaTools.length})
          </button>
          {cats.map(cat => (
            <button key={cat.id} onClick={() => setActiveCat(cat.id)}
              className={`px-2.5 py-1 text-[9px] font-bold rounded-full border transition-all ${
                activeCat===cat.id ? 'border-[#00d4ff]/40 text-white bg-[#00d4ff]/10' : 'border-[#1e1e30] text-[#5a5a72] hover:text-[#8888a0]'
              }`}
              style={activeCat===cat.id ? {borderColor: catColor(cat.id)+'66', color: catColor(cat.id)} : {}}
            >
              <i className={`fas ${cat.icon} text-[8px] mr-1`}/>
              {cat.id.includes('/') ? cat.id.split('/')[1] : cat.id}
              <span className="ml-1 text-[8px] text-[#5a5a72]">{cat.count}</span>
            </button>
          ))}
        </div>
      )}

      {/* Tools Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {filtered.map(tool => (
          <div key={tool.id}
            onClick={() => setSelectedTool(selectedTool?.id === tool.id ? null : tool)}
            className={`card-dark p-3 cursor-pointer transition-all ${
              selectedTool?.id === tool.id ? 'ring-1' : 'hover:border-[#2a2a40]'
            }`}
            style={selectedTool?.id === tool.id ? { borderColor: catColor(tool.category) } : {}}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-1.5">
              <div className="flex items-center gap-2 min-w-0">
                <span className="text-lg">
                  {tool.category.includes('OSINT') ? '🔍' :
                   tool.category.includes('Social') ? '👥' :
                   tool.category.includes('Agency') ? '🦅' :
                   tool.category.includes('Exploitation') ? '💣' :
                   tool.category.includes('Vulnerability') ? '🛡' :
                   tool.category.includes('Password') ? '🔑' :
                   tool.category.includes('Wireless') ? '📡' :
                   tool.category.includes('WebApplication') ? '🌐' : '🛠'}
                </span>
                <div className="min-w-0">
                  <span className="text-white font-bold text-xs block truncate">{tool.name}</span>
                  <span className="text-[8px] text-[#5a5a72]">{tool.subcategory}</span>
                </div>
              </div>
              <span className={`tag ml-1 flex-shrink-0 ${diffColor(tool.difficulty)}`}>
                {tool.difficulty}
              </span>
            </div>
            <p className="text-[10px] text-[#8888a0] line-clamp-2 mb-1.5">{tool.description}</p>

            {/* Expanded content */}
            {selectedTool?.id === tool.id && (
              <div className="mt-2 pt-2 border-t border-[#1e1e30] space-y-2">
                {/* Install */}
                <div>
                  <span className="text-[8px] text-[#5a5a72] uppercase tracking-wider font-bold">📥 INSTALL</span>
                  <div className="code-block mt-1 text-[10px] group cursor-pointer relative" onClick={e => { e.stopPropagation(); copyCmd(tool.install); }}>
                    $ {tool.install}
                    <button className="absolute right-2 top-1/2 -translate-y-1/2 text-[8px] px-2 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-[#8888a0] hover:text-[#00d4ff]">
                      {copied === tool.install ? '✓' : 'COPY'}
                    </button>
                  </div>
                </div>

                {/* Commands */}
                <div>
                  <span className="text-[8px] text-[#5a5a72] uppercase tracking-wider font-bold">⚡ COMMANDS</span>
                  <div className="space-y-1 mt-1">
                    {tool.commands.map((cmd, i) => (
                      <div key={i} className="code-block text-[10px] group cursor-pointer relative py-1.5" onClick={e => { e.stopPropagation(); copyCmd(cmd); }}>
                        <span className="text-[#00d4ff]">$</span> <span className="text-[#e0e0f0]">{cmd}</span>
                        <button className="absolute right-2 top-1/2 -translate-y-1/2 text-[8px] px-2 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-[#8888a0] hover:text-[#00d4ff] opacity-0 group-hover:opacity-100">
                          {copied === cmd ? '✓' : 'COPY'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* URL */}
                {tool.url && (
                  <div className="text-[9px]">
                    <span className="text-[#5a5a72]">🔗 </span>
                    <a href={tool.url} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}
                      className="text-[#448aff] hover:underline">{tool.url}</a>
                  </div>
                )}

                {/* Country */}
                {tool.country && <div className="text-[9px]"><span className="text-[#5a5a72]">📍 {tool.country}</span></div>}
              </div>
            )}
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-8 text-[#5a5a72]">No tools found matching your search.</div>
      )}
    </div>
  );
}
