import { useState } from 'react';
import { futureTools } from '../data/ultimatedata';

export default function FutureVault() {
  const [unlocked, setUnlocked] = useState(false);
  const [key, setKey] = useState('');
  const [selected, setSelected] = useState<string|null>(null);
  const [error, setError] = useState(false);

  const handleUnlock = () => {
    if (key.toLowerCase() === 'doulat-2099' || key.toLowerCase() === 'omega') {
      setUnlocked(true); setError(false);
    } else {
      setError(true); setTimeout(()=>setError(false),2000);
    }
  };

  return (
    <div className="h-full bg-[#0a0a0f] flex flex-col">
      <div className="flex items-center justify-between px-4 py-3 bg-[#0d0d17] border-b border-[#1e1e30]">
        <div className="flex items-center gap-2">
          <span className="text-lg">🔮</span>
          <h2 className="text-white font-black text-sm">FUTURE TOOLS VAULT — TOMORROW'S CYBER ARSENAL</h2>
          <span className="tag tag-purple">PREDICTED</span>
        </div>
        <span className="text-[#5a5a72] text-[9px]">{futureTools.length} PREDICTED TOOLS</span>
      </div>

      {!unlocked ? (
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center space-y-4">
            <div className="text-7xl">🔐</div>
            <h3 className="text-white font-black text-lg">FUTURE VAULT LOCKED</h3>
            <p className="text-[#8888a0] text-xs max-w-md">This vault contains predicted future cyber tools — quantum exploits, neural attack frameworks, bio-cyber weapons, and more. These are <strong className="text-[#b388ff]">educational predictions</strong>, not real tools.</p>
            <div className="flex gap-2 justify-center">
              <input type="text" value={key} onChange={e=>setKey(e.target.value)}
                onKeyDown={e=>e.key==='Enter'&&handleUnlock()}
                placeholder="Enter vault key..."
                className="px-4 py-2 bg-[#111118] border border-[#1e1e30] rounded-lg text-[#e0e0f0] text-xs outline-none focus:border-[#b388ff]/50 w-56"/>
              <button onClick={handleUnlock} className="btn-purple px-6 rounded-lg">UNLOCK</button>
            </div>
            {error && <p className="text-[#ff3b5c] text-xs animate-pulse">INVALID KEY</p>}
            <p className="text-[#5a5a72] text-[9px]">Hint: doulat-2099</p>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {futureTools.map(ft => (
              <div key={ft.id} onClick={()=>setSelected(selected===ft.id?null:ft.id)}
                className={`card-glow-purple p-4 cursor-pointer transition-all ${selected===ft.id?'border-[#b388ff]/50':'hover:border-[#2a2a40]'}`}>
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{ft.category==='Quantum Exploitation'?'⚛️':ft.category==='AI-Powered Attack'?'🤖':ft.category==='Space Warfare'?'🚀':'🔮'}</span>
                    <div>
                      <h3 className="text-white font-bold text-xs">{ft.name}</h3>
                      <span className="tag tag-yellow text-[7px]">{ft.year}</span>
                    </div>
                  </div>
                  <span className="text-[8px] text-[#b388ff] bg-[#b388ff]/10 px-1.5 py-0.5 rounded">{ft.status}</span>
                </div>
                <p className="text-[10px] text-[#8888a0] mb-2">{ft.desc}</p>
                {selected===ft.id && (
                  <div className="mt-2 pt-2 border-t border-[#1e1e30]">
                    <span className="text-[9px] text-[#5a5a72] font-bold">PREDICTED CAPABILITIES:</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {ft.capabilities.map((c,i)=><span key={i} className="tag tag-purple text-[7px]">{c}</span>)}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
