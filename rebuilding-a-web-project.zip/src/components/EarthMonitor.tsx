import { useState, useEffect } from 'react';

export default function EarthMonitor() {
  const [time, setTime] = useState(new Date());
  const [satellites, setSatellites] = useState(0);
  const [alerts, setAlerts] = useState<string[]>([]);

  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    const s = setInterval(() => setSatellites(Math.floor(Math.random() * 300 + 4700)), 5000);
    return () => { clearInterval(t); clearInterval(s); };
  }, []);

  useEffect(() => {
    const types = ['SEISMIC', 'WEATHER', 'CYBER', 'MILITARY', 'SATELLITE', 'ENERGY'];
    const interval = setInterval(() => {
      const type = types[Math.floor(Math.random() * types.length)];
      setAlerts(prev => {
        const next = [...prev, `[${time.toLocaleTimeString()}] ${type}: Activity detected in sector ${Math.floor(Math.random() * 36)}`];
        return next.slice(-8);
      });
    }, 4000);
    return () => clearInterval(interval);
  }, [time]);

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-green-400 font-bold text-sm tracking-wider">🌍 EARTH MONITOR — GLOBAL SURVEILLANCE</h2>
        <span className="text-[9px] text-green-600 animate-pulse">● LIVE</span>
      </div>

      {/* Earth Display */}
      <div className="flex-1 flex items-center justify-center relative">
        <div
          className="w-64 h-64 rounded-full relative"
          style={{
            background: 'radial-gradient(circle at 30% 30%, #0a2a0a 0%, #020 40%, #010 70%, #000 100%)',
            boxShadow: '0 0 60px rgba(0,255,0,0.15), inset 0 0 60px rgba(0,50,0,0.3)',
            border: '2px solid rgba(0,255,0,0.2)'
          }}
        >
          {/* Grid lines */}
          <div className="absolute inset-0 rounded-full" style={{ background: 'repeating-linear-gradient(0deg, transparent, transparent 9px, rgba(0,255,0,0.05) 9px, rgba(0,255,0,0.05) 10px), repeating-linear-gradient(90deg, transparent, transparent 9px, rgba(0,255,0,0.05) 9px, rgba(0,255,0,0.05) 10px)' }} />
          {/* Equator */}
          <div className="absolute top-1/2 left-0 right-0 h-px bg-green-500/30" />
          {/* Prime meridian */}
          <div className="absolute top-0 bottom-0 left-1/2 w-px bg-green-500/30" />
          {/* Pulsing dots */}
          <div className="absolute top-[30%] left-[25%] w-2 h-2 bg-green-400 rounded-full animate-pulse" style={{ boxShadow: '0 0 10px #0f0' }} />
          <div className="absolute top-[45%] left-[55%] w-2 h-2 bg-red-400 rounded-full animate-pulse" style={{ boxShadow: '0 0 10px #f00' }} />
          <div className="absolute top-[55%] left-[40%] w-2 h-2 bg-yellow-400 rounded-full animate-pulse" style={{ boxShadow: '0 0 10px #ff0' }} />
          <div className="absolute top-[25%] left-[70%] w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
          <div className="absolute top-[60%] left-[75%] w-1.5 h-1.5 bg-red-400 rounded-full animate-pulse" />
          <div className="absolute top-[35%] left-[45%] w-1 h-1 bg-yellow-400 rounded-full animate-pulse" />
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-2 text-center text-[9px] mt-3">
        <div className="p-2 border border-green-900/20 rounded">
          <div className="text-green-500">🛰 SATELLITES</div>
          <div className="text-green-400 font-bold">{satellites.toLocaleString()}</div>
        </div>
        <div className="p-2 border border-green-900/20 rounded">
          <div className="text-green-500">⏰ UTC</div>
          <div className="text-green-400 font-bold">{time.toUTCString().split(' ')[4]}</div>
        </div>
        <div className="p-2 border border-green-900/20 rounded">
          <div className="text-green-500">📡 SIGNALS</div>
          <div className="text-green-400 font-bold">{Math.floor(Math.random() * 9000 + 1000)}</div>
        </div>
        <div className="p-2 border border-green-900/20 rounded">
          <div className="text-green-500">⚠ ALERTS</div>
          <div className="text-yellow-400 font-bold">{alerts.length}</div>
        </div>
      </div>

      {/* Alert feed */}
      <div className="mt-2 p-2 border border-green-900/20 rounded max-h-32 overflow-y-auto bg-[#020408]">
        {alerts.map((alert, i) => (
          <div key={i} className="text-[8px] font-mono text-green-600">{alert}</div>
        ))}
      </div>
    </div>
  );
}
