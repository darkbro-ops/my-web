import { useState } from 'react';
import type { AccessLevel } from '../data/types';
import { darkWebSites } from '../data/categories';

interface Props {
  accessLevel: AccessLevel;
}

export default function DarkWebSim({ accessLevel: _al }: Props) {
  const [connected, setConnected] = useState(false);
  const [currentSite, setCurrentSite] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [torLog, setTorLog] = useState<string[]>([]);

  const connectTor = () => {
    setLoading(true);
    setTorLog([]);
    const steps = [
      '[BOOT] Initializing TOR circuit...',
      '[NODE] Connecting to guard node (DE)...',
      '[NODE] Establishing middle relay (NL)...',
      '[NODE] Connecting to exit node (SE)...',
      '[DONE] TOR circuit established — 3 hops',
      '[INFO] IP: 185.220.101.xxx (exit)',
      '[INFO] Circuit fingerprint: DOULATREX-7F3A',
      '[READY] Dark web gateway active',
    ];
    steps.forEach((step, i) => {
      setTimeout(() => {
        setTorLog(prev => [...prev, step]);
        if (i === steps.length - 1) {
          setConnected(true);
          setLoading(false);
        }
      }, i * 400);
    });
  };

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-purple-400 font-bold text-sm tracking-wider">🎭 DARK WEB GATEWAY</h2>
        <div className={`px-2 py-0.5 text-[9px] font-bold rounded ${connected ? 'bg-purple-950/30 text-purple-400 border border-purple-500/30' : 'bg-red-950/20 text-red-400 border border-red-500/20'}`}>
          {connected ? '● CONNECTED' : '○ DISCONNECTED'}
        </div>
      </div>

      {!connected ? (
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-6xl mb-4">🧅</div>
          <h3 className="text-purple-400 font-bold mb-2">TOR Gateway</h3>
          <p className="text-green-700 text-xs mb-4 text-center max-w-md">
            Establish a secure TOR connection to access the dark web gateway.
            All traffic will be routed through 3 encrypted hops.
          </p>
          <button
            onClick={connectTor}
            disabled={loading}
            className="px-6 py-2 bg-purple-950/30 border border-purple-500/30 rounded text-purple-400 hover:bg-purple-950/50 transition-all disabled:opacity-50 text-xs font-bold"
          >
            {loading ? 'CONNECTING...' : 'CONNECT TO TOR'}
          </button>
        </div>
      ) : (
        <>
          {/* Tor Log */}
          {torLog.length > 0 && (
            <div className="mb-3 p-2 bg-black border border-purple-900/20 rounded max-h-32 overflow-y-auto">
              {torLog.map((entry, i) => (
                <div key={i} className="text-[9px] font-mono text-green-600">{entry}</div>
              ))}
            </div>
          )}

          {/* Site List */}
          <div className="flex-1 overflow-y-auto space-y-2">
            <h3 className="text-[10px] text-purple-500 font-bold mb-2">KNOWN .ONION SITES</h3>
            {darkWebSites.map((site) => (
              <div
                key={site.id}
                onClick={() => setCurrentSite(site.id === currentSite ? null : site.id)}
                className={`border rounded p-3 cursor-pointer transition-all ${
                  site.id === currentSite
                    ? 'border-purple-500/50 bg-purple-950/10'
                    : 'border-green-900/20 bg-green-950/5 hover:border-purple-700/30'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-purple-400 text-xs font-bold">{site.name}</span>
                    <span className={`ml-2 px-1 py-0.5 text-[7px] rounded ${site.status === 'online' ? 'bg-green-950/30 text-green-400' : 'bg-red-950/30 text-red-400'}`}>
                      {site.status.toUpperCase()}
                    </span>
                  </div>
                  <span className="text-[9px] text-green-700">{site.category}</span>
                </div>
                {site.id === currentSite && (
                  <div className="mt-2 pt-2 border-t border-green-900/20 text-[10px] text-green-600 space-y-1">
                    <p>{site.description}</p>
                    <p className="text-[8px] text-purple-600 font-mono">{site.onion}</p>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-3 p-2 border border-purple-900/20 rounded bg-purple-950/5 text-[9px] text-purple-600 font-mono">
            ⚠ All connections are simulated for educational purposes only.
          </div>
        </>
      )}
    </div>
  );
}
