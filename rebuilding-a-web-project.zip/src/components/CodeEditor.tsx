import { useState } from 'react';

/* ═══════════════════════════════════════════════════════
   SHADOW CODE EDITOR — Write & Execute Code
   Real code editor with syntax highlighting simulation
   ═══════════════════════════════════════════════════════ */

const templates = [
  { name:'BASH — Auto Recon',lang:'bash',code:`#!/bin/bash
# DOULATREX Auto Recon Script
# Educational Purpose Only

TARGET=$1
if [ -z "$TARGET" ]; then
  echo "Usage: $0 <domain>"
  exit 1
fi

echo "[*] Starting recon on $TARGET"
echo "[*] Subdomain enumeration..."
subfinder -d $TARGET -o subs.txt
echo "[*] Port scanning..."
nmap -sV -sC $TARGET -oN scan.txt
echo "[*] Done. Check subs.txt and scan.txt"` },
  { name:'PYTHON — Port Scanner',lang:'python',code:`#!/usr/bin/env python3
# DOULATREX Port Scanner
# Educational Purpose Only

import socket
import sys

def scan_port(target, port):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(1)
        result = sock.connect_ex((target, port))
        if result == 0:
            print(f"[+] Port {port} OPEN")
        sock.close()
    except:
        pass

target = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
print(f"[*] Scanning {target}...")
for port in range(1, 1025):
    scan_port(target, port)` },
  { name:'PYTHON — Hash Cracker',lang:'python',code:`#!/usr/bin/env python3
# DOULATREX MD5 Hash Cracker
# Educational Purpose Only

import hashlib
import sys

def crack(hash_target, wordlist):
    with open(wordlist, 'r', errors='ignore') as f:
        for line in f:
            word = line.strip()
            if hashlib.md5(word.encode()).hexdigest() == hash_target:
                print(f"[+] CRACKED: {word}")
                return
    print("[-] Not found in wordlist")

if __name__ == "__main__":
    crack(sys.argv[1], sys.argv[2])` },
  { name:'BASH — Directory Brute',lang:'bash',code:`#!/bin/bash
# DOULATREX Directory Bruteforcer
# Educational Purpose Only

URL=$1
WORDLIST=$2

if [ -z "$URL" ] || [ -z "$WORDLIST" ]; then
  echo "Usage: $0 <url> <wordlist>"
  exit 1
fi

echo "[*] Brute forcing $URL..."
while read -r dir; do
  CODE=$(curl -s -o /dev/null -w "%{http_code}" "$URL/$dir")
  if [ "$CODE" != "404" ]; then
    echo "[$CODE] /$dir"
  fi
done < "$WORDLIST"` },
  { name:'PYTHON — Keylogger (EDU)',lang:'python',code:`#!/usr/bin/env python3
# DOULATREX Keylogger — EDUCATIONAL ONLY
# Demonstrates how keyloggers work for defense

# This is a SIMULATION for learning
# Real keyloggers require pynput library

print("=== EDUCATIONAL KEYLOGGER DEMO ===")
print("This shows how keyloggers capture input.")
print("Install: pip install pynput")
print("")
print("Code structure:")
print("1. Import pynput.keyboard")
print("2. Define on_press(key) callback")
print("3. Log keys to file")
print("4. Start listener with keyboard.Listener()")
print("")
print("DEFENSE: Use anti-keylogger software,")
print("hardware keyboards, behavioral detection.")` },
  { name:'BASH — Linux Priv Esc',lang:'bash',code:`#!/bin/bash
# DOULATREX Privilege Escalation Checker
# Educational Purpose Only

echo "[*] Linux Privilege Escalation Checks"
echo ""

echo "[*] SUID binaries:"
find / -perm -4000 2>/dev/null

echo ""
echo "[*] Sudo permissions:"
sudo -l 2>/dev/null

echo ""
echo "[*] Cron jobs:"
crontab -l 2>/dev/null
ls -la /etc/cron* 2>/dev/null

echo ""
echo "[*] Kernel version:"
uname -a

echo ""
echo "[*] Writable files:"
find / -writable -type f 2>/dev/null | head -20` },
];

export default function CodeEditor() {
  const [code, setCode] = useState(templates[0].code);
  const [lang, setLang] = useState(templates[0].lang);
  const [output, setOutput] = useState('');
  const [filename, setFilename] = useState('script.sh');

  const runCode = () => {
    setOutput(`[*] Simulating execution of ${filename}...
[*] This is a CODE EDITOR — not a real terminal
[*] Copy the code and run it in your own terminal
[*] 
[*] Code preview (first 5 lines):
${code.split('\n').slice(0,5).join('\n')}
[*]
[*] To run for real:
[*] 1. Save this code to a file: ${filename}
[*] 2. Make executable: chmod +x ${filename}
[*] 3: Run: ./${filename}
[*]
[*] ⚠ EDUCATIONAL USE ONLY ⚠`);
  };

  const loadTemplate = (idx: number) => {
    setCode(templates[idx].code);
    setLang(templates[idx].lang);
    setFilename(templates[idx].name.split(' — ')[0].toLowerCase().replace(' ','_') + (templates[idx].lang==='python'?'.py':'.sh'));
    setOutput('');
  };

  return (
    <div className="h-full bg-[#060608] flex flex-col">
      {/* Header */}
      <div className="bg-[#0a0a12] border-b border-[#181830] px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-xl">💻</span>
          <h2 className="text-xl font-black text-white" style={{fontFamily:'Impact, sans-serif'}}>SHADOW CODE EDITOR</h2>
          <span className="tag tag-cyan text-[7px]">WRITE • EDIT • EXECUTE</span>
        </div>
        <div className="flex items-center gap-2">
          <input type="text" value={filename} onChange={e=>setFilename(e.target.value)}
            className="px-2 py-1 bg-[#0a0a12] border border-[#181830] rounded text-cyan-400 text-xs outline-none w-32"/>
          <button onClick={runCode} className="px-3 py-1 bg-green-950/30 border border-green-500/30 rounded text-green-400 text-xs font-bold hover:bg-green-900/20">
            ▶ RUN
          </button>
        </div>
      </div>

      {/* Templates */}
      <div className="bg-[#080810] border-b border-[#181830] px-4 py-2 flex gap-1 overflow-x-auto">
        <span className="text-gray-500 text-[9px] mr-2 self-center">TEMPLATES:</span>
        {templates.map((t,i)=>(
          <button key={i} onClick={()=>loadTemplate(i)}
            className="px-2 py-1 text-[9px] font-bold rounded border border-[#181830] text-gray-400 hover:text-cyan-400 hover:border-cyan-500/30 whitespace-nowrap">
            {t.name}
          </button>
        ))}
      </div>

      {/* Editor + Output */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Code Editor */}
        <div className="flex-1 flex flex-col border-r border-[#181830]">
          <div className="bg-[#0a0a12] px-3 py-1 border-b border-[#181830] text-[9px] text-gray-500 flex items-center justify-between">
            <span>EDITOR — {lang.toUpperCase()}</span>
            <span>{code.split('\n').length} lines</span>
          </div>
          <textarea
            value={code}
            onChange={e=>setCode(e.target.value)}
            className="flex-1 bg-[#050510] text-cyan-400 text-xs font-mono p-4 outline-none resize-none leading-relaxed"
            spellCheck={false}
            style={{tabSize:2}}
          />
        </div>

        {/* Output */}
        <div className="lg:w-96 flex flex-col">
          <div className="bg-[#0a0a12] px-3 py-1 border-b border-[#181830] text-[9px] text-gray-500">
            OUTPUT / TERMINAL
          </div>
          <div className="flex-1 bg-black p-3 overflow-y-auto">
            <pre className="text-green-400 text-[10px] font-mono whitespace-pre-wrap">{output || 'Click RUN to execute code simulation...\n\nOr copy code and run in your terminal.'}</pre>
          </div>
        </div>
      </div>
    </div>
  );
}
