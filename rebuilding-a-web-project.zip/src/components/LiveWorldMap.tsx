import { useState, useEffect } from 'react';

// Simulated global cyber events that update in real-time
const generateEvent = () => {
  const types = ['CYBER ATTACK', 'BREACH', 'ZERO-DAY', 'DDoS', 'RANSOMWARE', 'APT ALERT', 'DATA LEAK', 'PHISHING', 'MALWARE', 'EXPLOIT'];
  const countries = ['US', 'CN', 'RU', 'IR', 'KP', 'IN', 'IL', 'UK', 'DE', 'FR', 'JP', 'KR', 'BR', 'AU', 'PK', 'TR'];
  const severity = ['LOW', 'MED', 'HIGH', 'CRITICAL'];
  const type = types[Math.floor(Math.random() * types.length)];
  const country = countries[Math.floor(Math.random() * countries.length)];
  const sev = severity[Math.floor(Math.random() * severity.length)];
  const srcIP = `${Math.floor(Math.random()*223)+1}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
  const dstIP = `${Math.floor(Math.random()*223)+1}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}.${Math.floor(Math.random()*255)}`;
  return { type, country, severity: sev, srcIP, dstIP, time: new Date().toLocaleTimeString(), id: Math.random().toString(36).slice(2,8) };
};

export default function LiveWorldMap() {
  const [events, setEvents] = useState<any[]>([]);
  const [nodes, setNodes] = useState<{x:number;y:number;label:string;country:string;color:string;type:string}[]>([]);
  const [scanLines, setScanLines] = useState<number>(0);
  useEffect(() => {
    // Setup world nodes
    const worldNodes = [
      {x:20,y:30,label:'NSA',country:'US',color:'#ff3b5c',type:'Agency'},
      {x:22,y:32,label:'CIA',country:'US',color:'#ff3b5c',type:'Agency'},
      {x:48,y:25,label:'GCHQ',country:'UK',color:'#448aff',type:'Agency'},
      {x:70,y:20,label:'GRU',country:'RU',color:'#ff3b5c',type:'Military'},
      {x:75,y:32,label:'MSS',country:'CN',color:'#ffab00',type:'Intelligence'},
      {x:82,y:28,label:'NPA',country:'KP',color:'#ff3b5c',type:'Military'},
      {x:35,y:42,label:'Mossad',country:'IL',color:'#448aff',type:'Intelligence'},
      {x:30,y:60,label:'DarkNet',country:'TOR',color:'#b388ff',type:'Network'},
      {x:55,y:45,label:'BND',country:'DE',color:'#448aff',type:'Intelligence'},
      {x:50,y:38,label:'DGSE',country:'FR',color:'#448aff',type:'Intelligence'},
      {x:40,y:55,label:'APT Hub',country:'IR',color:'#ffab00',type:'Threat'},
      {x:65,y:55,label:'CyberCmd',country:'IN',color:'#00e676',type:'Defense'},
      {x:85,y:50,label:'APT10',country:'CN',color:'#ffab00',type:'APT'},
      {x:15,y:45,label:'NORAD',country:'US',color:'#00d4ff',type:'Military'},
    ];
    setNodes(worldNodes);

    // Event generation
    const interval = setInterval(() => {
      setEvents(prev => {
        const next = [generateEvent(), ...prev].slice(0, 25);
        return next;
      });
      setScanLines(s => (s + 1) % 100);
    }, 1500);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="h-full bg-[#0a0a0f] flex flex-col overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-[#0d0d17] border-b border-[#1e1e30]">
        <div className="flex items-center gap-2">
          <span className="text-lg">🌍</span>
          <h2 className="text-white font-black text-sm tracking-wider">LIVE GLOBAL CYBER MONITOR</h2>
          <span className="w-2 h-2 rounded-full bg-[#00e676] animate-pulse"/>
          <span className="text-[#00e676] text-[9px] font-bold animate-pulse">LIVE</span>
        </div>
        <div className="flex items-center gap-3 text-[9px]">
          <span className="text-[#5a5a72]">EVENTS: <span className="text-[#ff3b5c] font-bold">{events.length}</span></span>
          <span className="text-[#5a5a72]">NODES: <span className="text-[#00d4ff] font-bold">{nodes.length}</span></span>
          <span className="text-[#5a5a72]">SCANS: <span className="text-[#00d4ff] font-bold">{scanLines}K</span></span>
        </div>
      </div>

      {/* Map Area */}
      <div className="flex-1 relative bg-[#050510] overflow-hidden">
        {/* World Grid */}
        <svg className="absolute inset-0 w-full h-full opacity-20" viewBox="0 0 100 65">
          {/* Latitude lines */}
          {[10,20,30,40,50,60].map(y => <line key={`lat-${y}`} x1="0" y1={y} x2="100" y2={y} stroke="#00d4ff" strokeWidth="0.05"/>)}
          {/* Longitude lines */}
          {[10,20,30,40,50,60,70,80,90].map(x => <line key={`lon-${x}`} x1={x} y1="0" x2={x} y2="65" stroke="#00d4ff" strokeWidth="0.05"/>)}
          {/* Continents (rough outlines) */}
          <ellipse cx="20" cy="30" rx="14" ry="18" fill="none" stroke="#00d4ff" strokeWidth="0.2"/>
          <ellipse cx="48" cy="28" rx="12" ry="9" fill="none" stroke="#00d4ff" strokeWidth="0.2"/>
          <ellipse cx="55" cy="38" rx="5" ry="7" fill="none" stroke="#00d4ff" strokeWidth="0.2"/>
          <ellipse cx="75" cy="30" rx="14" ry="16" fill="none" stroke="#00d4ff" strokeWidth="0.2"/>
          <ellipse cx="28" cy="50" rx="6" ry="8" fill="none" stroke="#00d4ff" strokeWidth="0.2"/>
          <ellipse cx="50" cy="52" rx="5" ry="6" fill="none" stroke="#00d4ff" strokeWidth="0.2"/>
          <ellipse cx="65" cy="50" rx="4" ry="5" fill="none" stroke="#00d4ff" strokeWidth="0.2"/>
          <ellipse cx="85" cy="48" rx="4" ry="5" fill="none" stroke="#00d4ff" strokeWidth="0.2"/>
        </svg>

        {/* Attack Lines */}
        <svg className="absolute inset-0 w-full h-full" viewBox="0 0 100 65">
          {events.slice(0,8).map((ev,i) => {
            const src = nodes.find(n => n.country === ev.country) || nodes[Math.floor(Math.random()*nodes.length)];
            const dst = nodes[Math.floor(Math.random()*nodes.length)];
            return (
              <line key={i}
                x1={src.x} y1={src.y} x2={dst.x} y2={dst.y}
                stroke={ev.severity==='CRITICAL'?'#ff3b5c':ev.severity==='HIGH'?'#ffab00':'#00d4ff'}
                strokeWidth={ev.severity==='CRITICAL'?0.5:0.2}
                opacity={0.4 + Math.random()*0.3}
                strokeDasharray="1,1"
              >
                <animate attributeName="opacity" values="0.2;0.6;0.2" dur="2s" repeatCount="indefinite"/>
              </line>
            );
          })}
        </svg>

        {/* Nodes */}
        {nodes.map((node,i) => (
          <div key={i} className="absolute" style={{left:`${node.x}%`,top:`${node.y}%`,transform:'translate(-50%,-50%)'}}>
            <div className="w-3 h-3 rounded-full animate-pulse" style={{backgroundColor:node.color,boxShadow:`0 0 15px ${node.color}`}}/>
            <div className="absolute -top-4 left-1/2 -translate-x-1/2 text-[7px] font-bold whitespace-nowrap" style={{color:node.color,textShadow:`0 0 8px ${node.color}`}}>
              {node.label}
            </div>
          </div>
        ))}
      </div>

      {/* Live Events Feed */}
      <div className="h-64 overflow-y-auto bg-[#0a0a12] border-t border-[#1e1e30] p-3">
        <h3 className="text-[10px] text-[#5a5a72] font-bold uppercase tracking-wider mb-2">▸ LIVE CYBER EVENT FEED</h3>
        <div className="space-y-1">
          {events.map((ev,i) => (
            <div key={i} className="flex items-center gap-2 py-1.5 px-2 rounded hover:bg-[#111118] transition-colors border-b border-[#1e1e30]/50 text-[9px]"
              style={{borderLeft:`3px solid ${ev.severity==='CRITICAL'?'#ff3b5c':ev.severity==='HIGH'?'#ffab00':ev.severity==='MED'?'#00d4ff':'#00e676'}`}}>
              <span className="text-[#5a5a72] w-14">{ev.time}</span>
              <span className={`px-1.5 py-0.5 rounded text-[7px] font-black ${
                ev.severity==='CRITICAL'?'bg-[#ff3b5c]/10 text-[#ff3b5c] border border-[#ff3b5c]/20':
                ev.severity==='HIGH'?'bg-[#ffab00]/10 text-[#ffab00] border border-[#ffab00]/20':
                ev.severity==='MED'?'bg-[#00d4ff]/10 text-[#00d4ff] border border-[#00d4ff]/20':
                'bg-[#00e676]/10 text-[#00e676] border border-[#00e676]/20'
              }`}>{ev.severity}</span>
              <span className="text-white font-bold">{ev.type}</span>
              <span className="text-[#5a5a72]">| {ev.country}</span>
              <span className="text-[#5a5a72] ml-auto font-mono">{ev.srcIP} → {ev.dstIP}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
