import { useState } from 'react';

const hackerWorld = [
  { id: 'anonymous', name: 'Anonymous', type: 'Hacktivist', icon: 'fa-mask', desc: 'Decentralized international hacktivist collective known for various cyber operations.', color: 'text-green-400' },
  { id: 'lulzsec', name: 'LulzSec', type: 'Hacktivist', icon: 'fa-laugh', desc: 'High-profile black hat hacking group known for "50 days of lulz".', color: 'text-yellow-400' },
  { id: 'equation', name: 'Equation Group', type: 'APT', icon: 'fa-skull', desc: 'Highly sophisticated threat actor, linked to NSA, creators of Stuxnet and Flame.', color: 'text-red-400' },
  { id: 'apt28', name: 'APT28 (Fancy Bear)', type: 'APT', icon: 'fa-bear', desc: 'Russian cyber espionage group linked to GRU military intelligence.', color: 'text-red-400' },
  { id: 'apt29', name: 'APT29 (Cozy Bear)', type: 'APT', icon: 'fa-crown', desc: 'Russian threat group, known for SolarWinds supply chain attack.', color: 'text-red-400' },
  { id: 'lazarus', name: 'Lazarus Group', type: 'APT', icon: 'fa-dragon', desc: 'North Korean state-sponsored group, $1B+ in crypto heists.', color: 'text-red-400' },
  { id: 'shadow', name: 'Shadow Brokers', type: 'Leak', icon: 'fa-cloud-showers', desc: 'Group that leaked NSA\'s Equation Group tools including EternalBlue.', color: 'text-purple-400' },
  { id: 'wikileaks', name: 'WikiLeaks Vault7', type: 'Leak', icon: 'fa-file-alt', desc: 'CIA hacking tools leak — largest intelligence leak in CIA history.', color: 'text-purple-400' },
  { id: 'darkbro', name: 'DarkBro (Doulat)', type: 'Legend', icon: 'fa-crown', desc: 'Creator of DOULATREX — The Global Cyber Command Center. Mr. Doulat Kumar.', color: 'text-green-400' },
];

const hackerTools = [
  { name: 'XKeyscore', desc: 'NSA\'s mass surveillance system', agency: 'NSA' },
  { name: 'PRISM', desc: 'Data collection program', agency: 'NSA' },
  { name: 'Pegasus', desc: 'Spyware developed by NSO Group', agency: 'NSO Group' },
  { name: 'EternalBlue', desc: 'SMBv1 exploit, used in WannaCry', agency: 'Equation Group' },
  { name: 'Stuxnet', desc: 'ICS/SCADA sabotage worm', agency: 'US/Israel' },
  { name: 'Duqu', desc: 'Info-stealing malware', agency: 'Equation Group' },
  { name: 'Flame', desc: 'Modular cyber espionage malware', agency: 'Equation Group' },
  { name: 'Regin', desc: 'GCHQ/NSA spyware platform', agency: 'GCHQ/NSA' },
];

export default function SobinTab() {
  const [tab, setTab] = useState<'groups' | 'tools'>('groups');

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-red-500/20 rounded p-4">
        <h2 className="text-red-400 font-bold text-sm">💀 HACKER WORLD — THREAT ACTORS & GROUPS</h2>
        <p className="text-green-700 text-[10px]">A comprehensive database of hacking groups, APTs, and legendary figures.</p>
      </div>

      <div className="flex gap-2">
        <button onClick={() => setTab('groups')} className={`px-4 py-1.5 text-[10px] font-bold rounded border ${tab === 'groups' ? 'bg-red-950/20 text-red-400 border-red-500/30' : 'text-green-700 border-green-900/20'}`}>
          👥 GROUPS
        </button>
        <button onClick={() => setTab('tools')} className={`px-4 py-1.5 text-[10px] font-bold rounded border ${tab === 'tools' ? 'bg-red-950/20 text-red-400 border-red-500/30' : 'text-green-700 border-green-900/20'}`}>
          🛠 NOTORIOUS TOOLS
        </button>
      </div>

      {tab === 'groups' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {hackerWorld.map(group => (
            <div key={group.id} className="bg-black/80 border border-green-900/20 rounded p-4 hover:border-red-700/30 transition-all">
              <div className="flex items-center gap-2 mb-2">
                <i className={`fas ${group.icon} text-lg ${group.color}`} />
                <div>
                  <h3 className="text-green-400 font-bold text-xs">{group.name}</h3>
                  <span className="text-[8px] text-red-600">{group.type}</span>
                </div>
              </div>
              <p className="text-green-600 text-[9px]">{group.desc}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {hackerTools.map((tool, i) => (
            <div key={i} className="bg-black/80 border border-green-900/20 rounded p-3 hover:border-yellow-700/30 transition-all">
              <div className="flex items-center justify-between mb-1">
                <h3 className="text-yellow-400 font-bold text-xs">{tool.name}</h3>
                <span className="text-[8px] text-red-600 bg-red-950/10 px-1.5 py-0.5 rounded">{tool.agency}</span>
              </div>
              <p className="text-green-600 text-[9px]">{tool.desc}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
