import { useState } from 'react';
import type { AccessLevel } from '../data/types';

interface Props {
  accessLevel: AccessLevel;
}

const osTools = [
  { name: 'Kali Linux', icon: 'fa-linux', desc: 'The ultimate penetration testing distribution', category: 'Linux', tools: ['600+ pre-installed tools', 'Metasploit', 'Burp Suite', 'Nmap', 'Wireshark'], color: 'text-blue-400' },
  { name: 'Parrot OS', icon: 'fa-linux', desc: 'Security and privacy-focused Linux distribution', category: 'Linux', tools: ['Anonsurf', 'Tor', 'Firejail', 'Custom kernel'], color: 'text-cyan-400' },
  { name: 'BlackArch', icon: 'fa-linux', desc: 'Arch Linux-based pentesting distribution', category: 'Linux', tools: ['2800+ tools', 'Lightweight', 'Rolling release'], color: 'text-gray-400' },
  { name: 'Tails', icon: 'fa-linux', desc: 'Amnesic incognito live system', category: 'Linux', tools: ['Tor forced', 'No trace', 'Encrypted persistence'], color: 'text-purple-400' },
  { name: 'Qubes OS', icon: 'fa-cube', desc: 'Security-oriented OS with compartmentalization', category: 'Linux', tools: ['VM isolation', 'Template VMs', 'Disposable VMs'], color: 'text-green-400' },
  { name: 'Windows Server', icon: 'fa-windows', desc: 'Enterprise Windows environment', category: 'Windows', tools: ['Active Directory', 'PowerShell', 'Group Policy', 'IIS'], color: 'text-blue-400' },
  { name: 'macOS', icon: 'fa-apple', desc: 'Apple macOS for security research', category: 'macOS', tools: ['Xcode', 'Homebrew', 'Little Snitch', 'Kext signing'], color: 'text-gray-400' },
  { name: 'Android', icon: 'fa-android', desc: 'Mobile security testing platform', category: 'Mobile', tools: ['ADB', 'Frida', 'Magisk', 'Custom ROMs'], color: 'text-green-400' },
  { name: 'iOS', icon: 'fa-apple', desc: 'Apple iOS security research', category: 'Mobile', tools: ['Checkra1n', 'Frida', 'Objection', 'Needle'], color: 'text-gray-400' },
  { name: 'Remnux', icon: 'fa-linux', desc: 'Malware analysis toolkit', category: 'Linux', tools: ['RE tools', 'Malware sandbox', 'Network analysis'], color: 'text-red-400' },
];

export default function GlobalOSArsenal({ accessLevel: _al }: Props) {
  const [selected, setSelected] = useState<string | null>(null);
  const [filter, setFilter] = useState('ALL');

  const categories = ['ALL', 'Linux', 'Windows', 'macOS', 'Mobile'];
  const filtered = filter === 'ALL' ? osTools : osTools.filter(o => o.category === filter);

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-green-900/20 rounded p-4">
        <h2 className="text-green-400 font-bold text-sm">💻 GLOBAL OS ARSENAL</h2>
        <p className="text-green-700 text-[10px]">Operating systems for offensive and defensive security.</p>
      </div>

      <div className="flex gap-1 flex-wrap">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setFilter(cat)}
            className={`px-3 py-1 text-[9px] rounded border font-mono ${
              filter === cat ? 'bg-green-950/20 text-green-400 border-green-500/30' : 'text-green-700 border-green-900/20'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {filtered.map(os => (
          <div
            key={os.name}
            onClick={() => setSelected(selected === os.name ? null : os.name)}
            className={`border rounded p-4 cursor-pointer transition-all ${
              selected === os.name
                ? 'border-green-500/30 bg-green-950/5'
                : 'border-green-900/20 bg-black/80 hover:border-green-700/30'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <i className={`fab ${os.icon} text-lg ${os.color}`} />
              <div>
                <h3 className="text-green-400 font-bold text-xs">{os.name}</h3>
                <span className="text-[8px] text-green-700">{os.category}</span>
              </div>
            </div>
            <p className="text-green-600 text-[9px]">{os.desc}</p>
            {selected === os.name && (
              <div className="mt-2 pt-2 border-t border-green-900/20">
                <div className="flex flex-wrap gap-1">
                  {os.tools.map((t, i) => (
                    <span key={i} className="px-1.5 py-0.5 text-[8px] bg-green-950/10 border border-green-900/20 rounded text-green-500 font-mono">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
