import type { ResearchTool } from '../data/types';

interface Props {
  data: ResearchTool;
  onBack: () => void;
}

export default function ToolContent({ data, onBack }: Props) {
  return (
    <div className="bg-black/80 border border-green-900/20 rounded p-4 min-h-[300px]">
      <button
        onClick={onBack}
        className="text-green-700 hover:text-green-400 text-[10px] mb-3 font-mono"
      >
        ← BACK TO SEARCH
      </button>

      <div className="flex items-start gap-3 mb-4">
        <div className="text-3xl">
          <i className={`fas ${data.icon || 'fa-tool'}`} />
        </div>
        <div>
          <h2 className="text-xl font-black text-white">{data.name}</h2>
          <div className="flex items-center gap-2 mt-1">
            <span className="text-[10px] text-red-400 font-bold">{data.category}</span>
            <span className={`text-[8px] px-1.5 py-0.5 rounded border ${
              data.level === 'omega' ? 'bg-purple-950/30 text-purple-400 border-purple-500/30' :
              data.level === 'classified' ? 'bg-red-950/30 text-red-400 border-red-500/30' :
              data.level === 'researcher' ? 'bg-yellow-950/30 text-yellow-400 border-yellow-500/30' :
              'bg-green-950/30 text-green-400 border-green-500/30'
            }`}>
              {data.level.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      <p className="text-green-600 text-xs mb-4">{data.longDescription || data.description}</p>

      {/* Tags */}
      {data.tags && data.tags.length > 0 && (
        <div className="mb-3">
          <span className="text-[9px] text-green-700 font-bold">TAGS:</span>
          <div className="flex flex-wrap gap-1 mt-1">
            {data.tags.map((tag, i) => (
              <span key={i} className="px-2 py-0.5 text-[9px] bg-green-950/10 border border-green-900/20 rounded text-green-500 font-mono">
                {tag}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* OS Support */}
      {data.os && data.os.length > 0 && (
        <div className="mb-3">
          <span className="text-[9px] text-green-700 font-bold">PLATFORMS:</span>
          <div className="flex flex-wrap gap-1 mt-1">
            {data.os.map((os, i) => (
              <span key={i} className="px-2 py-0.5 text-[9px] bg-cyan-950/10 border border-cyan-900/20 rounded text-cyan-500 font-mono">
                {os}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Commands */}
      {data.commands && data.commands.length > 0 && (
        <div className="mb-3">
          <span className="text-[9px] text-green-700 font-bold">COMMANDS:</span>
          <div className="mt-1 space-y-1">
            {data.commands.map((cmd, i) => (
              <div key={i} className="p-2 bg-[#020408] border border-green-900/20 rounded font-mono text-[10px] text-green-400">
                $ {cmd}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Install */}
      {data.install && (
        <div className="mb-3">
          <span className="text-[9px] text-green-700 font-bold">INSTALL:</span>
          <div className="mt-1 p-2 bg-[#020408] border border-green-900/20 rounded font-mono text-[10px] text-yellow-400">
            $ {data.install}
          </div>
        </div>
      )}

      {/* Usage */}
      {data.usage && (
        <div className="mb-3">
          <span className="text-[9px] text-green-700 font-bold">USAGE:</span>
          <div className="mt-1 p-2 bg-[#020408] border border-green-900/20 rounded font-mono text-[10px] text-green-400">
            {data.usage}
          </div>
        </div>
      )}

      {/* URL */}
      {data.url && (
        <div>
          <span className="text-[9px] text-green-700 font-bold">MORE INFO:</span>
          <div className="mt-1 p-2 bg-[#020408] border border-green-900/20 rounded font-mono text-[10px] text-cyan-400">
            🔗 {data.url}
          </div>
        </div>
      )}
    </div>
  );
}
