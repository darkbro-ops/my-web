import { useState } from 'react';
import type { AccessLevel } from '../data/types';

interface Props {
  accessLevel: AccessLevel;
}

export default function SecretVault({ accessLevel: _al }: Props) {
  const [password, setPassword] = useState('');
  const [unlocked, setUnlocked] = useState(false);
  const [error, setError] = useState(false);

  const vaultSecrets = [
    { id: 1, name: 'Zero-Day: CVE-2024-XXXX', type: 'Exploit', desc: 'Remote code execution in enterprise firewall appliances. Affects 50,000+ devices worldwide.', severity: 'CRITICAL' },
    { id: 2, name: 'APT Campaign: MidnightEagle', type: 'Intel', desc: 'Ongoing APT campaign targeting defense contractors in NATO countries. Attribution: Nation-state level.', severity: 'TOP SECRET' },
    { id: 3, name: 'DarkBro\'s Master Key', type: 'Access', desc: 'Universal bypass key for DOULATREX systems. Creator: Mr. Doulat Kumar. Generation: Quantum.', severity: 'OMEGA' },
    { id: 4, name: 'Underground Market Intel', type: 'Intel', desc: 'Dark web marketplace analysis: 12 new zero-days listed this week. Average price: $2.5M USD.', severity: 'CLASSIFIED' },
    { id: 5, name: 'Satellite Exploit Chain', type: 'Exploit', desc: 'Multi-stage exploit chain targeting LEO satellite communication systems.', severity: 'TOP SECRET' },
  ];

  const handleUnlock = () => {
    if (password.toLowerCase() === 'doulat' || password === 'omega') {
      setUnlocked(true);
      setError(false);
    } else {
      setError(true);
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div className="h-full bg-black p-4 flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-yellow-400 font-bold text-sm tracking-wider">🔒 SECRET VAULT</h2>
        <span className={`text-[9px] ${unlocked ? 'text-green-400' : 'text-red-400'}`}>
          {unlocked ? '● UNLOCKED' : '○ LOCKED'}
        </span>
      </div>

      {!unlocked ? (
        <div className="flex-1 flex flex-col items-center justify-center">
          <div className="text-6xl mb-4">🔐</div>
          <h3 className="text-yellow-400 font-bold mb-2">VAULT LOCKED</h3>
          <p className="text-green-700 text-xs mb-4 text-center">
            Enter the master password to access classified intelligence.
          </p>
          <div className="flex gap-2">
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleUnlock()}
              placeholder="Enter vault password..."
              className="px-3 py-1.5 bg-black border border-yellow-500/30 rounded text-yellow-400 text-xs outline-none font-mono w-48"
            />
            <button
              onClick={handleUnlock}
              className="px-4 py-1.5 bg-yellow-950/30 border border-yellow-500/30 rounded text-yellow-400 hover:bg-yellow-950/50 text-xs font-bold"
            >
              UNLOCK
            </button>
          </div>
          {error && <p className="text-red-400 text-[10px] mt-2 animate-pulse">ACCESS DENIED</p>}
          <p className="text-green-800 text-[8px] mt-4">Hint: The founder's name</p>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto space-y-2">
          {vaultSecrets.map((secret) => (
            <div key={secret.id} className="border border-yellow-500/20 rounded p-3 bg-yellow-950/5">
              <div className="flex items-center justify-between mb-1">
                <span className="text-yellow-400 text-xs font-bold">{secret.name}</span>
                <span className={`px-1.5 py-0.5 text-[7px] font-bold rounded ${
                  secret.severity === 'OMEGA' ? 'bg-purple-950/30 text-purple-400 border border-purple-500/30' :
                  secret.severity === 'TOP SECRET' ? 'bg-red-950/30 text-red-400 border border-red-500/30' :
                  'bg-yellow-950/30 text-yellow-400 border border-yellow-500/30'
                }`}>
                  {secret.severity}
                </span>
              </div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[9px] text-green-700">[{secret.type}]</span>
              </div>
              <p className="text-[10px] text-green-600">{secret.desc}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
