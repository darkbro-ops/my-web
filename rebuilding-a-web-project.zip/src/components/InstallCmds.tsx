import { useState } from 'react';

const installCategories = [
  {
    name: 'KALI LINUX',
    icon: 'fa-linux',
    color: 'text-blue-400',
    cmds: [
      { cmd: 'sudo apt update && sudo apt upgrade -y', desc: 'Update all packages' },
      { cmd: 'sudo apt install kali-linux-headless', desc: 'Install Kali headless' },
      { cmd: 'sudo apt install kali-linux-default', desc: 'Full Kali install' },
      { cmd: 'sudo apt install kali-linux-large', desc: 'Large Kali install' },
      { cmd: 'sudo apt install kali-linux-everything', desc: 'Install EVERY Kali tool (20GB+)' },
      { cmd: 'sudo apt install kali-desktop-xfce', desc: 'Install XFCE desktop' },
      { cmd: 'wget -q -O - archive.kali.org/archive-key.asc | sudo apt-key add', desc: 'Add Kali repo key' },
    ]
  },
  {
    name: 'DOCKER',
    icon: 'fa-docker',
    color: 'text-cyan-400',
    cmds: [
      { cmd: 'curl -fsSL https://get.docker.com | sudo sh', desc: 'Install Docker (quick)' },
      { cmd: 'sudo apt install docker.io docker-compose', desc: 'Install Docker via apt' },
      { cmd: 'sudo systemctl enable docker --now', desc: 'Enable Docker service' },
      { cmd: 'sudo usermod -aG docker $USER', desc: 'Add user to docker group' },
      { cmd: 'docker pull kalilinux/kali-rolling', desc: 'Pull Kali Docker image' },
    ]
  },
  {
    name: 'GO TOOLS',
    icon: 'fa-code',
    color: 'text-green-400',
    cmds: [
      { cmd: 'sudo apt install golang-go', desc: 'Install Go language' },
      { cmd: 'go install -v github.com/OWASP/Amass/v3/...@master', desc: 'Install Amass (OSINT)' },
      { cmd: 'go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest', desc: 'Install Subfinder' },
      { cmd: 'go install github.com/tomnomnom/assetfinder@latest', desc: 'Install Assetfinder' },
      { cmd: 'go install github.com/ffuf/ffuf@latest', desc: 'Install FFUF fuzzer' },
      { cmd: 'go install github.com/OJ/gobuster/v3@latest', desc: 'Install Gobuster' },
    ]
  },
  {
    name: 'PYTHON TOOLS',
    icon: 'fa-python',
    color: 'text-yellow-400',
    cmds: [
      { cmd: 'pip install shodan', desc: 'Shodan CLI' },
      { cmd: 'pip install pwntools', desc: 'CTF exploit framework' },
      { cmd: 'pip install impacket', desc: 'Network protocols library' },
      { cmd: 'pip install scapy', desc: 'Packet manipulation' },
      { cmd: 'pip install requests beautifulsoup4', desc: 'Web scraping essentials' },
      { cmd: 'pip install mitmproxy', desc: 'MITM proxy' },
    ]
  },
  {
    name: 'RUBY TOOLS',
    icon: 'fa-gem',
    color: 'text-red-400',
    cmds: [
      { cmd: 'sudo apt install ruby ruby-dev', desc: 'Install Ruby' },
      { cmd: 'gem install wpscan', desc: 'WordPress scanner' },
      { cmd: 'gem install metasploit-framework', desc: 'Metasploit (if not using Kali)' },
    ]
  },
  {
    name: 'ANDROID/IOS',
    icon: 'fa-mobile-alt',
    color: 'text-purple-400',
    cmds: [
      { cmd: 'sudo apt install adb fastboot', desc: 'Android Debug Bridge' },
      { cmd: 'pip install frida-tools', desc: 'Dynamic instrumentation' },
      { cmd: 'pip install objection', desc: 'Runtime mobile exploration' },
      { cmd: 'sudo apt install jtool', desc: 'iOS binary analysis' },
    ]
  },
  {
    name: 'MALWARE ANALYSIS',
    icon: 'fa-shield-virus',
    color: 'text-red-400',
    cmds: [
      { cmd: 'sudo apt install remnux-tools', desc: 'Malware analysis toolkit' },
      { cmd: 'pip install yara-python', desc: 'YARA rules engine' },
      { cmd: 'sudo apt install radare2 cutter', desc: 'Reverse engineering framework' },
      { cmd: 'sudo apt install ghidra', desc: 'NSA reverse engineering tool' },
      { cmd: 'sudo apt install strace ltrace', desc: 'System call tracers' },
    ]
  },
  {
    name: 'ANONYMITY',
    icon: 'fa-user-secret',
    color: 'text-purple-400',
    cmds: [
      { cmd: 'sudo apt install tor torsocks', desc: 'TOR network' },
      { cmd: 'sudo apt install proxychains4', desc: 'Proxy chains' },
      { cmd: 'sudo apt install macchanger', desc: 'MAC changer' },
      { cmd: 'sudo apt install secure-delete', desc: 'Secure file deletion' },
      { cmd: 'sudo apt install i2p', desc: 'I2P anonymous network' },
    ]
  },
];

export default function InstallCmds() {
  const [active, setActive] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const copyCmd = (cmd: string) => {
    navigator.clipboard.writeText(cmd);
    setCopied(cmd);
    setTimeout(() => setCopied(null), 1500);
  };

  return (
    <div className="space-y-4">
      <div className="bg-black/80 border border-green-900/20 rounded p-4">
        <h2 className="text-green-400 font-bold text-sm">📥 INSTALL COMMANDS — 100+ One-Liners</h2>
        <p className="text-green-700 text-[10px]">Quick install commands for all major hacking tools & frameworks.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {installCategories.map(cat => (
          <div key={cat.name} className="bg-black/80 border border-green-900/20 rounded overflow-hidden">
            <button
              onClick={() => setActive(active === cat.name ? null : cat.name)}
              className="w-full flex items-center gap-2 px-4 py-3 hover:bg-green-950/5 transition-all"
            >
              <i className={`fas ${cat.icon} ${cat.color}`} />
              <span className="text-green-400 font-bold text-xs">{cat.name}</span>
              <span className="text-green-700 text-[9px] ml-auto">{cat.cmds.length} commands</span>
            </button>
            {active === cat.name && (
              <div className="px-4 pb-3 space-y-1.5">
                {cat.cmds.map((cmd, i) => (
                  <div key={i} className="group flex items-center justify-between p-2 bg-[#020408] rounded border border-green-900/10 hover:border-green-700/20 transition-all">
                    <div className="flex-1 min-w-0">
                      <p className="font-mono text-[9px] text-green-400 truncate">$ {cmd.cmd}</p>
                      <p className="text-[8px] text-green-700">{cmd.desc}</p>
                    </div>
                    <button
                      onClick={(e) => { e.stopPropagation(); copyCmd(cmd.cmd); }}
                      className="ml-2 px-2 py-0.5 text-[8px] bg-green-950/20 border border-green-500/20 rounded text-green-400 hover:bg-green-950/30 transition-all"
                    >
                      {copied === cmd.cmd ? '✓' : 'COPY'}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
