import { useState } from 'react';
import { cloudShells } from '../data/shadowsect';

export default function ShadowCloudShells() {
  const [selected, setSelected] = useState<string|null>(null);
  const [copied, setCopied] = useState('');

  const copy = (c:string)=>{navigator.clipboard.writeText(c);setCopied(c);setTimeout(()=>setCopied(''),1500);};

  return (
    <div className="space-y-4 animate-fadein">
      <div className="card-glow-cyan p-4"><h2 className="text-white font-black text-sm">☁️ SHADOW CLOUD SHELLS — 10 Cloud Deployment Environments</h2><p className="text-[#8888a0] text-[10px] mt-1">Deploy Kali tools instantly in browser-based cloud shells. No local install needed.</p></div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
        {cloudShells.map(cs=>(
          <div key={cs.name} onClick={()=>setSelected(selected===cs.name?null:cs.name)}
            className={`card-dark p-3 cursor-pointer ${selected===cs.name?'ring-1 ring-[#00d4ff]/30':''}`}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-xl">{cs.provider==='Amazon'?'☁️':cs.provider==='Google'?'🌐':cs.provider==='Microsoft'?'🪟':cs.provider==='Microsoft/GitHub'?'🐙':cs.provider==='Oracle'?'🔴':'☁️'}</span>
                <div><span className="text-white font-bold text-xs">{cs.name}</span><span className="text-[8px] text-[#5a5a72] block">{cs.provider}</span></div>
              </div>
              <a href={cs.url} target="_blank" rel="noopener noreferrer" onClick={e=>e.stopPropagation()} className="text-[#448aff] text-[9px] hover:underline">↗ OPEN</a>
            </div>
            <p className="text-[10px] text-[#8888a0] mb-2">{cs.desc}</p>
            {selected===cs.name && (
              <div className="mt-2 pt-2 border-t border-[#1e1e30] space-y-2">
                <div><span className="text-[8px] text-[#5a5a72] font-bold">📥 INSTALL:</span><p className="text-[9px] text-[#00e676] mt-0.5">{cs.install}</p></div>
                <div><span className="text-[8px] text-[#5a5a72] font-bold">✨ FEATURES:</span><div className="flex flex-wrap gap-1 mt-1">{cs.features.map((f,i)=><span key={i} className="tag tag-cyan text-[7px]">{f}</span>)}</div></div>
                <div><span className="text-[8px] text-[#5a5a72] font-bold">💻 COMMANDS:</span>
                  {cs.commands.map((c,i)=>(<div key={i} className="code-block text-[9px] mt-1 group cursor-pointer relative py-1" onClick={e=>{e.stopPropagation();copy(c);}}>$ {c}<button className="absolute right-1 top-1 text-[7px] px-1.5 py-0.5 bg-[#1c1c2a] border border-[#2a2a40] rounded text-[#8888a0] opacity-0 group-hover:opacity-100">{copied===c?'✓':'CP'}</button></div>))}</div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
