import { useState } from 'react';
import { companyWeaknesses, attackTechniques } from '../data/ultimatedata';

export default function CompanyWeaknessPanel() {
  const [tab, setTab] = useState<'companies'|'techniques'>('companies');
  const [selected, setSelected] = useState<string|null>(null);
  const [search, setSearch] = useState('');

  const filteredCompanies = companyWeaknesses.filter(c =>
    !search || c.company.toLowerCase().includes(search.toLowerCase()) || c.country.toLowerCase().includes(search.toLowerCase())
  );
  const filteredTechniques = attackTechniques.filter(t =>
    !search || t.name.toLowerCase().includes(search.toLowerCase()) || t.category.toLowerCase().includes(search.toLowerCase()) || t.platform.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4 animate-fadein">
      <div className="card-glow-red p-4 flex items-center justify-between">
        <div>
          <h2 className="text-white font-black text-sm">⚠️ VULNERABILITY INTELLIGENCE — EDUCATIONAL DATABASE</h2>
          <p className="text-[#8888a0] text-[10px] mt-1">Company weaknesses & attack techniques — learn to defend, not to attack.</p>
        </div>
        <span className="text-[#ff3b5c] text-xs font-bold">FOR DEFENSE ONLY</span>
      </div>

      <div className="flex gap-2 items-center">
        <button onClick={()=>setTab('companies')} className={`px-4 py-1.5 rounded-lg text-[10px] font-bold transition-all ${tab==='companies'?'bg-[#ff3b5c]/10 text-[#ff3b5c] border border-[#ff3b5c]/30':'text-[#5a5a72] border border-[#1e1e30]'}`}>
          🏢 COMPANY WEAKNESSES ({companyWeaknesses.length})
        </button>
        <button onClick={()=>setTab('techniques')} className={`px-4 py-1.5 rounded-lg text-[10px] font-bold transition-all ${tab==='techniques'?'bg-[#ff3b5c]/10 text-[#ff3b5c] border border-[#ff3b5c]/30':'text-[#5a5a72] border border-[#1e1e30]'}`}>
          ⚔️ ATTACK TECHNIQUES ({attackTechniques.length})
        </button>
        <input type="text" value={search} onChange={e=>setSearch(e.target.value)}
          placeholder="Search..."
          className="ml-auto px-3 py-1.5 bg-[#111118] border border-[#1e1e30] rounded-lg text-[#e0e0f0] text-[10px] outline-none focus:border-[#ff3b5c]/30 w-48"/>
      </div>

      {tab==='companies' ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {filteredCompanies.map(c => (
            <div key={c.company} onClick={()=>setSelected(selected===c.company?null:c.company)}
              className={`card-dark p-4 cursor-pointer ${selected===c.company?'ring-1 ring-[#ff3b5c]/30':''}`}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-xl">{c.country==='USA'?'🇺🇸':c.country==='China'?'🇨🇳':c.country==='South Korea'?'🇰🇷':c.country==='UK'?'🇬🇧':'🌐'}</span>
                  <span className="text-white font-bold text-xs">{c.company}</span>
                  <span className="text-[#5a5a72] text-[9px]">{c.country}</span>
                </div>
                <span className="tag tag-red">{c.knownWeaknesses.length} weaknesses</span>
              </div>
              {selected===c.company && (
                <div className="space-y-2 mt-2 pt-2 border-t border-[#1e1e30]">
                  <div>
                    <span className="text-[9px] text-[#ff3b5c] font-bold">KNOWN WEAKNESSES:</span>
                    <div className="space-y-0.5 mt-1">{c.knownWeaknesses.map((w,i)=><div key={i} className="text-[10px] text-[#8888a0]">• {w}</div>)}</div>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#ffab00] font-bold">REPORTED BREACHES:</span>
                    <div className="space-y-0.5 mt-1">{c.reportedBreaches.map((b,i)=><div key={i} className="text-[10px] text-[#ffab00]/70">• {b}</div>)}</div>
                  </div>
                  <div>
                    <span className="text-[9px] text-[#00e676] font-bold">SECURITY TOOLS:</span>
                    <div className="flex flex-wrap gap-1 mt-1">{c.securityTools.map((t,i)=><span key={i} className="tag tag-green text-[7px]">{t}</span>)}</div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
          {filteredTechniques.map(t => (
            <div key={t.id} onClick={()=>setSelected(selected===t.id?null:t.id)}
              className={`card-dark p-4 cursor-pointer ${selected===t.id?'ring-1 ring-[#ff3b5c]/30':''}`}>
              <div className="flex items-center justify-between mb-2">
                <div>
                  <span className="text-white font-bold text-xs">{t.name}</span>
                  <span className="text-[#5a5a72] text-[9px] ml-2">{t.platform}</span>
                </div>
                <span className={`tag ${t.difficulty==='Expert'?'tag-purple':t.difficulty==='Advanced'?'tag-red':t.difficulty==='Intermediate'?'tag-yellow':'tag-green'}`}>{t.difficulty}</span>
              </div>
              <p className="text-[10px] text-[#8888a0]">{t.desc}</p>
              {selected===t.id && (
                <div className="space-y-2 mt-2 pt-2 border-t border-[#1e1e30]">
                  <div className="flex flex-wrap gap-1">{t.tools.map((tk,i)=><span key={i} className="tag tag-red text-[7px]">{tk}</span>)}</div>
                  <div className="code-block text-[9px]">{t.commands[0]}</div>
                  <div><span className="text-[8px] text-[#00e676] font-bold">🛡 MITIGATION:</span><p className="text-[9px] text-[#00e676]/70 mt-0.5">{t.mitigation}</p></div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
